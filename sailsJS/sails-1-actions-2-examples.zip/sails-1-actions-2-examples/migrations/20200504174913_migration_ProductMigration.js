
exports.up = function(knex) {
  return knex.schema.createTable("Product", function(t) {
    t.increments("id").primary();

    t.integer("txtPid").nullable();
    t.string("firstName").nullable();
    t.date("dob").nullable();
    t.string("email").nullable();
    t.string("phone").nullable();
    t.string("imageUrl").nullable();

    t.timestamp("createdAt", { useTz: true });
    t.timestamp("updatedAt", { useTz: true });
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists("Product");
};
