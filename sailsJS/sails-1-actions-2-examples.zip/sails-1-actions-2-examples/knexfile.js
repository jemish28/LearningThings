// Update with your config settings.

module.exports = {

  development: {
    client: 'mysql',
    connection: {
      database: 'sailsdemo',
      user: 'root',
      password: 'root'
    }
  }
};
