module.exports = {
  datastores:{
    default: {
      adapter: 'sails-mysql',
      timezone: 'UTC',
      dateStrings: true,
      url: 'mysql://root:123456@localhost:3306/Sails_DB_Test',
    },
  }
};
