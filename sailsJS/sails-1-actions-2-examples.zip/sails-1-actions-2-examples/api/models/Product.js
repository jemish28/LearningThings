/**
 * File.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {

    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝


    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝


    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝
    txtPid: {
      type: 'string',
      required: true,
      description: 'pid.',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
    firstName: {
      type: 'string',
      required: true,
      description: 'Full representation of the user\'s name.',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
    lastName: {
      type: 'string',
      required: true,
      description: 'Full representation of the user\'s name.',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
    dob: {
      type: 'string',
      required: true,
      description: 'date',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
    email: {
      type: 'string',
      required: true,
      description: 'email',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
    phone: {
      type: 'string',
      required: true,
      description: 'phone',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
    imageUrl: {
      type: 'string',
      required: true,
      description: 'imageUrl',
      maxLength: 120,
      example: 'Mary Sue van der McHenst'
    },
  },
  // customToJSON: function () {
  //       var moment = require('moment');
  //       this.openingTime = moment(this.openingTime, ["HH:mm"]).format("h:mm A");
  //       this.closingTime = moment(this.closingTime, ["HH:mm"]).format("h:mm A");
  //       return _.omit(this);
  //   },
  customToJSON: function () {
      if (this.imageUrl) {
          this.imageUrl = sails.config.custom.baseUrl + this.imageUrl;
      }
     return _.omit(this, []);
  },
};

