
module.exports = async function welcomeUser (req, res) {

  var user = await Product.find({});

  if (!user) {
    return res.redirect('/Product/create' );
  }

  return res.view('Product/list', {user});

}