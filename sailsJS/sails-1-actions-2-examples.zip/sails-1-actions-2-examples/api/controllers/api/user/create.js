module.exports = {


  friendlyName: 'Create',


  description: 'Create user.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    // All done.
    return;

  }


};
