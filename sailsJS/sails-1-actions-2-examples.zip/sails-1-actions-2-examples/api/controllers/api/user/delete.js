module.exports = {


  friendlyName: 'Delete',


  description: 'Delete user.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    // All done.
    return;

  }


};
