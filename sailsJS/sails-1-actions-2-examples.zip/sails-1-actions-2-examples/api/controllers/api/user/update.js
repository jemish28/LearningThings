module.exports = {


  friendlyName: 'Update',


  description: 'Update user.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    // All done.
    return;

  }


};
