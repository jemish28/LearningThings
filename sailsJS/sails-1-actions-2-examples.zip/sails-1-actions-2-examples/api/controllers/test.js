module.exports = {


  friendlyName: 'Test',


  description: 'Test something.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    // All done.
    return;

  }


};
