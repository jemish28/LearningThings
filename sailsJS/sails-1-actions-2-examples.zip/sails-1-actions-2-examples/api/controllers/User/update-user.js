module.exports = {


  friendlyName: 'Update user',


  description: '',

  inputs: {
    fullName: {
      type: 'string'
    },
    emailAddress: {
      unique: true,
      type: 'string'
    },
      userId: {
        type: 'string',
        required: true,
      },
  },


  exits: {

  },


  fn: async function (inputs) {

    var updatedUser = await User.update({
          id: inputs.userId
    }).set({
          fullName: inputs.fullName,
          emailAddress: inputs.emailAddress
    });
  }


};
