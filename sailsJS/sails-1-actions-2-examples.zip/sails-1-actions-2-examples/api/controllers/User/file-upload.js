module.exports = {
  friendlyName: 'Single file upload',
  description: '',

  exits: {

  },
  fn: async function (inputs, exits) {

    var req = this.req;
    req.file('avatar').upload({
      dirname: require('path').resolve(sails.config.appPath, 'assets/images')
    },function (err, images) {
    if (err) {
       return exits.serverError(err);
    }
    else{
       return exits.success({ message: 'file(s) uploaded successfully!'});
      }
    });

  }
};