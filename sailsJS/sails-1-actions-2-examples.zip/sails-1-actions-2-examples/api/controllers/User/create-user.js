module.exports = {


  friendlyName: 'Create user',


  description: '',

  inputs: {
      fullName: {
        type: 'string',
        required: true,
      },
      emailAddress: {
        required: true,
        unique: true,
        type: 'string',
        // isEmail: true,
      },
      password: {
        required: true,
        type: 'string',
        maxLength: 15,
        minLength: 6,
      },
    },


    exits: {
      invalid: {
        statusCode: 409,
        description: 'user create error' // this will not go in response
      },
  },

    fn: async function (inputs, exits) {
      var userRecord = await User.create({
          fullName: inputs.fullName,
          emailAddress: inputs.emailAddress,
          password: inputs.password,
        });

      // if (!userRecord) {
      //   return exits.invalid({
      //     message: 'invalid, problem creating user'
      //   });
      // }
      return exits.success({
        message: 'User has been created successfully.',
        data: userRecord
      });
    }
};
