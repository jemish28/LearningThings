module.exports = async function welcomeUser (req, res) {

  // Get the `userId` parameter from the request.
  // This could have been set on the querystring, in
  // the request body, or as part of the URL used to
  // make the request.
  var userId = req.param('id');

  // Look up the user whose ID was specified in the request.
  var user = await Product.destroyOne({ id: userId });

  // If no user was found, redirect to signup.
  if (!user) {
    return res.redirect('/Product/list' );
  }

  // Display the welcome view, setting the view variable
  // named "name" to the value of the user's name.
  var user = await Product.find({});
  return res.view('Product/list', {user});

}