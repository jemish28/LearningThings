// module.exports = {
//   friendlyName: 'View Create',
//   description: 'Display "Create" page.',

//   inputs: {
//     txtPid: {
//       type: 'string',
//       allowNull:true,
//       required: false,
//     },
//     firstName: {
//       type: 'string',
//       required: false,
//     },
//     lastName: {
//       type: 'string',
//       required: false,
//     },
//     dob: {
//       type: 'string',
//       required: false,
//     },
//     email: {
//       type: 'string',
//       required: false,
//     },
//     phone: {
//       type: 'string',
//       required: false,
//     },
//     imageUrl: {
//       type: 'string',
//       required: false,
//     },

//   },

//   fn: async function (inputs, exits) {

//       var req = this.req;

//       var _newContact = await Product.create({
//         txtPid: inputs.txtPid,
//         firstName: inputs.firstName,
//         lastName: inputs.lastName,
//         dob: inputs.dob,
//         email: inputs.email,
//         phone: inputs.phone,
//         imageUrl: inputs.imageUrl
//       });
//       return exits.success({
//         message: 'Product has been created successfully.',
//         data: _newContact
//       });
//   }

// };
module.exports = async function welcomeUser(req, res) {
  var new_image_name = req.file('imageUrl')._files[0]["stream"]["filename"];

  var _newContact = await Product.create({
    txtPid: req.param('txtPid'),
    firstName: req.param('firstName'),
    lastName: req.param('lastName'),
    dob: req.param('dob'),
    email: req.param('email'),
    phone: req.param('phone'),
    imageUrl: new_image_name
  });

  req.file('imageUrl').upload({
    dirname: require('path').resolve(sails.config.appPath, 'assets/images'),
    saveAs: new_image_name,
  }, function (err, images) {
    if (err) {
      sails.log('Error');
    } else {
      sails.log('Success');
    }
  });
  var user = await Product.find({});
  return res.view('Product/list', {
    user
  });

}
