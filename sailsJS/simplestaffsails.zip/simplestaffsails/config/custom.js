/**
 * Custom configuration
 * (sails.config.custom)
 *
 * One-off settings specific to your application.
 *
 * For more information on custom configuration, visit:
 * https://sailsjs.com/config/custom
 */

module.exports.custom = {
  verifyEmailAddresses: true,
  /***************************************************************************
  *                                                                          *
  * Any other custom config this Sails app should use during development.    *
  *                                                                          *
  ***************************************************************************/
  // mailgunDomain: 'transactional-mail.example.com',
  // mailgunSecret: 'key-testkeyb183848139913858e8abd9a3',
  // stripeSecret: 'sk_test_Zzd814nldl91104qor5911gjald',
  // …

  //FOLDER PATH
  profilePicture: 'profilePicture/',
  documents: '/documents/',
  image: '/images/',
  jobMedia: 'Admin/Job/',
  chat : 'chat/',


  // MESSAGES
  messages: {
    noAnyParam: 'No any parameter found. Please try again',
    auth: {
      emailAddress: 'Email address not found',
      resetPasswordLink: 'Reset password link sent successfully. Please check your email',
      userNotFound: 'User not found',
      verifyAccount: 'Please verify your account',
      notActive: 'Your account is not active',
      invalidToken: 'Invalid token',
      passwordReset: 'Password reset successfully',
      emailAddressExist: 'Email address already exist',
      signupSuccess: 'Signup successfully. Please check your email and active your account',
      invalidPassword: 'Invalid password',
      invalidCredential: 'Invalid credential',
      oldPassword: 'Old password is invalid',
      loginSuccess: 'Login successfully'
    },
    user: {
      emailExist: 'User already exist',
      notCreate: 'User not create',
      create: 'User create successfully',
      delete: 'User delete successfully',
      update: 'User update successfully',
      subscribe: 'subscribe user successfully',
      passwordUpdate: 'Password change successfully',
      passwordNotUpdate: 'Password not update.Please try again',
      getData: 'Get data successfully',
      passwordreset: 'Password update successfully, please login in application',
      mailsend: 'Mail has been sent , check your mail',
      changePassword: 'Password change successfully, please login in application',
      changePasswordInvalid: 'User not found',
      newConfirmSame: 'New password and confirm new password should be same',
      oldPasswordCheck:'Old password is invalid',
      profileImage:'Profile image upload successfully'
    },
    application: {
      applicationSubmit: 'Application submit successfully',
      applicationSendMsgOtp: 'OTP send successfully',
      verifyOtp: 'Phone Number has been varified successfully',
      verifyOtpWrongEntered: 'Please enter correct OTP',
      imageNotUploadError: 'Please Upload Image',
      mediaUpload: 'Media upload successfully',
      bookAppointment: 'Appointment book successfully',
      dateNotValidFormat: 'Please enter valid date format',
      dateNotAfter: 'Appointment date should be future date',
      applicationIdNotFound: 'Before upload document please verify mobile number',
      removeFile: 'Remove file successfully',
      fileNotFound: 'File not found'
    },
    job: {
      dateNotValidFormat: 'Please enter valid date format',
      hourNotValidFormat: 'Please enter valid hour',
      dateNotAfter: 'Week availability date should be future date',
      weeklyAvailability: 'Week availability date and time added successfully',
      dateValidationForDuplicate: 'Date which you are enter is already exist for same id , kindly enter different future date',
      jobSuggestion: 'Job suggestion list get successfully',
      jobAccept: 'Job accept successfully',
      jobDecline: 'Job decline successfully',
      totalHour: 'Total hour of week get successfully',
      getweeklyAvailability: 'Get weekly availability successfully',
      getAccptedJob: 'Get accept job successfully',
      JobOutTime: 'Job out time should be greater than job in time',
      JobInTime: 'Job in time should be future time',
      JobInOutTime: 'Job time updated successfully'
    },
    chat:{
      create: 'Chat create successfully',
    },
    admin:{
      subscribe:'subscribe user successfully',
    }
  },
};
