/**
 * Policy Mappings
 * (sails.config.policies)
 *
 * Policies are simple functions which run **before** your actions.
 *
 * For more information on configuring policies, check out:
 * https://sailsjs.com/docs/concepts/policies
 */

module.exports.policies = {

  /***************************************************************************
   *                                                                          *
   * Default policy for all controllers and actions, unless overridden.       *
   * (`true` allows public access)                                            *
   *                                                                          *
   ***************************************************************************/

  // '*': [''],
  '*': false,

  // Bypass the `is-super-admin` policy for:
  'admin/*': ['is-super-admin'],
  'admin/admin/auth/*': true,

  'api/*': ['isAuthorized'],
  'api/v-1/user/auth/*': true,
  'api/v-1/user/create': true,
  'api/v-1/chat/subscribeuser1':true,
  'api/v-1/chat/chatlist':true,
  'api/v-1/chat/createchat':true,
  'api/v-1/chat/leaveroom':true,
  /*
    whenever we want to by pass without token then only use true in policies.
  */
  'common/*': true,
  'front/*': true,
};
