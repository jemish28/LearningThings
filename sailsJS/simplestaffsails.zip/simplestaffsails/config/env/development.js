// var AWS = require("aws-sdk");

module.exports = {
  /***************************************************************************
   * Set the default database connection for models in the development       *
   * environment (see config/connections.js and config/models.js )           *
   ***************************************************************************/
  mode: 'development',
  siteName: 'Simple Staff',
  shortName: 'ST',
  redis_url: 'redis://127.0.0.1:6379',
  models: {
    // connection: 'localMysqlServer'     //local
    // connection: 'liveMysqlServer'  // 22
    // connection: 'productionMysqlServer'  // production
    // connection: "liveMysqlServer", // production_AWS
    migrate: 'safe'
  },

  //sails.__
  datastores: {
    default: {
      adapter: 'sails-mysql',
			url: 'mysql://root:root@localhost:3306/student_staffapp',
      wlNext: {
        caseSensitive: true
      }
    }
  },

  mail: {
    email: 'noreplysimplestaff@yandex.com',
    password: 'Simplestaff12',
    host: 'smtp.yandex.com',
    port: 465,
    secure: true, // true for 465, false for other ports
    from: {
      name: 'Debug Mail',
      email: 'noreplysimplestaff@yandex.com',
    },
    to: {
      name: '',
      email: 'nirav@logisticinfotech.com',
    },
  },

  custom: {

    baseUrl: 'http://localhost:1337/',
    mediaDisplayPath : 'http://localhost:1337/uploads/',
    mediaUploadPath: '/Applications/XAMPP/xamppfiles/htdocs/simplestaffsails/uploads/',
    protocol: 'http://',

    aws: {
      snsAccessKeyId: 'AKIA4HE6ZOJR3NYBOMU5',
      snsSecretAccessKey: '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',
      snsRegion: 'us-east-1',
      snsOutput: 'json',
      //IOS
      // snsArnIosUserPlatformApplication: 'arn:aws:sns:us-west-2:099612405189:app/APNS_SANDBOX/RideforSure_Customer_staging',
      // snsArnIosDriverPlatformApplication: 'arn:aws:sns:us-west-2:099612405189:app/APNS_SANDBOX/RideforSure_Driver_staging',
      iOS : 'arn:aws:sns:us-east-1:839999124067:app/APNS_SANDBOX/SS_iOS_APP',
      Android :'arn:aws:sns:us-east-1:839999124067:app/GCM/SS_Android_App'
      // snsArnIosUserTopic: 'arn:aws:sns:us-west-2:099612405189:rfs_iOSUserStaging',
      // snsArnIosDriverTopic: 'arn:aws:sns:us-west-2:099612405189:rfs_iOSDriverStaging',
      // ANDROID
      // snsArnAndroidUserPlatformApplication: 'arn:aws:sns:us-west-2:099612405189:app/GCM/RideforSure_Customer_Android_Staging',
      // snsArnAndroidDriverPlatformApplication: 'arn:aws:sns:us-west-2:099612405189:app/GCM/RideforSure_Driver_Android_Staging',

      // snsArnAndroidUserTopic: 'arn:aws:sns:us-west-2:099612405189:rfs_androidUserStaging',
      // snsArnAndroidDriverTopic: 'arn:aws:sns:us-west-2:099612405189:rfs_androidDriverStaging',
    },
  },


  //   /****** Hood twilio ******/
  //   twilioSid: "AC3ab15b8a2ec65785e01b190b56852f62",
  //   twilioauthToken: "ca3385ee1e9c2c830d425f58bae13a7e",
  //   twiliomobilenumber: "+17865098772",

  // set the status if you want to send the SMS SERVICES
  PHONE_SMS_STATUS: 'true',

  // twilio setting
  ACCOUNT_SID: 'AC1c0ac6393b4a0bf4a80d5afaaae5ded1',
  AUTH_TOKEN: 'b437e37338c1581fca299e9443e06497',
  TWILLIO_PHONE_NO: '+19592650686',

  // ACCOUNT_SID: 'AC1514156c8103951286eef713b7c80430',
  // AUTH_TOKEN: '5e170d63a1e04251f4b9c66995b40fcb',
  // TWILLIO_PHONE_NO: '+61437784830',

  url: {
    appURL: 'http://localhost:1337',
    applicationURL: 'http://localhost:1337',
  },
};
