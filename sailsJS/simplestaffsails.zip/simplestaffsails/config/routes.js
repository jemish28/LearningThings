/**
 * Route Mappings
 * (sails.config.routes)
 *
 * Your routes tell Sails what to do each time it receives a request.
 *
 * For more information on configuring custom routes, check out:
 * https://sailsjs.com/anatomy/config/routes-js
 */
var adminRoutes = {
  'GET /incident-view': { view: 'incident-form', locals: { layout: 'admin/layouts/layout' } },
  'GET /': { action: 'common/view-homepage-or-redirect'},
  'GET ': { action: 'common/view-homepage-or-redirect' },
  'GET /login': { view: 'admin/login', locals: { layout: 'admin/layouts/layout' } },
  'GET /userlogin': { view: 'admin/loginforuser', locals: { layout: 'admin/layouts/layout' } },

  // Not Secured API
  'POST /login': { action: 'admin/admin/auth/login', locals: { layout: 'admin/layouts/master' } },
  'GET /logout': { action: 'admin/admin/auth/logout', locals: { layout: 'admin/layouts/layout' } },

  // Secured Views and APIs
	'GET /dashboard': { action: 'admin/dashboard/view-index', locals: { layout: 'admin/layouts/master' } },
	'GET /notificationlist': { action: 'admin/notification/notification-list', locals: { layout: 'admin/layouts/master' } },
	'GET /delete_notification/:id': { action: 'admin/notification/delete' },
	'GET /deleteallnotification': { action: 'admin/notification/delete-all' },

  // admin
  'GET /admins': { action: 'admin/admin/view-index', locals: { layout: 'admin/layouts/master' } },
  'GET /create': { action: 'admin/admin/view-create', locals: { layout: 'admin/layouts/master' } },
  'GET /edit/:adminId': { action: 'admin/admin/view-edit', locals: { layout: 'admin/layouts/master' } },

  'GET /index': { action: 'admin/admin/index' }, //getting list of admin with datatable
  'POST /create': { action: 'admin/admin/create' },
  'POST /update/:adminId': { action: 'admin/admin/update', locals: { layout: 'admin/layouts/master' } },
  'DELETE /:id': { action: 'admin/admin/delete' },
  'GET /subscribeuser': { action: 'admin/admin/subscribeuser' },

  // user
  'GET /users': { action: 'admin/user/view-index', locals: { layout: 'admin/layouts/master' } },

  // user

  'GET /pendingUsers': { action: 'admin/user/view-status-index', locals: { layout: 'admin/layouts/master' } },

  'GET /user/create': { action: 'admin/user/view-create', locals: { layout: 'admin/layouts/master' } },
  'GET /user/edit/:userId': { action: 'admin/user/view-edit', locals: { layout: 'admin/layouts/master' } },

  //documents of user
  'GET /media': { action: 'admin/media/view-media-index', locals: { layout: 'admin/layouts/master' } },
  'GET /media/create': { action: 'admin/media/view-media-create', locals: { layout: 'admin/layouts/master' } },
  'POST /media/create': { action: 'admin/media/create' },
  'POST /media/delete': { action: 'admin/media/delete' },
  'GET /media/edit/:id': { action: 'admin/media/view-media-edit', locals: { layout: 'admin/layouts/master' } },

  //datatable for time card
  'GET /user/index': { action: 'admin/user/index' },

  'GET /usersfortimecard/index/:jobId': { action: 'admin/job/indexfordatatable' },
  'GET /usersfortimecard/show/:id/:jobId': { action: 'admin/job/timecard-job-view', locals: { layout: 'admin/layouts/master' } },

  //getting list of admin with datatable
  'GET /user/index-status': { action: 'admin/user/index-status' },
  'GET /pendinguser/show/:id': { action: 'admin/user/pending-user-view', locals: { layout: 'admin/layouts/master' } },

  'GET /user/show/:id': { action: 'admin/user/all-user-view', locals: { layout: 'admin/layouts/master' } }, 'POST /user/create': { action: 'admin/user/create'},
  'POST /user/update/:userId': { action: 'admin/user/update', locals: { layout: 'admin/layouts/master' } },
  'GET /user/:id': { action: 'admin/user/delete' },
  'POST /user/status/:changeStatus/:id': { action: 'admin/user/change-status' },
  'POST /user/change-appointment-date/:userId': { action: 'admin/user/change-appointment-date' },

  //job
  'GET /job': { action: 'admin/job/view-job-index', locals: { layout: 'admin/layouts/master' } },
  'GET /job/index': { action: 'admin/job/index' },
  'GET /job/create': { action: 'admin/job/view-job-create', locals: { layout: 'admin/layouts/master' } },
  'GET /job/edit/:id': { action: 'admin/job/view-job-update', locals: { layout: 'admin/layouts/master' } },
  'GET /job/show/:id': { action: 'admin/job/view-job-show', locals: { layout: 'admin/layouts/master' } },
  'POST /job/create': { action: 'admin/job/create' },
  'GET /userdata/getdata/': { action: 'admin/job/getuserdata' },
  'POST /job/update/:id': { action: 'admin/job/update' },
	'DELETE /job/:id': { action: 'admin/job/delete' },
	'POST /job/change-status-job/:changeStatus/:id/:total_hours': { action: 'admin/job/change-status-job' },

  //chats
  'GET /chat': { action: 'admin/chat/view-chat-index', locals: { layout: 'admin/layouts/master' } },
  'POST /chat/send-msg-from-admin/': { action: 'admin/chat/send-msg-from-admin' },
  'POST /chat/send-msg-from-admin/:id': { action: 'admin/chat/send-msg-from-admin' },

  'POST /chat/on-connect': { action: 'admin/chat/on-connect' },
  'GET /chat/get-chat-data': { action: 'admin/chat/chatlist' },
  'GET /chat/leave-room': { action: 'admin/chat/leaveroom' },
  // 'POST /chat/subscribeuser': { action: 'api/v-1/user/subscribeuser' },

  //user availability
  'GET /useravailability': { action: 'admin/useravailability/view-useravailability-index', locals: { layout: 'admin/layouts/master' } },

  'GET /useravailability/show/:id': { action: 'admin/useravailability/view-useravailability-show', locals: { layout: 'admin/layouts/master' } },

  //News
  'GET /news': { action: 'admin/news/view-news-index', locals: { layout: 'admin/layouts/master' } },
  'GET /news/index': { action: 'admin/news/index' },
  'GET /news/create': { action: 'admin/news/view-news-create', locals: { layout: 'admin/layouts/master' } },
  'POST /news/create': { action: 'admin/news/create' },
  'GET /news/edit/:id': { action: 'admin/news/view-news-update', locals: { layout: 'admin/layouts/master' } },
  'POST /news/update/:id': { action: 'admin/news/update' },
  'DELETE /news/:id': { action: 'admin/news/delete' },

  'GET /workplacesafety': { action: 'admin/workplacesafety/view-workplacesafety-index', locals: { layout: 'admin/layouts/master' } },
  'GET /workplacesafety/index': { action: 'admin/workplacesafety/index' },
  'POST /workplacesafety/create': { action: 'admin/workplacesafety/create' },
  'GET /workplacesafety/edit/:id': { action: 'admin/workplacesafety/view-workplacesafety-update', locals: { layout: 'admin/layouts/master' } },
  'POST /workplacesafety/update/:id': { action: 'admin/workplacesafety/update' },
  'DELETE /workplacesafety/:id': { action: 'admin/workplacesafety/delete' },
  'GET /workplacesafety/create': { action: 'admin/workplacesafety/view-workplacesafety-create', locals: { layout: 'admin/layouts/master' } },
};

var apiV1 = {
  //  API V1
  'POST /user/login': { action: 'api/v-1/user/auth/login' },
  'POST /user/logout': { action: 'api/v-1/user/auth/logout' },
  'POST /user/create': { action: 'api/v-1/user/create' },
  'POST /user/update/:userId': { action: 'api/v-1/user/update' },
  'DELETE /user/delete/:userId': { action: 'api/v-1/user/delete' },
  'POST /user/refresh-token': { action: 'api/v-1/user/refresh-token' },
  'POST /user/get-user': { action: 'api/v-1/user/get-user' },
  'POST /user/reset-password': { action: 'api/v-1/user/auth/reset-password' },
  'POST /user/forgot-password': { action: 'api/v-1/user/auth/forgot-password' },
  'POST /user/change-password': { action: 'api/v-1/user/change-password' },
  'POST /user/user-profile': { action: 'api/v-1/user/user-profile-image' },
  //'GET /user/subscribeuser': { action: 'api/v-1/user/subscribeuser' },

  //for application API V1

  'POST /application/create': { action: 'api/v-1/application/create' },

  //for send otp API V1
  'POST /application/sendOtp': { action: 'api/v-1/application/send-sms' },
  'POST /application/varifyOtp': { action: 'api/v-1/application/verify-otp' },

  //for media upload,delete
  'POST /application/mediaUpload': { action: 'api/v-1/application/media-upload' },
  'POST /application/deleteFile': { action: 'api/v-1/application/delete-media' },
  'GET /application/document': { action: 'api/v-1/application/documentlist' },
  //for appointment
  'POST /application/bookAppointment': { action: 'api/v-1/application/book-appointment'},

  //for booked appointment
  'POST /application/bookedAppointment': { action: 'api/v-1/application/booked-appointment'},

  //for weekly-availability
  'POST /job/set-weekly-availability': { action: 'api/v-1/job/set-weekly-availability' },

  //for get total hour of week
  'GET /job/get-total-hour-of-week': { action: 'api/v-1/job/get-total-hour-of-week' },
  'GET /job/get-job-suggestion': { action: 'api/v-1/job/job-suggestion' },

  //for job accept decline
  'POST /job/job-accept-decline': { action: 'api/v-1/job/job-accept-decline' },

  //for get weekly availability
  'POST /job/get-weekly-availability': { action: 'api/v-1/job/get-weekly-availability' },

  //for accpted jobs
  'GET /job/get-accepted-job': { action: 'api/v-1/job/get-accepted-job' },
  'POST /job/job-in-out-time': { action: 'api/v-1/job/job-in-out-time' },

  //chats
  'POST /chat/change-device-token-and-type': { action: 'api/v-1/chat/change-device-token-and-type' },
  'POST /chat/chatlist': { action: 'api/v-1/chat/chatlist' },
  'POST /chat/createchat': { action: 'api/v-1/chat/createchat' },
  'GET /chat/leaveroom': { action: 'api/v-1/chat/leaveroom' },
  'GET /subscribeuser1': { action: 'api/v-1/chat/subscribeuser1' },

  //news
  'GET /news/newslist': { action: 'api/v-1/news/newslist' },

  //workplacesafety
  'GET /workplacesafety/workplacesafetylist': { action: 'api/v-1/workplacesafety/workplacesafetylist'},

  //ppe order form
  'POST /ppeform/create': { action: 'api/v-1/ppeorderform/create' },

  //incident form api
  'POST /incident/create': { action: 'api/v-1/incident/create' },
};

var otherRoutes = {
  // Not Secure Views
  '/': { view: 'pages/homepage' },
  // test route
  'GET /email/reset-password/:token/': { action: 'common/reset-password-view', locals: { layout: 'admin/layouts/layout' } },
  'GET /email/confirm': { action: 'common/confirm-email', locals: { layout: 'admin/layouts/layout' } },
  'GET /test-job': { action: 'common/test-job' },
  'GET /test-mail': { action: 'common/test-mail' },
};

function genRoutes(objRoutes) {
  // console.log(objRoutes);
  var prefix = Object.keys(objRoutes);
  let newRoutes = {};
  let routes = {};
  // console.log(prefix);

  for (let i = 0; i < prefix.length; i++) {
    var paths = Object.keys(objRoutes[prefix[i]]);
    // console.log('paths =>', paths);
    paths.forEach((path) => {
      var pathParts = path.split(' ');
      var uri = pathParts.pop();
      var prefixedURI = '';
      var newPath = '';

      prefixedURI = (prefix[i] ? '/' : '') + prefix[i] + uri;
      pathParts.push(prefixedURI);
      newPath = pathParts.join(' ');
      // construct the new routes
      newRoutes[newPath] = objRoutes[prefix[i]][path];
    });

  }
  routes = newRoutes;
  // console.log('routes => ', routes);
  return routes;
}

// generate route with prefix keys
var routes = genRoutes({
  '': otherRoutes,
  'admin': adminRoutes,
  'api/v-1': apiV1,
});

// assigning generated route
module.exports.routes = routes;
