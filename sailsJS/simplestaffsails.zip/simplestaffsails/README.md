redis-server --daemonize yes
NODE_ENV=development node app.js
NODE_ENV=production node app.js
sails_hooks__grunt=false NODE_ENV=production node app.js

"hooks": {
    "grunt": false
},
"paths": {
    "public": "assets"
},

# Create User
use sails1demo
db.createUser(
   {
     user: "sails1demo",
     pwd: "sails1demo123",
     roles: [ "readWrite", "dbAdmin" ]
   }
)

git init .
git remote add -t \* -f origin git@192.168.0.77:nilesh/SimpleStaffSails.git
git checkout -f master

# If got error related to ruby install
sudo apt install ruby-full rubygems autogen autoconf libtool make
sudo gem install sass

# for grunt error
sudo gem install sass
# if still issue try
sudo gem install clean

npm install grunt-sails-linker --save-dev --save-exact

grunt buildProd
grunt buildProd --build=prod --force

# to create ADMIN user
# password is 123546
=> type 'sails console' then paste this line
=> Admin.create({firstName: 'Super', lastName: 'Admin',email:'admin@admin.com',password:'$2a$10$4Nc8PvwLgiJWcE4mcibv9uIpdlz7yYbu2wkpQXkdyhFbjzlwZOYBS'}).fetch().exec(console.log)

#to start job
=> node worker.js
# to start radis server
=> redis-server --daemonize yes

nodemon --ignore 'assets/swagger/*'

npm config get prefix

# for install grunt
sudo npm install -g grunt
#for install sass
sudo npm install -g sass
sudo npm install -g node-sass
#for permision
sudo chown -R $(whoami) $(npm config get prefix)/{lib/node_modules,bin,share}
sudo chown -R $USER:$GROUP ~/.npm
sudo chown -R $USER:$GROUP ~/.config

#remove cache for npm
sudo npm cache clean -f

#remove node modules
rm -rf /usr/local/lib/node_modules
sudo rm -rf /usr/local/lib/node_modules

#follow this link for knex update table
http://perkframework.com/v1/guides/database-migrations-knex.html

sailsrc := production setting
{
  "hooks": {
    "grunt": false
  },
  "paths": {
    "public": "assets"
  },
  "generators": {
    "modules": {}
  },
  "_generatedWith": {
    "sails": "1.1.0",
    "sails-generate": "1.16.0"
  }
}



# Git pull production

cd /var/www/html/SimpleStaffSails
run on server
NODE_ENV=staging pm2 start app.js
NODE_ENV=staging pm2 start app.js

folder contain db file import it 

