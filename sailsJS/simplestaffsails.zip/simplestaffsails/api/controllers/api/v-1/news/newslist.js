module.exports = {
  friendlyName: 'Chatlist',

  description: 'Chatlist chatindividual.',

  inputs: {},

  exits: {},

  fn: async function(inputs, exits) {

    let individualChatPerPageLimit = 10;
    let perPage = inputs.perPage || individualChatPerPageLimit;
    let page = inputs.page + 1 || 1;
    var news = await News.find();
    console.log('news',news);

    let meta = await sails.helpers.pagination.with({
      page: page,
      perPage: perPage,
      // nativeQuery: news,
      model: 'news',
    });
    exits.success({ result: news ,meta: meta});
  },
};
