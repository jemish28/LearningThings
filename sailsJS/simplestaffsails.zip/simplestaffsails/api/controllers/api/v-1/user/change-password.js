module.exports = {


  friendlyName: 'Change password',

  description: '',

  inputs: {
    oldPassword: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 6,
      description: 'The unencrypted password to use for the new account.'
    },
    newPassword: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 6,
      description: 'The unencrypted password to use for the new account.'
    },
  },
  exits: {
    success: {},
    invalid: {}
  },

  fn: async function (inputs, exits) {

    let newPassword = inputs.newPassword;

    var user = await User.findOne({
      id: this.req.userId,
    });

    if (!user) {
      return this.res.badRequest({ message: sails.__('User not found') });
    }

    await sails.helpers.passwords.checkPassword(inputs.oldPassword, user.password)
      .tolerate('incorrect', () => {
        return this.res.badRequest({ message: sails.__('Old password is invalid') });
      });


    if (inputs.newPassword) {
      newPassword = await sails.helpers.passwords.hashPassword(inputs.newPassword);
    }

    let passwordUser = {
      password: newPassword,
    };
    var updatePassword = await User.update({
      id: this.req.userId
    }).set(passwordUser).fetch();

    if (updatePassword) {
      return exits.success({
        message: sails.__('Password change successfully, please login in application')
      });
    }
  }
};
