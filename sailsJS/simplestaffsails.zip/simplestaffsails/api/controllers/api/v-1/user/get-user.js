module.exports = {
  friendlyName: 'Login',

  exits: {},

  fn: async function (inputs, exits) {
    console.log('this.req.userId->', this.req.userId);
    var user = await User.findOne({
      id: this.req.userId,
    });

    // If there was no matching user, respond thru the "badCombo" exit.
    if (!user) {
      return this.res.badRequest({ message: sails.__('User not found') });
    }

    var application = await Application.findOne({
      userId: user.id,
    }).populate('applicationMedias');

    // this.req.session.userId = user.id;
    let documents = sails.config.custom.documents;
    var baseurl = sails.config.custom.mediaDisplayPath + user.id + documents;

    if (application) {
      user.application = application;
      for (var i = 0; i < application.applicationMedias.length; i++) {
        application.applicationMedias[i].media = baseurl + application.applicationMedias[i].media;
      }
    } else {
      user.application = {};
    }

    var data = user;
    exits.success({
      data,
      message: sails.__('Get data successfully'),
    });
  }

};
