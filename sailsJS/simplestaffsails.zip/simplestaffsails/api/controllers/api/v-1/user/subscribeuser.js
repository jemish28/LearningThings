module.exports = {
  friendlyName: 'Subscribeuser',

  description: 'Subscribeuser user.',

  inputs: {
    id: {
      type: 'number',
      //  required: true,
      description: 'Userid',
    },
  },

  exits: {},

  fn: async function(inputs, exits) {
    // let socketId = sails.sockets.getId(this.req.userId);
    // console.log('socketId',socketId);
    // await User.update({ id: inputs.id }).set({ socketId: socketId, userStatus: 'online' });



    let onlineUser = await User.find({
      id: this.req.userId,
    });

    console.log('onlineUser[0].id',onlineUser[0].id);

    User.subscribe(this.req, [this.req.userId]);

    // User.publish(_.map(onlineUser, 'id'), {
    //   verb: 'connectUser',
    //   data: this.req.userId,
    // });
    console.log('ss');
    console.log('sails',sails.__('subscribe user successfully'));
    exits.success({ message: sails.__('subscribe user successfully') });
  },
};
