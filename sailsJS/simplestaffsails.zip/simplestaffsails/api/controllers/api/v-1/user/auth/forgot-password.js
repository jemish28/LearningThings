module.exports = {


  friendlyName: 'Forgot password',


  description: '',


  inputs: {
    email: {
      required: true,
      type: 'string',
      isEmail: true,
      description: 'The email address for the new account, e.g. m@example.com.',
      extendedDescription: 'Must be a valid email address.',
    },
  },


  exits: { success: {} },


  fn: async function (inputs,exits) {

    var resetPasswordToken = sails.helpers.strings.random();

    await User.update({
      email: inputs.email
    })
      .set({ resetPasswordToken });

    await sails.helpers.sendEmail.with({
      to: inputs.email,
      subject: 'Reset Your Password',
      template: 'forgot-password',
      layout: 'layout-email',
      typeOfSend: 'queue', // 'now', 'queue', 'preview'
      templateData: {
        email: inputs.email,
        id: this.req.userId,
        token: resetPasswordToken
      }
    });

    return exits.success({
      message: sails.__('Mail has been sent , check your mail')
    });

  }
};
