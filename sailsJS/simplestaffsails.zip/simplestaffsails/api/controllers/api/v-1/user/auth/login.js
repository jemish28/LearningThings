module.exports = {
  friendlyName: 'Login',

  inputs: {
    email: {
      description: 'The email to try in this attempt, e.g. "irl@example.com".',
      type: 'string',
      required: true
    },
    password: {
      description: 'The unencrypted password to try in this attempt, e.g. "passwordlol".',
      type: 'string',
      required: true
    },
  },
  exits: {},

  fn: async function (inputs, exits) {
    var user = await User.findOne({
      email: inputs.email.toLowerCase(),
    });

    // If there was no matching user, respond thru the "badCombo" exit.
    if (!user) {
      return this.res.badRequest({ message: sails.__('User not found') });
    }

    // If the password doesn't match, then also exit thru "badCombo".
    await sails.helpers.passwords.checkPassword(inputs.password, user.password)
      .tolerate('incorrect', () => {
        return this.res.badRequest({ message: sails.__('Invalid password') });
      });
    //profile image path
    let documents = sails.config.custom.documents;
    var baseurl = sails.config.custom.mediaDisplayPath + user.id + documents;
    var baseurlforProfileImage = sails.config.custom.mediaDisplayPath + user.id + documents;
    if(user.profileImage){
      user.profileImage = baseurlforProfileImage + user.profileImage;
    } else {
      user.profileImage = null;
    }

    var application = await Application.findOne({
      userId: user.id,
    }).populate('applicationMedias');

    // this.req.session.userId = user.id;
		if(application.haveYouEverWorkForThisCompany==false && application.eligibleToWorkInUs==true && application.haveYouEverBeenConvicatedOfFalony==true)
		{
				if (application) {
					user.application = application;
					application.profileImage = baseurlforProfileImage + application.profileImage;
					for (var i = 0; i < application.applicationMedias.length; i++) {
						application.applicationMedias[i].media = baseurl + application.applicationMedias[i].media;
					}
				} else {
					// application.profileImage = null;
					user.application = {};
				}

				var data = user;
				return exits.success({
					data,
					status:true,
					token: jwToken.issue({
						id: user.id,
					}),
					message: sails.__('Login successfully'),
				});
		}
		else
		{
			return exits.success({
				status:false,
				message: sails.__('Login Failed'),
			});
		}
  }
};
