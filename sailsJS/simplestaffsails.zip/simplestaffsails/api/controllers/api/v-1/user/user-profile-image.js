module.exports = {


  friendlyName: 'Profile image',


  description: '',


  inputs: {
    media: {
      type: 'string',
    },
  },

  exits: {},

  fn: async function (inputs, exits) {
    let file = this.req.file('media');

    let documents = sails.config.custom.documents;
    let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

    if (file._files.length === 0) {
      file.upload({
        noop: true,
      });
    }

    let fileName = await sails.helpers.fileUploadHelper.with({
      name: file,
      media: path,
    });

    let updateProfile = { profileImage: fileName.fileName };
   // console.log('this.req.userId', this.req.userId);
    var updatedUser = await User.update({
      id: this.req.userId
    }).set(updateProfile).fetch();
    var baseurl = sails.config.custom.mediaDisplayPath + this.req.userId + documents;
    updatedUser[0].profileImage = baseurl + updatedUser[0].profileImage;
    return exits.success({
      message: 'Profile image uploaded successfully',
      data: updatedUser[0].profileImage,
    });

  }
};
