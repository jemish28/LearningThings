module.exports = {

  friendlyName: 'Logout',

  description: 'Logout auth.',

  inputs: {
    id:{
      type:'number'
    }
  },

  exits: {},

  fn: async function (inputs, exits) {
    var userId = inputs.id;
    console.log('inputs.id',inputs.id);
    var customerRecord = await User.findOne({ id: userId });
    console.log('customerRecord',customerRecord);
    if(customerRecord.devicetype !== '' && customerRecord.devicetoken !== '' && customerRecord.snsendpointarn !== ''){
      await User.update({ id: userId }).set({ devicetype: '', devicetoken: '', snsendpointarn: '' });
      await sails.helpers.push.deleteArn(customerRecord.snsendpointarn);
    }
    return exits.success({
      status: true
    });
  }
};
