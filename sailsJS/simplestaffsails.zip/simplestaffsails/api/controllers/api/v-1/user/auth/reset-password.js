module.exports = {
  friendlyName: 'Update',
  description: 'Update user.',
  inputs: {
    token: {
      type: 'string',
      description: 'The confirmation token from the email.',
      example: '4-32fad81jdaf$329'
    },
    password: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 6,
      description: 'The unencrypted password to use for the new account.'
    },
  },

  exits: {
    success: {
      viewTemplatePath: 'reset-password-response',
    },
    invalid: {
      viewTemplatePath: 'reset-password-link-expired',
    }
  },


  fn: async function (inputs, exits) {

    let tokenResult = await User.findOne({ resetPasswordToken: inputs.token });

    if (!tokenResult) {
      return exits.invalid({
        statusCod: 400,
        message: 'This reset password link is expired, please request for new one.',
      });
    }



    let passwordUser = {
      password: inputs.password,
      resetPasswordToken: ''
    };

    if (inputs.password) {
      passwordUser.password = await sails.helpers.passwords.hashPassword(inputs.password);
    }

    var updatedUser = await User.update({
      resetPasswordToken: inputs.token
    }).set(passwordUser).fetch();

    return exits.success({
      message:sails.__('Password update successfully, please login in application')
    });
  }


};
