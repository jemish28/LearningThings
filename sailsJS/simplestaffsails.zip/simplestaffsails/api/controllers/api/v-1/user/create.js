module.exports = {


  friendlyName: 'Create',

  description: 'Create User.',

  inputs: {
    userName: {
      type: 'string',
    //  required: true,
    },
    email: {
      required: true,
      unique: true,
      type: 'string',
      isEmail: true,
      description: 'The email address for the new account, e.g. m@example.com.',
      extendedDescription: 'Must be a valid email address.',
    },
    password: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 6,
      example: 'passwordlol',
      description: 'The unencrypted password to use for the new account.'
    },
    timeZone: {
      required: true,
      type: 'string',
    },
  },

  exits: {
    success: {
      description: 'New user account was created successfully.'
    },

    invalid: {
      responseType: 'badRequest',
      description: 'The provided fullName, password and/or email address are invalid.',
      extendedDescription: 'If this request was sent from a graphical user interface, the request ' +
        'parameters should have been validated/coerced _before_ they were sent.'
    },
  },

  fn: async function (inputs, exits) {
    var userRecord = await User.create({
      userName: inputs.userName,
      email: inputs.email,
      password: await sails.helpers.passwords.hashPassword(inputs.password),
      timeZone: inputs.timeZone
    })
      .intercept('E_UNIQUE', () => {
        return exits.invalid({ message: sails.__('User already exist') });
      })
      .fetch();

    if (!userRecord) {
      return exits.invalid({ message: sails.__('User not create') });
    }

		  //create notification
			notificationObj = {
				sender_id: userRecord.id,
				notification_type: 'CreatedNewUserByUser',
				notification_data: userRecord.id,
				sender_type: 'app',
				receiver_type: 'admin'
			};

			notificationResult = await Notifications.create(notificationObj).fetch();


    return exits.success({
      data: userRecord,
      token: jwToken.issue({
        id: userRecord.id,
      }),
      message: sails.__('User create successfully'),
    });
  }

};
