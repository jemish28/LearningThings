module.exports = {


  friendlyName: 'Gethour of week',


  description: '',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs, exits) {

    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });

    let fmtForDate = 'YYYY-MM-DD';


    var fromDate = sails.moment().day(0).format('YYYY-MM-DD HH:mm:ss');
    var momentObj1 = sails.moment.tz(fromDate, fmtForDate, user.timeZone);//utc to user time zone convert
    var fromDate2 = sails.moment(momentObj1).format('YYYY-MM-DD HH:mm:ss');
    console.log('fromDate2', momentObj1);

    var toDate = sails.moment().day(+6).format('YYYY-MM-DD HH:mm:ss');
    var momentObj2 = sails.moment.tz(toDate, fmtForDate, user.timeZone);//utc to user time zone convert
    var toDate2 = sails.moment(momentObj2).format('YYYY-MM-DD HH:mm:ss');
    console.log('toDate2', momentObj2);

    let dataOfDate = await WeeklyAvailability.find({
      date: { '>=': fromDate2, '<=': toDate2 },
      userId: this.req.userId
    });

    let hours = [];
    for (var i = 0; i < dataOfDate.length; i++) {
      hours.push(dataOfDate[i].hour);
    }

    //total hour of week
    const totalDurations = hours.slice(1)
      .reduce((prev, cur) => sails.moment.duration(cur).add(prev),
        sails.moment.duration(hours[0]));
    let totalHour = `${sails.moment.utc(totalDurations.asMilliseconds()).format('HH:mm')}`;
    console.log('Total time is', totalHour);

    return exits.success({
      message: sails.__('Total hour of week get successfully'),
      data: totalHour
    });
  }
};
