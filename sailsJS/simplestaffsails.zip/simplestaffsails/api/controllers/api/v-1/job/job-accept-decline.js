module.exports = {


  friendlyName: 'Job accept decline',

  description: '',

  inputs: {
    jobId: {
      type: 'number',
      required: true,
    },
    accept: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    invalid: {
      // statusCode: 409,
      // description: 'Invalid request'
    },
  },

  fn: async function (inputs, exits) {
    var jobData = await Job.findOne({ id: inputs.jobId });
    if (!jobData) {
      return exits.invalid({
        message: sails.__('Invalid jobId')
      });
    }

    console.log('user id', this.req.userId);
    var status = inputs.accept;
    var result = await Jobofuser.find({
      jobId: inputs.jobId,
      userId: this.req.userId,
    });

    if (result.length) {
      if (result[0].isproceed) {
        return exits.invalid({
          message: sails.__('User already proceed this job')
        });
      }
    } else {
      return exits.invalid({
        message: sails.__('No records found')
      });
    }

    var userlimit = jobData.userlimit;
    if (jobData.isAll) {
      userlimit = (userlimit > 0 ? userlimit - 1 : 0);

      if (jobData.userlimit === 0) {
        await Jobofuser.destroy({
          jobId: inputs.jobId,
          isproceed: false
        }).fetch();
        return exits.invalid({
          message: sails.__('Sorry you are late Job limit is over here')
        });
      }
    }

    console.log('result', result);
    if (status === 'true') {
      if (result.length > 0) {
        console.log('abc');
        await Jobofuser.update({
          userId: this.req.userId,
          jobId: result[0].jobId
        }).set({
          status: 'accepted',
          isproceed: true
        });
      } else {
        await Jobofuser.create({
          userId: this.req.userId,
          jobId: inputs.jobId,
          status: 'accepted',
          isproceed: true
        });
      }

      await Job.update({ id: inputs.jobId }).set({ userlimit: userlimit }).fetch();
      return exits.success({
        message: sails.__('Job accept successfully')
      });

    } else if (status === 'false') {

      if (result) {
        await Jobofuser.update({
          userId: this.req.userId,
          jobId: result[0].jobId
        }).set({
          status: 'decline',
          isproceed: true
        });
      } else {
        await Jobofuser.create({
          userId: this.req.userId,
          jobId: inputs.jobId,
          status: 'decline',
          isproceed: true
        });
      }
      return exits.success({
        message: sails.__('Job decline successfully')
      });

    } else {
      return exits.invalid({
        message: 'invalid'
      });
    }
  }
};
