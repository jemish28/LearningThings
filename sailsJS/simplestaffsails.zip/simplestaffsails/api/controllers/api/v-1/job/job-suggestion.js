module.exports = {


  friendlyName: 'Job suggestion',


  description: '',


  inputs: {},


  exits: {},


  fn: async function (inputs, exits) {
    var assignJobList = await Jobofuser.find({
      status: 'assign',
      userId: this.req.userId
    });
    var jobIds = [];
    for (var k = 0; k < assignJobList.length; k++) {
      jobId = assignJobList[k].jobId;
      jobIds.push(jobId);
    }
    console.log('jobIds',jobIds);
    var jobList = await Job.find({
      id:jobIds,
      // or: [
      //   { isAll: 1 },
      //   { isAll: 0 },
      // ]
    }).populate('JobMedias');

    var documents = sails.config.custom.jobMedia;
    var path = sails.config.custom.mediaDisplayPath + documents;

    if (jobList) {
      jobList = jobList;
      for (var i = 0; i < jobList.length; i++) {
        for (var j = 0; j < jobList[i].JobMedias.length; j++) {
          jobList[i].JobMedias[j].media = path + jobList[i].JobMedias[j].media;
        }
      }
    } else {
      jobList = {};
    }
    console.log('jobList', jobList);
    return exits.success({
      message: sails.__('Job suggestion list get successfully'),
      data: jobList
    });
  }
};
