module.exports = {


  friendlyName: 'Job in out time',


  description: '',

  inputs: {
    jobId: {
      type: 'number',
      required: true,
    },
    JobInTime: {
      type: 'ref',
      required: true,
    },
    JobOutTime: {
      type: 'ref',
      required: true,
    },
    Longitude:{
      type: 'string',
      required: true,
    },
    Latitude:{
      type: 'string',
      required: true,
    },
    Location:{
      type: 'string',
      required: true,
    },
    timeOfJob: {
      type: 'ref',
      //  required: true,
		},
		desc: {
			type: 'string',
		},
		status: {
			type: 'string',
		}
  },

  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },


  fn: async function (inputs, exits) {

    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });

    var fmtForDate = 'DD-MM-YYYY h:mm:ss A';


    var JobInTime = inputs.JobInTime;
    var JobOutTime = inputs.JobOutTime;

    var isValidForInDate = sails.moment(JobInTime, fmtForDate, true).isValid();

    var isValidForOutDate = sails.moment(JobOutTime, fmtForDate, true).isValid();

    if (!isValidForInDate) { // Check valid date format
      return exits.invalid({
        message: sails.__('Please enter valid date format')
      });
    }
    if (!isValidForOutDate) { // Check valid date format
      return exits.invalid({
        message: sails.__('Please enter valid date format')
      });
    }


    var momentObjforIn = sails.moment.tz(JobInTime, fmtForDate, user.timeZone);
    var momentObjforOut = sails.moment.tz(JobOutTime, fmtForDate, user.timeZone);


    momentObjforIn = momentObjforIn.utc(); //Convert to utc
    momentObjforOut = momentObjforOut.utc(); //Convert to utc


    var jobInTime = sails.moment(momentObjforIn).format('YYYY-MM-DD HH:mm:ss');
    var jobOutTime = sails.moment(momentObjforOut).format('YYYY-MM-DD HH:mm:ss');

    var now = sails.moment(jobInTime);
    var end = sails.moment(jobOutTime);
    var duration = sails.moment.duration(end.diff(now));
    var days = duration.asSeconds();
    var timeInMinutes = days / 60;

    var isAfter = momentObjforIn.isAfter();

    var isAfterforOutTime = momentObjforOut.isAfter(momentObjforIn);
    if (!isAfterforOutTime) { //Check future date for out time
      return exits.invalid({
        message: sails.__('Job out time should be greater than job in time')
      });
    }
    console.log('timeInMinutes', timeInMinutes);
    console.log('inputs.Longitude',inputs.Longitude);
    console.log('inputs.Latitude',inputs.Latitude);
    console.log('inputs.Location',inputs.Location);
    let objJobInOutTime = {
      timeOfJob: timeInMinutes,
      jobId: inputs.jobId,
      jobInTime: jobInTime,
      jobOutTime: jobOutTime,
      userId:this.req.userId,
      longitude:inputs.Longitude,
      latitude:inputs.Latitude,
			location:inputs.Location,
			desc: inputs.desc,
			status :'pending'
    };

    let objJobInOutTimes = await JobInAndJobOut.create(objJobInOutTime).fetch();

    let jobInTimeObj = sails.moment.tz(objJobInOutTimes.jobInTime, fmtForDate, user.timeZone);
    objJobInOutTimes.jobInTime = sails.moment(jobInTimeObj).format('DD-MM-YYYY h:mm:ss A');
    let jobOutTimeObj = sails.moment.tz(objJobInOutTimes.jobOutTime, fmtForDate, user.timeZone);
    objJobInOutTimes.jobOutTime = sails.moment(jobOutTimeObj).format('DD-MM-YYYY h:mm:ss A');

    objJobInOutTimes.timeOfJob = objJobInOutTimes.timeOfJob + ' ' + 'minutes';

    return exits.success({
      message: sails.__('Job time updated successfully'),
      data: objJobInOutTimes
    });
  }
};
