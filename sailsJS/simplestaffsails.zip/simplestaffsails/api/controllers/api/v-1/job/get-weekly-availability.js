module.exports = {


  friendlyName: 'Get weekly availability',


  description: '',

  inputs: {
    year: {
      type: 'number',
      required: true,
    },
  },

  exits: {},

  fn: async function (inputs, exits) {

    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });


    let months = sails.moment.months();
    let monthArr = [];
    months.map(month => {
      let objMonth = {
        monthName: month.substring(0, 3),
        total: 0,
      };
      monthArr.push(objMonth);
    });

    let totalHoursOfMonth = [];


    let totalHoursOfMonthSql = `select concat(date) as date ,SEC_TO_TIME(SUM(TIME_TO_SEC(hour))) as totalhour  FROM weeklyavailability where userId = ${this.req.userId} and date like '%${inputs.year}%' GROUP BY YEAR(date), MONTH(date) ,date`;

    totalHoursOfMonth = await sails.sendNativeQuery(totalHoursOfMonthSql);

    totalHoursOfMonth = totalHoursOfMonth.rows;

    function groupByMonth(data) {
      var month1 = new Array();
      month1[0] = 'January';
      month1[1] = 'February';
      month1[2] = 'March';
      month1[3] = 'April';
      month1[4] = 'May';
      month1[5] = 'June';
      month1[6] = 'July';
      month1[7] = 'August';
      month1[8] = 'September';
      month1[9] = 'October';
      month1[10] = 'November';
      month1[11] = 'December';
      var months = {};
      for (var i = 0; i < data.length; i++) {
        var obj = data[i];
        var date = new Date(obj.date);
        var month = month1[date.getMonth()];
        if (months[month]) {
          months[month].push(obj);  // already have a list- append to it
        }
        else {
          months[month] = [obj]; // no list for this month yet - create a new one
        }
      }
      return months;

    }
    result = groupByMonth(totalHoursOfMonth);

    let allData = JSON.parse(JSON.stringify(result));


    for (const key in allData) {
      const element = allData[key];
      for (const key in element) {
        if (element.hasOwnProperty(key)) {
          const element2 = element[key];
          element2.date;
          var momentObj = sails.moment.tz(element2.date, user.timeZone);
          element2.date = sails.moment(momentObj).format('DD-MM-YYYY');
        }
      }
    }
    return exits.success({
      message: sails.__('Get weekly availability successfully'),
      data: allData
    });
  }
};
