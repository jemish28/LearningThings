module.exports = {

  friendlyName: 'Get accepted job',

  description: '',

  inputs: {},

  exits: {},

  fn: async function (inputs, exits) {

    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });

    console.log('user', user);

    var objJobofuser = await Jobofuser.find({
      where: {
        userId: this.req.userId,
        status:'accepted'
      },
      select: ['jobId','userId']
    });
    console.log('objJobofuser',objJobofuser);
    var jobIdList = [];
    for(var l=0; l<objJobofuser.length; l++){
      jobId = objJobofuser[l].jobId;
      jobIdList.push(jobId);
    }
    var jobList = await Job.find({
      id:jobIdList
    }).populate(['JobMedias', 'JobTotalTime']);
    console.log('jobList',jobList);

    let documents = sails.config.custom.jobMedia;
    let path = sails.config.custom.mediaDisplayPath + documents;
    var fmtForDate = 'DD-MM-YYYY h:mm A';
    if (jobList) {
      jobList = jobList;
      for (var i = 0; i < jobList.length; i++) {
        for (var j = 0; j < jobList[i].JobMedias.length; j++) {
          jobList[i].JobMedias[j].media = path + jobList[i].JobMedias[j].media;
        }
        for (var k = i; k < jobList[i].JobTotalTime.length; k++) {
          let totalMinute = jobList[i].JobTotalTime[k].timeOfJob;
          var hours = Math.floor(totalMinute / 60);
          var minutes = totalMinute % 60;
          jobList[i].JobTotalTime[k].timeOfJob = hours + ':' + minutes;
          let jobInTimeObj = sails.moment.tz(jobList[i].JobTotalTime[k].jobInTime, fmtForDate, user.timeZone);
          jobList[i].JobTotalTime[k].jobInTime = sails.moment(jobInTimeObj).format('DD-MM-YYYY h:mm A');
          let jobOutTimeObj = sails.moment.tz(jobList[i].JobTotalTime[k].jobOutTime, fmtForDate, user.timeZone);
          jobList[i].JobTotalTime[k].jobOutTime = sails.moment(jobOutTimeObj).format('DD-MM-YYYY h:mm A');
        }
      }
    } else {
      jobList = {};
    }

    return exits.success({
      message: sails.__('Get accept job successfully'),
      data: jobList,
    });
  }
};
