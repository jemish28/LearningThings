module.exports = {


  friendlyName: 'Weekly availability',

  description: '',

  inputs: {
    date: {
      type: 'ref',
      // required: true,
    },
    // 'date': { type: 'ref', columnType: 'date' },
    hour: {
      type: 'ref',
      //  required: true,
    },
    dateObj: {
      type: 'ref',
      //  required: true,
    },
  },

  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },
  fn: async function (inputs, exits) {
    let dateObjArr = inputs.dateObj;
    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });

    var fmtForDate = 'DD-MM-YYYY';
    // var fmtForHour = 'HH:mm';

    // var dateForAvailability = inputs.date;

    // var hourForAvailability = inputs.hour;
    var isValidForDate;
    var momentObj;
    var mm;
    var weeklyAvailabilityData;
    let objWeeklyAvailability;
    var weeklyAvailability = [];
    for (var i = 0; i < inputs.dateObj.length; i++) {
      weeklyAvailability.push(inputs.dateObj[i].date,inputs.dateObj[i].isselected);
      isValidForDate = sails.moment(inputs.dateObj[i].date, fmtForDate, true).isValid();
      momentObj = sails.moment.tz(inputs.dateObj[i].date, fmtForDate, user.timeZone);
      // console.log('momentObj for without utc', momentObj);
    //  momentObj = momentObj.utc();
      //console.log('momentObj for with utc', momentObj);
      mm = sails.moment(momentObj).format('YYYY-MM-DD');
    //  console.log('momentObj for with mm', mm);
      weeklyAvailabilityData = await WeeklyAvailability.find({
        userId: this.req.userId,
        date: mm,
      });
      objWeeklyAvailability = {
        userId: this.req.userId,
        date: mm,
        status: inputs.dateObj[i].isselected
      };
      //console.log('objWeeklyAvailability',objWeeklyAvailability);
      // console.log('weeklyAvailabilityData', weeklyAvailabilityData);
      if (weeklyAvailabilityData.length === 0) {
        // console.log('create');
        await WeeklyAvailability.create(objWeeklyAvailability).fetch();
      } else {
        // console.log('update');
        await WeeklyAvailability.update({ userId: this.req.userId, date: mm }).set(objWeeklyAvailability).fetch();
      }
    }

    if (!isValidForDate) { // Check valid date format
      return exits.invalid({
        message: sails.config.custom.messages.job.dateNotValidFormat
      });
    }

    return exits.success({
      message: sails.__('Week availability date added successfully'),
      data: dateObjArr
    });
  }
};
