module.exports = {
  friendlyName: 'Subscribeuser',

  description: 'Subscribeuser user.',

  inputs: {

    id: {
      description: 'The email to try in this attempt, e.g. "irl@example.com".',
      type: 'string',
      // required: true
    },
  },

  exits: {},

  fn: async function (inputs, exits) {
    console.log('subscrbe inputs.id', inputs.id);
    let socketId = sails.sockets.getId(this.req);
    console.log('socketId', socketId);
    // await User.update({ id: inputs.id }).set({ socketId: socketId, userStatus: 'online' });


    // let onlineUser = await User.find({
    //   id: this.req.userId,
    // });
    User.subscribe(this.req, [inputs.id]);
    // User.publish(_.map(onlineUser, 'id'), {
    //   verb: 'connectUser',
    //   data: inputs.id,
    // });
    exits.success({ message: 'subscribe user' });
  },
};
