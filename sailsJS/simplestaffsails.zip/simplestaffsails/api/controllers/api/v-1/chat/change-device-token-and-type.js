module.exports = {
  friendlyName: 'Change device token and type',
  description: '',
  inputs: {
    // id: {
    //     type: "number",
    //     required: true,
    //     description: "User Id"
    // },
    devicetype: {
      type: 'string',
      required: true,
      isIn: ['iOS', 'Android'],
      description: 'User device type',
    },
    devicetoken: {
      type: 'string',
      required: true,
      description: 'User device token',
    },
  },
  exits: {},
  fn: async function(inputs, exits) {
    var req = this.req;
    var res = this.res;
    inputs.id = this.req.userId;

    var userDataObj = await User.findOne({ id: inputs.id });
    if (!userDataObj) {
      return res.notFound({ message: sails.__('User record not found') });
    }

    // delete other user endpoint arn with same token
    var usersWithSameTokenRes = await User.find({ devicetoken: inputs.devicetoken, id: { '!=': inputs.id } });
    var usersWithSameTokenResLength = usersWithSameTokenRes.length;
    if (usersWithSameTokenResLength) {
      for (var i = 0; i < usersWithSameTokenResLength; i++) {
        var usersWithSameToken = usersWithSameTokenRes[i];
        if (usersWithSameToken.snsendpointarn) {
          await sails.helpers.push.topicUnsubscribe(usersWithSameToken.snstopicscriptionarn);
          await sails.helpers.push.deleteArn(usersWithSameToken.snsendpointarn);
        }
      }
      var nullDeviceTokenDetails = { devicetoken: '', snsendpointarn: '', snstopicscriptionarn: '' };
      await User.update({ devicetoken: inputs.devicetoken }).set(nullDeviceTokenDetails);
    }

    if (userDataObj.snsendpointarn && userDataObj.devicetoken !== inputs.devicetoken) {
      /* Replace with new token */
      console.log('/* Replace with new token */');
      await sails.helpers.push.topicUnsubscribe(userDataObj.snstopicscriptionarn);
      await sails.helpers.push.deleteArn(userDataObj.snsendpointarn);

      // createPlatformEndpoint
      var createArnRes = await sails.helpers.push.createArn('user', inputs.devicetype, inputs.devicetoken, userDataObj.email);
      var endpointArn = createArnRes.endpointArn;

      // subscribe to endpoint arn
      var snsTopicScriptionArn = '';
      var topicSubscribeRes = await sails.helpers.push.topicSubscribe('user', inputs.devicetype, endpointArn);
      if (topicSubscribeRes.status === true && topicSubscribeRes.data) {
        snsTopicScriptionArn = topicSubscribeRes.data.SubscriptionArn;
      }

      // update token & end point
      await User.update({ id: inputs.id }, { snsendpointarn: endpointArn, snstopicscriptionarn: snsTopicScriptionArn, devicetype: inputs.devicetype, devicetoken: inputs.devicetoken }).fetch();
    } else if (!userDataObj.snsendpointarn) {
      /* Generate new token */
      console.log('/* Generate new token */');

      // createPlatformEndpoint
      var createArnRes = await sails.helpers.push.createArn('user', inputs.devicetype, inputs.devicetoken, userDataObj.email);
      var endpointArn = createArnRes.endpointArn;

      // subscribe to endpoint arn
      var snsTopicScriptionArn = '';
      var topicSubscribeRes = await sails.helpers.push.topicSubscribe('user', inputs.devicetype, endpointArn);
      if (topicSubscribeRes.status === true && topicSubscribeRes.data) {
        snsTopicScriptionArn = topicSubscribeRes.data.SubscriptionArn;
      }
      console.log('endpointArn',endpointArn);
      // update token & end point
      await User.update({ id: inputs.id }, { snsendpointarn: endpointArn, snstopicscriptionarn: snsTopicScriptionArn, devicetype: inputs.devicetype, devicetoken: inputs.devicetoken }).fetch();
    } else {
      console.log('/* No any need to change with token */');
    }

    return exits.success({
      message: sails.__('Device token changed successfully'),
      // temp: {
      //     usersWithSameTokenRes: usersWithSameTokenRes
      // }
    });
  },
};
