module.exports = {
  friendlyName: 'Createchat',

  description: 'Createchat chatindividual.',

  inputs: {
    userId: {
      type: 'number',
    //  required: true,
    },
    fromUserId: {
      type: 'number',
      // required: true,
    },
    mediaType: {
      type: 'string',
    //  required: true,
    },
    media: {
      type: 'string',
    },
    objectId: {
      type: 'number',
    },
  },

  exits: {},

  fn: async function(inputs, exits) {
    console.log('inputs.fromUserId',inputs.fromUserId);
    //var userId = this.req.userId;
    var userId = inputs.fromUserId;
    var adminId = 1;
   // console.log('admin', 1);

    let chatsResult;
    let chatObj;
    if (inputs.mediaType !== 'text') {
      let chatMedia = sails.config.custom.chat;
      let path = sails.config.custom.mediaUploadPath + chatMedia;
      let file;
      file = this.req.file('media');
      if (file._files.length === 0) {
        file.upload({
          noop: true,
        });
      }
      let fileName = await sails.helpers.fileUploadHelper.with({
        name: file,
        media: path,
      });

      chatObj = {
        mediaType: 'image',
        fromUserId: inputs.fromUserId,
        userId: adminId,
        mediaContent: fileName.fileName,
      };
    } else {
      chatObj = {
        mediaType: 'text',
        fromUserId: inputs.fromUserId,
        userId: adminId,
        mediaContent: inputs.media,
      };
    }

		chatsResult = await Chats.create(chatObj).fetch();

	  //create notification
		notificationObj = {
			sender_id: inputs.fromUserId,
			reciever_id: adminId,
			notification_type: 'CreatedChatByUser',
			notification_data: chatsResult.id,
			sender_type: 'app',
			receiver_type: 'admin'
		};

		notificationResult = await Notifications.create(notificationObj).fetch();

    if (chatsResult.mediaType === 'text') {
      chatsResult.mediaContent = chatsResult.mediaContent;
    } else {
      let chat = sails.config.custom.chat;
      let mediaPath = sails.config.custom.mediaDisplayPath + chat;
      chatsResult.mediaContent = mediaPath + chatsResult.mediaContent;
    }

    console.log('chatsResult for testing',chatsResult);

    Admin.publish([1], {
      verb: 'message',
      data: chatsResult,
    });
    exits.success({
      result: chatsResult,
      message: 'success',
    });
  },
};
