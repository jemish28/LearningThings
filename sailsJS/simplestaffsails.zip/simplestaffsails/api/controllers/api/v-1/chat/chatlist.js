module.exports = {
  friendlyName: 'Chatlist',

  description: 'Chatlist chatindividual.',

  inputs: {
    userId: {
      type: 'number',
      // required: true,
    },
    fromUserId: {
      type: 'number',
      //required: true,
    },
    oldSelectedUserId: {
      type: 'number',
    },
    perPage: {
      type: 'number',
      //required: true,
    },
    page: {
      type: 'number',
      //required: true,
    },
    lastChatId: {
      type: 'number',
      // required: true,
    },
  },

  exits: {},

  fn: async function(inputs, exits) {
    let chatResult = [];
    let individualChatPerPageLimit = 10;
    let perPage = inputs.perPage || individualChatPerPageLimit;
    let page = inputs.page + 1 || 1;

    // if (page === 1) {
    var adminId = 1;
    let socketRoomName = 'chatRoom_' + inputs.fromUserId;
    //let socketRoomName = 'chatRoom_' + inputs.userId + '_' + inputs.fromUserId;
    sails.sockets.join(this.req, socketRoomName);
    let isConnected = await sails.helpers.isConnectedHelper.with({ socketRoomName: socketRoomName });
    console.log('isConnected for user room join', isConnected);
    // if (inputs.oldSelectedUserId) {
    //   let roomNameOld = 'chatRoom_' + inputs.fromUserId + '_' + inputs.oldSelectedUserId;

    //   sails.sockets.leave(this.req, roomNameOld);
    // }

    await Chats.update({
      isRead: false,
      or: [
        { fromUserId: inputs.userId, userId: inputs.fromUserId },
        { fromUserId: inputs.fromUserId, userId: inputs.userId },
      ],
    }).set({ isRead: true });

    let unreadMessageCount = await Chats.count({
      userId: inputs.userId,
      isRead: false,
      chatType: 'individualchat',
    });

    User.publish([inputs.userId], {
      verb: 'unreadMessageCount',
      data: unreadMessageCount,
    });

    let messageResult = await Chats.find({
      where: {
        fromUserId: inputs.userId,
        userId: inputs.userId,
        isRead: true,
        chatType: 'individualchat',
      },
      sort: [{ id: 'DESC' }],
      limit: 1,
    });

    if (messageResult.length > 0) {
      User.publish([inputs.userId], {
        verb: 'individualMessageSeen',
        data: messageResult[0],
      });
    }
    let chat = sails.config.custom.chat;
    let mediaPath = sails.config.custom.mediaDisplayPath + chat;

    let paginationSql;
    let totalRecordSql;

    let sql = `SELECT *,`;

    // sql += await sails.helpers.commonQueryHelper.with({ moduleName: 'user' });

    sql += `CASE
    WHEN mediaType = 'image'
    THEN
    CONCAT ('${mediaPath}',mediaContent)
    ELSE mediaContent
    END
    AS mediacontent1 FROM chats WHERE chatType = 'individualchat' `;

    paginationSql = sql;

    totalRecordSql = sql;

    totalRecordSql += ` AND (userId=${inputs.userId} AND fromUserId=${inputs.fromUserId})
      OR (userId=${inputs.fromUserId} AND fromUserId=${inputs.userId})`;

    paginationSql += ` AND (userId=${inputs.userId} AND fromUserId=${inputs.fromUserId}`;

    if (inputs.lastChatId !== 0) {
      paginationSql += ` AND id<${inputs.lastChatId}`;
    }

    paginationSql += `) OR (userId=${inputs.fromUserId} AND fromUserId=${inputs.userId}`;

    if (inputs.lastChatId !== 0) {
      paginationSql += ` AND id<${inputs.lastChatId}`;
    }

    paginationSql += `) ORDER BY createdAt DESC LIMIT ${perPage}`;

    let sqlOuter = `SELECT * FROM (${paginationSql}) AS chats ORDER BY id`;

    let chatResultQuery = await sails.sendNativeQuery(sqlOuter);

    if (chatResultQuery.rows.length > 0) {
      chatResult = chatResultQuery.rows;
    }

    let meta = await sails.helpers.pagination.with({
      page: page,
      perPage: perPage,
      nativeQuery: totalRecordSql,
      model: 'chats',
    });

    exits.success({ result: chatResult, meta: meta,isConnected:isConnected });
  },
};
