module.exports = {

  friendlyName: 'leave room',

  description: 'send msg from admin.',

  inputs: {
    socketRoomName: {
      type: 'ref',
      //  required: true,
    },
    id: {
      type: 'string',
      //  required: true,
    },
  },
  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {
    console.log('id for check leave room',inputs.id);
    let socketRoomName = 'chatRoom_' + inputs.id;
    console.log('socketRoomName when leave room',socketRoomName);
    sails.sockets.leave(this.req, socketRoomName);
    let isConnected = await sails.helpers.isConnectedHelper.with({ socketRoomName: socketRoomName });
    console.log('room leave isConnected', isConnected);
    exits.success({  message: 'Success' });
    // console.log('username on connect: ', 1);
    // sails.sockets.join(1, 'chat-channel');
    // return res.ok();
  }
};
