module.exports = {
  friendlyName: 'Readmessage',

  description: 'Readmessage chatindividual.',

  inputs: {
    id: {
      type: 'number',
      required: true,
    },
  },

  exits: {},

  fn: async function(inputs, exits) {
    await Chats.update({ isRead: false, fromUserId: inputs.id, userId: this.req.userId }).set({ isRead: true });
    exits.success({ message: sails.config.custom.messages.chat.read });
  },
};
