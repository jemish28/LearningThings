module.exports = {
  friendlyName: 'Usertyping',

  description: 'Usertyping chatindividual.',

  inputs: {
    userId: {
      type: 'number',
      required: true,
    },
    fromUserId: {
      type: 'number',
      required: true,
    },
  },

  exits: {},

  fn: async function(inputs, exits) {
    User.publish(
      [inputs.userId],
      {
        verb: 'userTyping',
        data: inputs.fromUserId,
      },
      this.req
    );
    exits.success({});
  },
};
