module.exports = {
  friendlyName: 'Weekly availability',
  description: '',
  inputs: {
    formObj: {
      type: 'ref'
    },
  },
  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },

  fn: async function (inputs, exits) {
    let userId = {
      userId: this.req.userId,
    };
    console.log('inputs.formObj', inputs.formObj);
    let ppeform = await Ppeform.create(userId).fetch();
    console.log('ppeform id', ppeform.id);
    let ppeOrderFormdata;
    let ppeAllData = [];
    for (var i = 0; i < inputs.formObj.length; i++) {
      objPpeOrderForm = {
        ppeformid: ppeform.id,
        itemname: inputs.formObj[i].itemname,
        quantity: inputs.formObj[i].quantity,
        size: inputs.formObj[i].size
      };
      let ppeFormDataObj = {
        itemname: inputs.formObj[i].itemname,
        quantity: inputs.formObj[i].quantity,
        size: inputs.formObj[i].size
      };
      ppeAllData.push(ppeFormDataObj);
      ppeOrderFormdata = await Ppeformitem.create(objPpeOrderForm).fetch();
    }
    let htmlData = await sails.helpers.ppereport.with({
      template: 'ppereport',
      templateData: {
        ppeAllData: ppeAllData
      }
    });

    // console.log('ppeAllData', ppeAllData);
    // console.log('htmlData', htmlData);

    var fs = require('fs');
    var pdf = require('html-pdf');

    let documents = sails.config.custom.documents;
    let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

    var min = 1;
    var max = 9999999;
    var random = Math.floor(Math.random() * (+max - +min)) + +min;
    var html = htmlData;
    var options = { format: 'Letter' };

    filename = {
      ppeorderform: random + '.pdf'
    };

    var updatedUser = await Ppeform.update({
      id: ppeform.id
    }).set(filename);
    pdf.create(html, options).toFile(path + '/' + random + '.pdf', (err, res) => {
      console.log('res', res);
      if (err) { return console.log(err); }
    });

    return exits.success({
      message: sails.__('Ppe order form data added successfully'),
      //data: dateObjArr
    });
  }
};
