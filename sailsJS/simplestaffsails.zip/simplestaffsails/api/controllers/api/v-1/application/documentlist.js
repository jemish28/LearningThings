module.exports = {
  friendlyName: 'Login',
  inputs: {

  },
  exits: {},

  fn: async function (inputs, exits) {

    var application = await Application.findOne({
      userId: this.req.userId,
    }).populate('applicationMedias');

    // this.req.session.userId = user.id;
    let documents = sails.config.custom.documents;
    var baseurl = sails.config.custom.mediaDisplayPath + this.req.userId + documents;

    if (application) {
      application = application;
      for (var i = 0; i < application.applicationMedias.length; i++) {
        application.applicationMedias[i].media = baseurl + application.applicationMedias[i].media;
      }
    } else {
      application = {};
    }

    var incidentData = await Incident.find({ userId: this.req.userId });
    for (let i = 0; i < incidentData.length; i++) {
      incidentData[i].document = (incidentData[i].document ? baseurl + incidentData[i].document : null);
    }

    var ppeFormData = await Ppeform.find({ userId: this.req.userId }).populate('ppeformitems');
    for (let i = 0; i < ppeFormData.length; i++) {
      ppeFormData[i].ppeorderform = (ppeFormData[i].ppeorderform ? baseurl + ppeFormData[i].ppeorderform : null);
    }

    var data = application;
    exits.success({
      data,
      incidentDoument: incidentData,
      ppeFormData: ppeFormData,
      message: sails.__('Document get successfully'),
    });
  }
};
