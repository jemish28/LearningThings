module.exports = {
  friendlyName: 'Update',
  description: 'Update user.',
  inputs: {
    appointmentDate: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },

  fn: async function (inputs, exits) {

    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });

    // var fmt   = 'DD-MM-YYYY h:mm A';
    var fmt = 'DD-MM-YYYY';
    var appointmentDate = inputs.appointmentDate;

    var isValid = sails.moment(appointmentDate, fmt, true).isValid();

    if (!isValid) { // Check valid date format
      return exits.invalid({
        message: sails.__('Please enter valid date format')
      });
    }

    var momentObj = sails.moment.tz(appointmentDate, fmt, user.timeZone);
    // momentObj = momentObj.utc(); //Convert to utc
    var isAfter = momentObj.isAfter();

    if (!isAfter) { //Check future date
      return exits.invalid({
        message: sails.__('Appointment date should be future date')
      });
    }
    // mm = sails.moment(momentObj).format('YYYY-MM-DD HH:mm:ss');
    mm = sails.moment(momentObj).format('YYYY-MM-DD');
    let objApplicaion = {
      appointmentDate: mm,
      status: 'pending'
    };

    var updatedApplicaion = await Application.update({
      userId: this.req.userId
    }).set(objApplicaion).fetch();

    return exits.success({
      message: sails.__('Appointment book successfully'),
      data: updatedApplicaion[0]
    });
  }
};
