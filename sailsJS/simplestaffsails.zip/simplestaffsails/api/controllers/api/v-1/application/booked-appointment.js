module.exports = {
  friendlyName: 'Update',
  description: 'Update user.',
  inputs: {},
  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },

  fn: async function (inputs, exits) {

    // let appointmentData = `SELECT * FROM  application WHERE appointmentDate < NOW()`;
    // let result = await sails.sendNativeQuery(appointmentData);
    // console.log('result.rows.length', result.rows.length);
    // console.log('result', result.rows);
    // for (let i = 0; i < result.rows.length; i++) {
    //   let dateFormat = sails.moment(result.rows[i].appointmentDate).format('YYYY-MM-DD');
    //   result.rows[i].appointmentDateFormat = dateFormat;
    // }
    // return exits.success({
    //   message: sails.__('Get booked appointment data successfully'),
    //   totalAppointment: result.rows,
    //   totalNumberofAppointmentBooked: result.rows.length
    // });

    var getBookeApplicationValue = [];
    var getBookeApplicationQuery = ' SELECT'
      + ' a.appointmentDate AS "date",COUNT(*) AS "totalappointment"'
      + ' FROM'
      + ' application AS a'
      + ' GROUP BY a.appointmentDate';

    var getBookeApplicationQueryRes = await sails.sendNativeQuery(getBookeApplicationQuery, getBookeApplicationValue);
    var getBookedApplications = [];
    if (getBookeApplicationQueryRes && Array.isArray(getBookeApplicationQueryRes.rows) && getBookeApplicationQueryRes.rows.length > 0) {
      getBookedApplications = getBookeApplicationQueryRes.rows;
    }

    if (!getBookedApplications.length) {
      return exits.invalid({
        message: sails.__('No records found')
      });
    }

    for (let i = 0; i < getBookedApplications.length; i++) {
      getBookedApplications[i].date = sails.moment(getBookedApplications[i].date).format('YYYY-MM-DD');
    }

    return exits.success({
      message: sails.__('Fetch booked Applications data successfully'),
      data: {
        bookedApplications: getBookedApplications
      }
    });
  }
};
