module.exports = {
  friendlyName: 'Update',
  description: 'Update application.',
  inputs: {
    otp: {
      type: 'number',
    },
  },
  exits: {
    success: {
      description: 'successfully.'
    },

    invalid: {
      responseType: 'badRequest'
    },
  },
  fn: async function (inputs, exits) {

    var applicationOtp = await Application.findOne({
      where: {
        userId: this.req.userId
      },
      select: ['otp']
    });

    if (applicationOtp.otp === inputs.otp) {
      let objOtpVarify = {
        isPhoneNumberVarified: 1
      };
      await Application.update({
        userId: this.req.userId,
      }).set(objOtpVarify).fetch();

      return exits.success({
        message: sails.__('Phone Number has been varified successfully'),
      });
    }
    return exits.invalid({
      message: sails.__('Please enter correct OTP'),
    });
  }
};
