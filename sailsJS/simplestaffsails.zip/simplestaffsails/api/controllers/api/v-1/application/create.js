module.exports = {

  friendlyName: 'Create',

  description: 'Create User.',

  inputs: {
    firstName: {
      type: 'string',
      required: true,
    },
    lastName: {
      type: 'string',
      required: true,
    },
    middleInitial: {
      type: 'string',
      //   required: true,
    },
    streetNumber: {
      type: 'string',
      required: true,
    },
    city: {
      type: 'string',
      required: true,
    },
    state: {
      type: 'string',
      required: true,
    },
    zipCode: {
      type: 'string',
      required: true,
    },
    eligibleToWorkInUs: {
      type: 'boolean',
      required: true,
    },
    haveYouEverWorkForThisCompany: {
      type: 'boolean',
      required: true,
    },
    socialSecurityNumber: {
      type: 'string',
    //  required: true,
    },
    haveYouEverBeenConvicatedOfFalony: {
      type: 'boolean',
      required: true,
    },
    skillAndQualification: {
      type: 'string',
      required: true,
    },
    media: {
      type: 'string',
		},
		phoneNumber: {
			type: 'number',
		},
		appointmentDate: {
			type: 'ref'
		}
  },
  exits: {},


  fn: async function (inputs, exits) {

		var get_user = await User.find({ id: this.req.userId});

		if(inputs.haveYouEverWorkForThisCompany==false && inputs.eligibleToWorkInUs==true && inputs.haveYouEverBeenConvicatedOfFalony==true)
		{
			let objApplication = {
				firstName: inputs.firstName,
				lastName: inputs.lastName,
				middleInitial: inputs.middleInitial,
				streetNumber: inputs.streetNumber,
				city: inputs.city,
				state: inputs.state,
				zipCode: inputs.zipCode,
				eligibleToWorkInUs: inputs.eligibleToWorkInUs,
				haveYouEverWorkForThisCompany: inputs.haveYouEverWorkForThisCompany,
				haveYouEverBeenConvicatedOfFalony: inputs.haveYouEverBeenConvicatedOfFalony,
				skillAndQualification: inputs.skillAndQualification,
				socialSecurityNumber:inputs.socialSecurityNumber,
				userId: this.req.userId,
				status: 'incomplete',
				// profileImage:fileName.fileName,
				applicationBy:'Admin'
			};

			var result = await Application.findOne({
				userId: this.req.userId
			});

			if (!result) {
				await Application.create(objApplication);
				 //======================> generate incident pdf form data
				 let htmlData = await sails.helpers.ppereport.with({
					template: 'application-form',
					templateData: objApplication
				});

				var fs = require('fs');
				var pdf = require('html-pdf');

				let documents = sails.config.custom.documents;
				let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

				var min = 1;
				var max = 9999999;
				var random = Math.floor(Math.random() * (+max - +min)) + +min;
				var html = htmlData;
				var options = { format: 'Letter' };

				pdf.create(html, options).toFile(path + '/' + random + '.pdf', (err, res) => {
					console.log('res', res);
					if (err) { return console.log(err); }
				});

				var applicationDocument = random + '.pdf';
				await Application.update({ userId: this.req.userId }).set({ document: applicationDocument }).fetch();
				//======================> end file generate
			} else {
				 //======================> generate incident pdf form data
				 let htmlData = await sails.helpers.ppereport.with({
					template: 'application-form',
					templateData: objApplication
				});

				var fs = require('fs');
				var pdf = require('html-pdf');

				let documents = sails.config.custom.documents;
				let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

				var min = 1;
				var max = 9999999;
				var random = Math.floor(Math.random() * (+max - +min)) + +min;
				var html = htmlData;
				var options = { format: 'Letter' };

				pdf.create(html, options).toFile(path + '/' + random + '.pdf', (err, res) => {
					console.log('res', res);
					if (err) { return console.log(err); }
				});

				var applicationDocument = random + '.pdf';
				await Application.update({ userId: this.req.userId }).set({ document: applicationDocument }).fetch();
				//======================> end file generate
				await Application.update({ userId: this.req.userId }).set(objApplication);
			}
			var application = await Application.findOne({
				userId: this.req.userId,
			});
			application = application;

			return exits.success({
				message: sails.__('Application accepted'),
				status:'true',
				data: {application},
			});

		}
		else{
			let objApplication = {
				firstName: inputs.firstName,
				lastName: inputs.lastName,
				middleInitial: inputs.middleInitial,
				streetNumber: inputs.streetNumber,
				city: inputs.city,
				state: inputs.state,
				zipCode: inputs.zipCode,
				eligibleToWorkInUs: inputs.eligibleToWorkInUs,
				haveYouEverWorkForThisCompany: inputs.haveYouEverWorkForThisCompany,
				haveYouEverBeenConvicatedOfFalony: inputs.haveYouEverBeenConvicatedOfFalony,
				skillAndQualification: inputs.skillAndQualification,
				socialSecurityNumber:inputs.socialSecurityNumber,
				userId: this.req.userId,
				status: 'incomplete',
				// profileImage:fileName.fileName,
				applicationBy:'Admin'
			};

			var result = await Application.findOne({
				userId: this.req.userId
			});

			if (!result) {
				await Application.create(objApplication);

				 //======================> generate incident pdf form data
				 let htmlData = await sails.helpers.ppereport.with({
					template: 'application-form',
					templateData: objApplication
				});

				var fs = require('fs');
				var pdf = require('html-pdf');

				let documents = sails.config.custom.documents;
				let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

				var min = 1;
				var max = 9999999;
				var random = Math.floor(Math.random() * (+max - +min)) + +min;
				var html = htmlData;
				var options = { format: 'Letter' };

				pdf.create(html, options).toFile(path + '/' + random + '.pdf', (err, res) => {
					console.log('res', res);
					if (err) { return console.log(err); }
				});

				var applicationDocument = random + '.pdf';
				await Application.update({ userId: this.req.userId }).set({ document: applicationDocument }).fetch();
				//======================> end file generate

			} else { return exits.success(objApplication);
				await Application.update({ userId: this.req.userId }).set(objApplication);

				 //======================> generate incident pdf form data
				 let htmlData = await sails.helpers.ppereport.with({
					template: 'application-form',
					templateData: objApplication
				});

				var fs = require('fs');
				var pdf = require('html-pdf');

				let documents = sails.config.custom.documents;
				let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

				var min = 1;
				var max = 9999999;
				var random = Math.floor(Math.random() * (+max - +min)) + +min;
				var html = htmlData;
				var options = { format: 'Letter' };

				pdf.create(html, options).toFile(path + '/' + random + '.pdf', (err, res) => {
					console.log('res', res);
					if (err) { return console.log(err); }
				});

				var applicationDocument = random + '.pdf';
				await Application.update({ userId: this.req.userId }).set({ document: applicationDocument }).fetch();
				//======================> end file generate
			}
			// var application = await Application.findOne({
			// 	userId: this.req.userId,
			// });
			// application = application;

			// return exits.success({
			// 	message: sails.__('Application rejected'),
			// 	status:'false',
			// 	data: {application},
			// });
		}
  }
};
