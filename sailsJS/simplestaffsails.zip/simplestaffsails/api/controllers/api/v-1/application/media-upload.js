module.exports = {
  friendlyName: 'media upload',

  description: 'insert media.',

  inputs: {
    name: {
      type: 'string',
    },
    media: {
      type: 'string',
    },
  },
  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },

  fn: async function (inputs, exits) {
    var objApplication = await Application.findOne({
      where: {
        userId: this.req.userId,
      },
      select: ['id']
    });

    if (objApplication === undefined){
      return exits.invalid({
        message: sails.__('Before upload document please verify mobile number'),
      });
    }

    var applicationId = objApplication.id;
    let file = this.req.file('media');
    let documents = sails.config.custom.documents;

    let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

    if (file._files.length === 0) {
      file.upload({
        noop: true,
      });
      return exits.invalid({
        message: sails.__('Please Upload Image'),
      });
    }

    var mediaData = {
      applicationId: applicationId,
      name: inputs.name
    };

    let fileName = await sails.helpers.fileUploadHelper.with({
      name: file,
      media: path,
    });
    mediaData.media = fileName.fileName;

    var applicationMedia = await ApplicationMedia.create(mediaData).fetch();
    var baseurl = sails.config.custom.mediaDisplayPath  + this.req.userId+ documents;
    applicationMedia.media = baseurl + applicationMedia.media;

    return exits.success({
      message: sails.__('Media upload successfully'),
      data: applicationMedia,
    });
  },
};
