module.exports = {
  friendlyName: 'Update',
  description: 'Update user.',
  inputs: {
    phoneNumber: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },

  fn: async function (inputs, exits) {

    var min = 1000;
    var max = 9999;
    var random = await Math.floor(Math.random() * (+max - +min)) + +min;

    let objApplication = {
      phoneNumber: inputs.phoneNumber,
      otp: random,
      status: 'incomplete',
      userId: this.req.userId
    };

    var result = await Application.findOne({
      userId: this.req.userId
    });

    if (!result) {
      await Application.create(objApplication);
    } else {
      await Application.update({ userId: this.req.userId }).set(objApplication);
    }
    var updatedApplication = await Application.findOne({
      userId: this.req.userId,
    });

    await sails.helpers.sendSms(inputs.phoneNumber, random);
    return exits.success({
      message: sails.__('OTP send successfully'),
      data: { otp: updatedApplication.otp }
    });
  }


};
