module.exports = {


  friendlyName: 'Delete media',


  description: '',


  inputs: {
    mediaId: {
      type: 'number',
      required: true,
    },
  },
  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },


  fn: async function (inputs, exits) {

    var objMedia = await ApplicationMedia.findOne({
      id: inputs.mediaId
    });

    if (objMedia === undefined){
      return exits.invalid({
        message: sails.__('File not found'),
      });
    }

    var applicationMedia = objMedia.media;
    // Remove file form disk
    await sails.helpers.removeFile.with({ oldImage: applicationMedia, userId: this.req.userId });
    await ApplicationMedia.destroy({ id: inputs.mediaId });
    return exits.success({
      message: sails.__('Remove file successfully'),
      data: {id : objMedia.id},
    });
  }
};
