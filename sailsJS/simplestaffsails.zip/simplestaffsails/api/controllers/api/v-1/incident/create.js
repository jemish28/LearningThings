module.exports = {
  friendlyName: 'Job in out time',
  description: '',
  inputs: {
    date: {
      type: 'ref',
      required: true,
    },
    reportedby: {
      type: 'ref',
      required: true,
    },
    title: {
      type: 'ref',
      required: true,
    },
    employeeName: {
      type: 'ref',
      required: true,
    },
    dateOfIncident: {
      type: 'ref',
      required: true,
    },
    location: {
      type: 'ref',
      required: true,
    },
    timeOfIncident: {
      type: 'ref',
      required: true,
    },
    additionalPersonInvolved: {
      type: 'string',
      required: false,
      allowNull: true
    },
    witnesses: {
      type: 'string',
      required: false,
      allowNull: true
    },
  },

  exits: {
    success: {
      description: 'successfully.'
    },
    invalid: {
      responseType: 'badRequest'
    },
  },

  fn: async function (inputs, exits) {
    var user = await User.findOne({ // Get user object for timeZone
      id: this.req.userId,
    });

    var fmtForDate = 'DD-MM-YYYY';
    var date = inputs.date;
    let dateOfIncident = inputs.dateOfIncident;

    var dates = sails.moment(date, fmtForDate, true).isValid();
    console.log('dates', dates);
    var dateOfincident = sails.moment(dateOfIncident, fmtForDate, true).isValid();

    if (!dates) { // Check valid date format
      return exits.invalid({
        message: sails.__('Please enter valid date format')
      });
    }
    if (!dateOfincident) { // Check valid date format
      return exits.invalid({
        message: sails.__('Please enter valid date format')
      });
    }

    var momentObjfordate = sails.moment.tz(date, fmtForDate, user.timeZone);
    var momentObjfordateOfincident = sails.moment.tz(dateOfIncident, fmtForDate, user.timeZone);

    console.log('momentObjfordate=>', momentObjfordate);
    console.log('momentObjfordateOfincident=>', momentObjfordateOfincident);

    momentObjfordate = momentObjfordate.utc(); //Convert to utc
    momentObjfordateOfincident = momentObjfordateOfincident.utc(); //Convert to utc

    console.log('momentObjfordate=>', momentObjfordate);
    console.log('momentObjfordateOfincident=>', momentObjfordateOfincident);

    var normaldate = sails.moment(momentObjfordate).format('YYYY-MM-DD HH:mm:ss');
    var incidentdate = sails.moment(momentObjfordateOfincident).format('YYYY-MM-DD HH:mm:ss');

    console.log('normaldate', normaldate);
    console.log('incidentdate', incidentdate);

    let objIncident = {
      reportedby: inputs.reportedby,
      title: inputs.title,
      employeeName: inputs.employeeName,
      timeOfIncident: inputs.timeOfIncident,
      location: inputs.location,
      additionalPersonInvolved: inputs.additionalPersonInvolved,
      witnesses: inputs.witnesses,
      time: inputs.time,
      userId: this.req.userId,
      dateofincident: incidentdate,
      date: normaldate,
    };

    let incident = await Incident.create(objIncident).fetch();
    objIncident.userName = user.userName;
    objIncident.time = inputs.timeOfIncident;
    //======================> generate incident pdf form data
    let htmlData = await sails.helpers.ppereport.with({
      template: 'incident-form',
      templateData: objIncident
    });

    var fs = require('fs');
    var pdf = require('html-pdf');

    let documents = sails.config.custom.documents;
    let path = sails.config.custom.mediaUploadPath + this.req.userId + documents;

    var min = 1;
    var max = 9999999;
    var random = Math.floor(Math.random() * (+max - +min)) + +min;
    var html = htmlData;
    var options = { format: 'Letter' };

    pdf.create(html, options).toFile(path + '/' + random + '.pdf', (err, res) => {
      console.log('res', res);
      if (err) { return console.log(err); }
    });

    var incidentDocument = random + '.pdf';
    await Incident.update({ id: incident.id }).set({ document: incidentDocument }).fetch();
    //======================> end file generate

    return exits.success({
      message: sails.__('Incident data added successfully'),
      //   data: objJobInOutTimes
    });
  }
};
