module.exports = {
  friendlyName: 'workplacesafety',

  description: 'workplacesafety chatindividual.',

  inputs: {},

  exits: {},

  fn: async function(inputs, exits) {
    var workplacesafety = await Workplacesafety.find();
    console.log('workplacesafety',workplacesafety);
    exits.success({ result: workplacesafety });
  },
};
