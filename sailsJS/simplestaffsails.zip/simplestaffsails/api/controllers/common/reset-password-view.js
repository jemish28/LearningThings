module.exports = {

  friendlyName: 'Confirm email',

  inputs: {
    token: {
      type: 'string',
      required: true,
    },
  },

  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'resetpassword'
    },
    redirect: {
      responseType: 'redirect',
    }

  },


  fn: async function (inputs, exits) {

    if (!inputs.token) {

    }
    console.log(inputs.token);
    // Get the user with the matching email token.
    var user = await User.findOne({
      resetPasswordToken: inputs.token
    });

    return exits.success({
      token: inputs.token
    });



  }
};
