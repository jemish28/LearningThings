module.exports = {


  friendlyName: 'View job create',


  description: 'Display "job Create" page.',

  inputs: {
    id: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    success: {
      viewTemplatePath: 'admin/useravailability/show'
    }
  },

  fn: async function (inputs, exits) {

    //console.log('id for view user availability', inputs.id);

    var user = await User.findOne({ // Get user object for timeZone
      id: inputs.id,
    });
    console.log('user', user.timeZone);

    weeklyAvailabilityData = await WeeklyAvailability.find({
      userId: inputs.id,
    });
   // console.log('weeklyAvailabilityData', weeklyAvailabilityData);
    // let sql = `SELECT * FROM weeklyavailability
		// WHERE YEARWEEK(date) = YEARWEEK(NOW() + INTERVAL 1 WEEK) AND userId = ${inputs.id} `;
		let sql = `SELECT * FROM weeklyavailability
		WHERE YEARWEEK(date) = YEARWEEK(NOW()) AND userId = ${inputs.id} `;
		//console.log(sql);
    let chatResultQuery = await sails.sendNativeQuery(sql);
   // console.log('weekley availability result', chatResultQuery.rows);
    var days = new Array(7);
    days[0] = 'Sunday';
    days[1] = 'Monday';
    days[2] = 'Tuesday';
    days[3] = 'Wednesday';
    days[4] = 'Thursday';
    days[5] = 'Friday';
    days[6] = 'Saturday';
    for (let i = 0; i < chatResultQuery.rows.length; i++) {
      var a = new Date(chatResultQuery.rows[i].date);
     // console.log(a);
      var r = days[a.getDay()];
      console.log('days',r);
      chatResultQuery.rows[i].dayName = r;
    }
    return exits.success({
      data: chatResultQuery.rows
    });
  }
};
