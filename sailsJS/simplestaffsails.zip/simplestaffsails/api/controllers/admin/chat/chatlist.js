module.exports = {
  friendlyName: 'send msg from admin',

  description: 'send msg from admin.',

  inputs: {
    userId: {
      type: 'string',
      //  required: true,
    },
    // message: {
    //   type: 'string',
    // //  required: true,
    // },
  },

  exits: {
    redirect: {
      responseType: 'redirect',
    },
  },

  fn: async function(inputs, exits) {
    console.log('this.req.session.adminId for chatlist', this.req.session.adminId);
    console.log('inputs.userId',inputs.userId);
    var adminId = 1;
    //  let socketRoomName = 'chatRoom_' + adminId + '_' + inputs.userId;
    let socketRoomName = 'chatRoom_' + adminId;
    sails.sockets.join(this.req, socketRoomName);
    let isConnected = await sails.helpers.isConnectedHelper.with({ socketRoomName: socketRoomName });
    console.log('isConnected for chat list admin ?', isConnected);

		var sql = `SELECT chats.*,user.profileImage FROM chats LEFT JOIN user ON user.id=chats.userId WHERE user.profileImage AND (chats.fromUserId=${
			inputs.userId
		} and chats.userId=1 ) or (chats.fromUserId=1 AND chats.userId=${inputs.userId})`;
    let chatResultQuery = await sails.sendNativeQuery(sql);
		let chatdata = chatResultQuery.rows;

		for (let i = 0; i < chatdata.length; i++) {
	     let documents = sails.config.custom.documents;
			 var baseurl = sails.config.custom.mediaDisplayPath + chatdata[i].userId + documents;
			 chatdata[i].baseurl = baseurl;
		}
    exits.success({ result: chatdata, message: sails.config.custom.messages.chat.create });
  },
};
