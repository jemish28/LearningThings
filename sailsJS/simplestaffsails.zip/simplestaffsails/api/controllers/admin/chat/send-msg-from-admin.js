module.exports = {

  friendlyName: 'send msg from admin',

  description: 'send msg from admin.',

  inputs: {
    id: {
      type: 'string',
      //  required: true,
    },
    message: {
      type: 'string',
      //  required: true,
    },
    image: {
      type: 'ref',
    },
    mediaType: {
      type: 'ref',
    }
  },

  exits: {
    redirect: {
      responseType: 'redirect'
    },
    invalid: {}
  },

  fn: async function (inputs, exits) {
    console.log('this.req.session.adminId for send from admin', this.req.session.adminId);
    var userObj = await User.findOne({ id: inputs.id });
    console.log('userObj', userObj);

    var chatsResult;
    if (inputs.mediaType === 'text') {
      chatsResult = await Chats.create({
        mediaContent: inputs.message,
        mediaType: 'text',
        userId: inputs.id,
        fromUserId: 1
      }).fetch();
    } else {
      let chatMedia = sails.config.custom.chat;
      let path = sails.config.custom.mediaUploadPath + chatMedia;
      let file = this.req.file('file');
      if (file._files.length === 0) {
        file.upload({
          noop: true,
        });
      }
      let fileName = await sails.helpers.fileUploadHelper.with({
        name: file,
        media: path,
      });
      chatsResult = await Chats.create({
        mediaContent: fileName.fileName,
        mediaType: 'image',
        userId: inputs.id,
        fromUserId: 1
      }).fetch();
    }

    if (chatsResult.mediaType === 'text') {
      chatsResult.mediaContent = chatsResult.mediaContent;
    }
    else {
      let chat = sails.config.custom.chat;
      let mediaPath =
        sails.config.custom.mediaDisplayPath + chat;
      chatsResult.mediaContent = mediaPath + chatsResult.mediaContent;
    }

    let socketRoomName = 'chatRoom_' + inputs.id;

    let isConnected = await sails.helpers.isConnectedHelper.with({ socketRoomName: socketRoomName });

    console.log('isConnected check strickly',isConnected);

    if (isConnected) {
      User.publish([inputs.id], {
        verb: 'message',
        data: chatsResult,
      });
      exits.success({ result: chatsResult, message: sails.config.custom.messages.chat.create });
    } else {
      exits.success({ result: chatsResult, message: sails.config.custom.messages.chat.create });
      console.log('this is connected',isConnected);
      var title = 'Admin';
      var data = chatsResult.mediaContent;
      var endpointArn = userObj.snsendpointarn;
      console.log('endpointArn check', endpointArn);

      var sendPushRes = await sails.helpers.push.sendPush(title, data, '', endpointArn);
    }

    if (!chatsResult) {
      return exits.invalid({
        message: 'invalid'
      });
    }
    
    // throw {
    //   redirect: '/admin/chat'
    // };
  }
};
