module.exports = {


  friendlyName: 'send msg from admin',


  description: 'send msg from admin.',


  inputs: {},


  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {
    let socketRoomName = 'chatRoom_' + 1;
    let isConnected = await sails.helpers.isConnectedHelper.with({ socketRoomName: socketRoomName });
    console.log('isConnected', isConnected);
    console.log('username on connect: ', 1);
    sails.sockets.join(1, 'chat-channel');
    return res.ok();




  }
};
