module.exports = {

  friendlyName: 'leave room',

  description: 'send msg from admin.',

  inputs: {
    socketRoomName: {
      type: 'ref',
      //  required: true,
    },
  },

  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {
    sails.sockets.leave(this.req, inputs.socketRoomName);
    let isConnected = await sails.helpers.isConnectedHelper.with({ socketRoomName: inputs.socketRoomName });
    console.log('leave room isConnected', isConnected);
    // console.log('username on connect: ', 1);
    // sails.sockets.join(1, 'chat-channel');
    // return res.ok();
  }
};
