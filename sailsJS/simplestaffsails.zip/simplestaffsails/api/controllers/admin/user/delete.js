module.exports = {


  friendlyName: 'Delete',


  description: 'Delete User.',


  inputs: {

  },


  exits: {
    success: {
      description: 'User Deleted.',
    },
    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {

    var userId = this.req.params['id'];
		console.log('delete request get id :- ', this.req.params['id']);

		var applicationRecord = await Application.destroy({
      userId: userId
    });
		var incidentRecord = await Incident.destroy({
			userId: userId
		});
		var ChatsRecord = await Chats.destroy({
			userId: userId
		});

		var JobRecord = await Job.find({
			userId: userId
		});

		JobRecord.forEach(function(data,index){
			JobMediaRecord = "Delete from jobmedia where jobId="+data.id+"";
		});

		var JobRecord = await Job.destroy({
			userId: userId
		});
		var JobInAndJobOutRecord = await JobInAndJobOut.destroy({
			userId: userId
		});
		var JobofuserRecord = await Jobofuser.destroy({
			userId: userId
		});

		var PpeformRecord = await Ppeform.find({
			userId: userId
		});

		PpeformRecord.forEach(function(data,index){
			PpeformitemRecord = "Delete from ppeformitem where ppeformid="+data.id+"";
		});

		var PpeformRecord = await Ppeform.destroy({
			userId: userId
		});
		var WeeklyAvailabilityRecord = await WeeklyAvailability.destroy({
			userId: userId
		});

    var userRecord = await User.destroy({
      id: userId
    });

    exits.success();
  }


};
