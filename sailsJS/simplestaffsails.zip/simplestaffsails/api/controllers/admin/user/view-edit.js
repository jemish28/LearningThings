module.exports = {


  friendlyName: 'Edit',


  description: 'Edit user.',


  inputs: {

  },


  exits: {
    success: {
      viewTemplatePath: 'admin/user/edit'
    },
    redirect: {
      responseType: 'redirect'
    },

  },


  fn: async function (inputs, exits) {

    var userId = this.req.params['userId'];
    var user = await User.findOne({
      id: userId
    });

    // var application = await Application.findOne({
    //   userId: user.id,
    // }).populate('applicationMedias');

    // let documents = sails.config.custom.documents;
    // var baseurl = sails.config.custom.localhostUrl + user.id + documents;

    // if (application) {
    //   user.application = application;
    //   for (var i = 0; i < application.applicationMedias.length; i++) {
    //     application.applicationMedias[i].media = baseurl + application.applicationMedias[i].media;
    //   }
    // } else {
    //   user.application = {};
    // }

    // var data = user;

    return exits.success({
      userRecord: user
    });
  }

};
