module.exports = {
  friendlyName: 'Change appointment date',
  description: '',
  inputs: {
    appointMentDate: {
      type: 'string',
      required: true
    },
    appointMentTime: {
      type: 'string',
      required: true
    }
  },
  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {
    var req = this.req;
    var appointmentDateAndTime = inputs.appointMentDate + ' ' + inputs.appointMentTime;
    let updateData = {
      appointmentDate: appointmentDateAndTime,
    };

    var updatedUser = await Application.update({
      userId: req.params['userId']
    }).set(updateData);

		var moment = require("moment");

    var user = await User.findOne({ id: req.params['userId'] });
    await sails.helpers.sendEmail.with({
      to: user.email,
      subject: 'Appointment Date and Time change',
      template: 'appointment-date-time-change',
      layout: 'layout-email',
      typeOfSend: 'queue', // 'now', 'queue', 'preview'
      templateData: {
        name: user.userName,
        email: user.email,
				appointmentDate: moment(appointmentDateAndTime).format("DD-MM-YYYY"),
				appointmentTime: moment(appointmentDateAndTime).format("HH:MM a"),
      }
    });

    return exits.success({
      message: sails.__('Updated date successfully')
    });
  }
};
