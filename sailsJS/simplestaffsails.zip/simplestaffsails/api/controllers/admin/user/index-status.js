module.exports = {


  friendlyName: 'View Users',
  description: 'Display users.',
  inputs: {},

  exits: {
    success: {}
  },


  fn: async function (inputs, exits) {

    let result = await sails.helpers.datatablePending.with({
      model: 'user',
      options: this.req.query,
      joinTable: [
        {
          table: 'application',
          column: 'userId',
        },
      ],
    });

    return exits.success(result);
  }
};
