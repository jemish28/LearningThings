module.exports = {


  friendlyName: 'change status',


  description: 'change status.',


  inputs: {},


  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {
    var status = this.req.params['changeStatus'];
    var id = this.req.params['id'];
    var objJob;
    var objJobUser;
    let objUser = {
      status: status,
    };

    var updatedUser = await Application.update({
      userId: id
    }).set(objUser);

    if (status === 'approved') {
      objJob = await Job.find({
        where: {
          userlimit: { '>': 0 }
        },
      });

      for (var i = 0; i < objJob.length; i++) {
        objJobUser = await Jobofuser.find({
          userId: id,
          jobId: objJob[i].id
        });
      }
      if (objJobUser.length > 0) {
        for (var j = 0; j < objJobUser.length; j++) {
          await Jobofuser.update({
            userId: id,
            jobId: objJobUser[j].jobId
          }).set({
            userId: id,
            status: 'assign',
            jobId: objJobUser[j].jobId
          });
        }
      } else {
        for (var k = 0; k < objJob.length; k++) {
          await Jobofuser.create({
            userId: id,
            status: 'assign',
            jobId: objJob[k].id
          });
        }
			}

			//send mail to user when status is approved
			var getUser = await User.findOne({
				id: id
			});

			await sails.helpers.sendEmail.with({
				to: getUser.email,
				subject: 'Welcome to simple staff',
				template: 'approve-email',
				typeOfSend: 'queue', // 'now', 'queue', 'preview'
				layout: 'layout-email',
				templateData: {
					email: getUser.email,
					id: id,
					name:getUser.userName,
					desc:'Please login to the simple staff app with your credentials'
				}
			});
    }

    throw {
      redirect: '/admin/users'
    };
  }
};
