module.exports = {


  friendlyName: 'View Users index',


  description: 'Display "Index" page.',

  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'admin/user/pendingUserView'
    },
    redirect: {
      responseType: 'redirect',
    }
  },


  fn: async function (inputs, exits) {
    var id = this.req.params['id'];
    var user = await User.findOne({
      id: id,
    });

    var application = await Application.findOne({
      userId: id,
    }).populate('applicationMedias');

    let documents = sails.config.custom.documents;
    var baseurl = sails.config.custom.mediaDisplayPath + user.id + documents;
    console.log(baseurl);
    if (application) {
      user.application = application;
      // for (var i = 0; i < application.applicationMedias.length; i++) {
      //   application.applicationMedias[i].media = baseurl + application.applicationMedias[i].media;
      // }
    } else {
      user.application = {};
    }
    console.log(application);
    var data = user;

    return exits.success({userDetails : data});
  }
};
