module.exports = {


  friendlyName: 'Update',


  description: 'Update user.',

  // inputs: {
  //   userId: {
  //     type: 'string',
  //   },
  //   firstName: {
  //     type: 'string',
  //     required: true,
  //   },
  //   lastName: {
  //     type: 'string',
  //     required: true,
  //   },
  //   middleInitial: {
  //     type: 'string',
  //     required: true,
  //   },
  //   phoneNumber: {
  //     type: 'string',
  //     required: true,
  //   },
  //   skillAndQualification: {
  //     type: 'string',
  //     required: true,
  //   },
  //   appointmentDate: {
  //     type: 'string',
  //     required: true,
  //   },


  // },
	inputs: {

    email: {
      unique: true,
      required: true,
      type: 'string',
      isEmail: true,
      description: 'The email address for the new account, e.g. m@example.com.',
      extendedDescription: 'Must be a valid email address.',
    },
    password: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 6,
      example: 'passwordlol',
      description: 'The unencrypted password to use for the new account.'
		},
		userId: {
			type: "number"
		},
		userName: {
			type: "string"
		}

	},

  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {
    let objUser = {
			email: inputs.email,
      password: await sails.helpers.passwords.hashPassword(inputs.password),
    };

		await sails.helpers.sendEmail.with({
			to: inputs.email,
			subject: 'Welcome to simple staff',
			template: 'approve-email',
			typeOfSend: 'queue', // 'now', 'queue', 'preview'
			layout: 'layout-email',
			templateData: {
				email: inputs.email,
				id: inputs.userId,
				name:inputs.userName,
				desc:'Please login to the simple staff app with your new credentials'
			}
		});

     await User.update({
      id: inputs.userId
    }).set(objUser);

    throw {
      redirect: '/admin/users'
    };
  }
};
