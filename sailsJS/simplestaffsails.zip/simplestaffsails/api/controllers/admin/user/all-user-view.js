module.exports = {


  friendlyName: 'View Users index',


  description: 'Display "Index" page.',

  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'admin/user/allUserView'
    },
    redirect: {
      responseType: 'redirect',
    }
  },


  fn: async function (inputs, exits) {
    var id = this.req.params['id'];
    var user = await User.findOne({
      id: id,
    });

    var application = await Application.findOne({
      userId: id,
    }).populate('applicationMedias');

    let documents = sails.config.custom.documents;
    var baseurl = sails.config.custom.mediaDisplayPath + user.id + documents;

    if (application) {
      user.application = application;
    } else {
      user.application = {};
    }

    var incidentData = await Incident.find({ userId: user.id }).select(['document']);

		var ppeFormData = await Ppeform.find({ userId: user.id });

		getNearByUsersQuery =
		"SELECT job.title,jobinandjobout.location FROM job LEFT JOIN jobinandjobout ON jobinandjobout.jobId=job.id Where jobinandjobout.userId="+user.id+"";
		var rawResult = await sails.sendNativeQuery(
			getNearByUsersQuery
		);
		jobData = rawResult.rows;


    user.incidentData = incidentData;
    user.ppeFormData = ppeFormData;
		user.baseurl = baseurl;
		user.jobData = jobData;
    var data = user;

    return exits.success({ userDetails: data });
  }
};
