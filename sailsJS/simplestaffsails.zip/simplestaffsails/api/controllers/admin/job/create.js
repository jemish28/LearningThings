module.exports = {
  friendlyName: 'Create',
  description: 'Create admin.',
  inputs: {
    title: {
      type: 'string',
      required: true,
    },
    description: {
      type: 'string',
      required: true,
    },
    hours: {
      required: true,
      type: 'string',
    },
    users: {
      //required: true,
      type: 'string',
    },
    media: {
      type: 'string',
    },
    status: {
      required: true,
      type: 'string',
    },
    numberofuser: {
      type: 'number',
      required: true
    }
  },
  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and City is required.'
    },
    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs) {
    let file = this.req.file('media[]');
    console.log('inputs.users', inputs.users);
    var title;
    var data;
    var jobRecordData;
    var userIds = [];
    if (inputs.users !== '0') {
      let jobRecord = await Job.create({
        title: inputs.title,
        description: inputs.description,
        hours: inputs.hours,
        userId: inputs.users,
        numberOfUser: null,
        userlimit: null,
        isAll: false
      }).fetch();
      jobRecordData = jobRecord;
      await Jobofuser.create({
        status: 'assign',
        userId: inputs.users,
        jobId: jobRecord.id,
      }).fetch();
    } else {
      let jobRecord = await Job.create({
        title: inputs.title,
        description: inputs.description,
        hours: inputs.hours,
        numberOfUser: inputs.numberofuser,
        userlimit: inputs.numberofuser,
        isAll: true
      }).fetch();
      jobRecordData = jobRecord;

      var application = await Application.find({
        status: 'approved',
      });


      for (let i = 0; i < application.length; i++) {
        userId = application[i].userId;
        userIds.push(userId);
      }

      var getAllUsers = await User.find({
        id: userIds
      });
      for (let i = 0; i < getAllUsers.length; i++) {
        await Jobofuser.create({
          status: 'assign',
          userId: getAllUsers[i].id,
          jobId: jobRecord.id,
        }).fetch();
      }
    }

    if (file) {
      let documents = sails.config.custom.jobMedia;
      let path = sails.config.custom.mediaUploadPath + documents;

      const multipleFiles = await sails.helpers.fileUploadHelperForAdmin.with({
        name: file,
        media: path,
        multiple: true
      });

      console.log('controlller multipleFiles', multipleFiles);
      for (var i = 0; i < multipleFiles.length; i++) {
        await JobMedia.create({
          media: multipleFiles[i],
          jobId: jobRecordData.id
        }).fetch();
      }
    }

    var endpointArn;
    var userIdsFromapplication = [];
    if (inputs.users !== '0') {
      var userObj = await User.findOne({ id: inputs.users });
      title = 'New job';
      data = inputs.title;
      endpointArn = userObj.snsendpointarn;
      sendPushRes = await sails.helpers.push.sendPush(title, data, '', endpointArn);
    } else {
      title = 'New job posted';
      data = inputs.title;

      let allUser = await User.find({
        where: {
          snsendpointarn: { '!=': '' },
          id: userIds,
        },
      });
      console.log('jobRecordData id',jobRecordData.id);
      console.log('allUser',allUser);
      for (var j = 0; j < allUser.length; j++) {
        endpointArn = allUser[j].snsendpointarn;
        jobId = jobRecordData.id;
        type = 'Job notification';
        notificationType = 'Job';
        sendPushRes = await sails.helpers.push.sendPush(title, data, notificationType, endpointArn,jobId);
      }
    }

    throw {
      redirect: '/admin/job'
    };
  }
};
