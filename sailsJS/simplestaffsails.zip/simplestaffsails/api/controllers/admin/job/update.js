module.exports = {

  friendlyName: 'Create',

  description: 'Create admin.',

  inputs: {
    title: {
      type: 'string',
      required: true,
    },
    id: {
      type: 'string',
      required: true,
    },
    description: {
      type: 'string',
      required: true,
    },
    hours: {
      required: true,
      type: 'string',
    },
    users: {
      required: true,
      type: 'string',
    },
    media: {
      type: 'string',
    },
    delete: {
      type: 'string'
    },
    status: {
      required: true,
      type: 'string',
    },
  },


  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and City is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {
    let file = this.req.file('media[]');
    var array = inputs.delete.split(',');
    console.log(array.length);
    var objJobMedia = await JobMedia.find({
      jobId: inputs.id
    });

    if (file._files.length === 0) {
      file.upload({
        noop: true,
      });
    }

    if (!objJobMedia) {
      return exits.invalid({
        message: sails.config.custom.messages.application.fileNotFound,
      });
    }

    jobRecordData = {
      title: inputs.title,
      description: inputs.description,
      hours: inputs.hours,
      status: inputs.status,
      //userId: inputs.users,
    };
    await Job.update({
      id: inputs.id
    }).set(jobRecordData);

    if (jobRecordData.length === 0) {
      return exits.invalid({
        message: 'Job not found'
      });
    }

    if (file) {
      let documents = sails.config.custom.jobMedia;
      let path = sails.config.custom.mediaUploadPath + documents;
      const multipleFiles = await sails.helpers.fileUploadHelperForAdmin.with({
        name: file,
        media: path,
        multiple: true
      });
      for (var i = 0; i < multipleFiles.length; i++) {
        await JobMedia.create({
          jobId: inputs.id,
          media: multipleFiles[i],
        });
      }
    }

    if (inputs.delete) {
      var objJobMediaDelete = await JobMedia.find({
        id: array
      });
      files = [];

      console.log('deleted media id', objJobMediaDelete.length);
      let documents = sails.config.custom.jobMedia;
      let filepath = sails.config.custom.mediaUploadPath + documents;
      for (var images = 0; images < objJobMediaDelete.length; images++) {
        objJobMediaDelete[images].media = filepath + objJobMediaDelete[images].media;
        files.push(objJobMediaDelete[images].media);
      }

      var fs = require('fs');
      function deleteFiles(files, callback) {
        var i = files.length;

        files.forEach((filepath) => {
          fs.unlink(filepath, (err) => {
            i--;
            if (err) {
              callback(err);
              return;
            } else if (i <= 0) {
              return null;
            }
          });
        });
      }

      deleteFiles(files, (err) => {
        if (err) {
          console.log(err);
        } else {
          console.log('all files removed');

        }
      });

      await JobMedia.destroy({ id: array });
    }

    throw {
      redirect: '/admin/job'
    };
  }
};

