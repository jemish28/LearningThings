module.exports = {


  friendlyName: 'View Jobs',
  description: 'Display Jobs.',
  inputs: {},

  exits: {
    success: {}
  },


  fn: async function (inputs, exits) {

    let result = await sails.helpers.datatableJob.with({
      model: 'user',
      options: this.req.query,
      joinTable: [
        {
          table: 'job',
          column: 'userId',
        },
      ],
    });
    return exits.success(result);
  }
};
