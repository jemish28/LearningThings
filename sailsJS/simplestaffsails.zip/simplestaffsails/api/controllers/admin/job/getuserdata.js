module.exports = {


  friendlyName: 'Get User Data',
  description: 'Get User Data',
  inputs: {
    usernameLike: {
      type: 'ref'
    }
  },

  exits: {
    success: {}
  },


  fn: async function (inputs, exits) {

    var application = await Application.find({
      status: 'approved',
    });
    var userIds = [];
    for (var i = 0; i < application.length; i++) {
      userId = application[i].userId;
      userIds.push(userId);
    }
    var user;
    if (inputs.usernameLike) {
      user = await User.find({
        id: userIds,
        or: [
          { email: { contains: inputs.usernameLike } },
          { userName: { contains: inputs.usernameLike } },
        ]
      }).limit(10);
    } else {
      // var user = await User.find({
      //   id: userIds,
      // }).limit(10);
    }

    return exits.success(user);
  }
};
