module.exports = {


  friendlyName: 'change status',


  description: 'change status.',


  inputs: {},


  exits: {
    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {
    var status = this.req.params['changeStatus'];
		var id = this.req.params['id'];
		var total_hours = this.req.params['total_hours'];
    var objJob;
    var objJobUser;
    let objUser = {
			status: status,
			total_hours: total_hours,
    };

    var updatedUser = await JobInAndJobOut.update({
      id: id
    }).set(objUser);



    throw {
      redirect: '/admin/job'
    };
  }
};
