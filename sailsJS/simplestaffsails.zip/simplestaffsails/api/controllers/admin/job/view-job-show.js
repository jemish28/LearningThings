module.exports = {


  friendlyName: 'View job create',


  description: 'Display "job Create" page.',

  inputs: {
    id: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    success: {
      viewTemplatePath: 'admin/job/show'
    }
  },

  fn: async function (inputs, exits) {
    // console.log(inputs.id);
    var jobObject = await Job.findOne({
      id: inputs.id
    }).populate('JobMedias');

    var jobMediaObject = await JobMedia.find({
      jobId: inputs.id
    });

    let documents = sails.config.custom.jobMedia;
    let path = sails.config.custom.mediaDisplayPath + documents;

    for (let jobMedia of jobMediaObject) {
      jobMedia.mediawithpath = path + jobMedia.media;
      jobMedia.withoutpath = jobMedia.media;
      var extention = jobMedia.mediawithpath.split('.').pop();
      //console.log('extention', extention);
      if (extention === 'jpg' || extention === 'png' || extention === 'jpeg') {
        jobMedia.images = path + jobMedia.media;
       // console.log('jobMedia', jobMedia);
      } else if (extention === 'doc' || extention === 'pdf' || extention === 'xls' || extention === 'ppt' || extention === 'pdf' || extention === 'xlsx') {
        jobMedia.documents = path + jobMedia.media;
      }
    }

    // console.log('jobMediaObject', jobMediaObject);
    var application = await Application.find({
      status: 'approved',
    });

    var userIds = [];
    for (var i = 0; i < application.length; i++) {
      userId = application[i].userId;
      userIds.push(userId);
    }

    var user = await User.find({
      id: userIds
    });

    var jobObjectforTimeSet = await JobInAndJobOut.find({
      jobId: inputs.id
    });

    let hours = [];

    for (let value of jobObjectforTimeSet) {
      //   console.log('value', value);
      hours.push(value.timeOfJob);
    }
    let totalMinutes = hours.reduce(myFunc, 0);
    function myFunc(total, num) {
      return total + num;
    }
    let hour = Math.floor(totalMinutes / 60);
    let minutes = totalMinutes % 60;
    totalTime = hour + ' hour ' + minutes + ' minutes ';

    var jobaccepted = await Jobofuser.find({
      jobId: inputs.id,
      status: 'accepted'
    });
   // console.log('jobaccepted', jobaccepted);
    var userIdsForaccpted = [];

    for (var j = 0; j < jobaccepted.length; j++) {
      userId = jobaccepted[j].userId;
      userIdsForaccpted.push(userId);
    }
    //console.log('userIdsForaccpted', userIdsForaccpted);
    var userIdForAccptedJob = await User.find({
      id: userIdsForaccpted
    });
    return exits.success({
      jobRecord: jobObject,
      userData: user,
      media: jobMediaObject,
      totalTime: totalTime, jobObjectforTimeSet: jobObjectforTimeSet, userIdForAccptedJob: userIdForAccptedJob
    });
  }
};
