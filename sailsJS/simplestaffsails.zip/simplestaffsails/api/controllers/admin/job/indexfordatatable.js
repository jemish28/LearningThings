module.exports = {


  friendlyName: 'View Users',
  description: 'Display users.',
  inputs: {

    jobId:{
      type: 'ref',
      //required: true,
    }
  },

  exits: {
    success: {}
  },


  fn: async function (inputs, exits) {
    // console.log('job id',inputs.jobId);

    var jobAccptedUser = await Jobofuser.find({
      jobId : inputs.jobId,
      status:'accepted'
    });

    //console.log('jobAccptedUser',jobAccptedUser);
    var userIds;
    if(jobAccptedUser.length>0){
      userIds = [];
    }else{
      userIds = ['NULL'];
    }


    for (let i = 0; i < jobAccptedUser.length; i++) {
      userId = jobAccptedUser[i].userId;
      userIds.push(userId);
    }

    let result = await sails.helpers.datatableTimecard.with({
      model: 'user',
      userIds:userIds,
      options: this.req.query,
      joinTable: [
        {
          table: 'application',
          column: 'userId',
				},
      ],
		});



    for (let i = 0; i < result.data.length; i++) {
			//result.data[i].appointmentDate = sails.moment(result.data[i].appointmentDate).format('YYYY-MM-DD hh:mm:ss');

		 getQuery =
			"SELECT GROUP_CONCAT(total_hours) as total_hours FROM jobinandjobout Where jobId="+inputs.jobId+" AND userId="+result.data[i].userId+" AND status='approved' AND total_hours!='' ORDER BY id DESC";
			var rawResult = await sails.sendNativeQuery(
				getQuery
			);
			total_hoursData = rawResult.rows;

			const moment= require('moment');
			if(total_hoursData[0].total_hours!=null)
			{
				const durations = (total_hoursData[0].total_hours).split(",")

				const totalDurations = durations.slice(1)
			 .reduce((prev, cur) => moment.duration(cur).add(prev),
				moment.duration(durations[0]))
				result.data[i].totalHours = moment.utc(totalDurations.asMilliseconds()).format("HH:mm:ss");
			}
			else{
				result.data[i].totalHours='00:00:00';
			}

		}

		result.jobId = inputs.jobId;
    return exits.success(result);
  }
};
