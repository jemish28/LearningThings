module.exports = {
  friendlyName: 'View job create',
  description: 'Display "job Create" page.',
  inputs: {
    id: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    success: {
      viewTemplatePath: 'admin/job/edit'
    }
  },

  fn: async function (inputs, exits) {
    console.log(inputs.id);
    var jobObject = await Job.findOne({
      id: inputs.id
    }).populate('JobMedias');

    var jobMediaObject = await JobMedia.find({
      jobId: inputs.id
    });

    let documents = sails.config.custom.jobMedia;
    let path = sails.config.custom.mediaDisplayPath + documents;

    for (let jobMedia of jobMediaObject) {
      jobMedia.mediawithpath = path + jobMedia.media;
      jobMedia.withoutpath = jobMedia.media;
    }
    var application = await Application.find({
      status: 'approved',
    });

    var userIds = [];
    for (var i = 0; i < application.length; i++) {
      userId = application[i].userId;
      userIds.push(userId);
    }

    var user = await User.find({
      id: userIds
    });
    user.unshift({ id: 0, email: 'All' });
    console.log('select 2 user', user);
    console.log('jobObject', jobObject);
    return exits.success({
      jobRecord: jobObject,
      userData: user,
      media: jobMediaObject,
      approvedUserLength: user.length
    });
  }
};
