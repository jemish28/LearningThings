module.exports = {


  friendlyName: 'View Users index',


  description: 'Display "Index" page.',

  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'admin/job/usersfortimecard'
    },
    redirect: {
      responseType: 'redirect',
    }
  },


  fn: async function (inputs, exits) {
    var id = this.req.params['id'];
    var jobId = this.req.params['jobId'];
    var user = await User.findOne({
      id: id,
    });

    let months = sails.moment.months();
    let monthArr = [];
    months.map(month => {
      let objMonth = {
        monthName: month.substring(0, 3),
        total: 0,
      };
      monthArr.push(objMonth);
    });

    let totalHoursOfMonth = [];

    let totalHoursOfMonthSql = `select concat(jobInTime) as date ,concat(jobInTime) as inDate,concat(jobOutTime) as outDate,timeOfJob as totalhour,Time(jobInTime) as intime,Time(jobOutTime) as outtime, location as location,jobOutTime,jobinandjobout.desc,jobinandjobout.status,jobinandjobout.id  FROM jobinandjobout where userId = ${id} and jobId = ${jobId} GROUP BY YEAR(jobOutTime), MONTH(jobOutTime),jobInTime`;

    totalHoursOfMonth = await sails.sendNativeQuery(totalHoursOfMonthSql);

    totalHoursOfMonth = totalHoursOfMonth.rows;

    for (var i = 0; i < totalHoursOfMonth.length; i++) {

			start = (totalHoursOfMonth[i].intime).split(":");
			end = (totalHoursOfMonth[i].outtime).split(":");

			const moment= require('moment');

			var now  = new Date(0, 0, 0, end[0], end[1], end[2]);
			var then = new Date(0, 0, 0, start[0], start[1], start[2]);

			totalHoursOfMonth[i].totalhour = moment.utc(moment(now,"DD/MM/YYYY HH:mm:ss").diff(moment(then,"DD/MM/YYYY HH:mm:ss"))).format("HH:mm:ss");
    }

    function groupByMonth(data) {
      var month1 = new Array();
      month1[0] = 'January';
      month1[1] = 'February';
      month1[2] = 'March';
      month1[3] = 'April';
      month1[4] = 'May';
      month1[5] = 'June';
      month1[6] = 'July';
      month1[7] = 'August';
      month1[8] = 'September';
      month1[9] = 'October';
      month1[10] = 'November';
      month1[11] = 'December';
      var months = {};
      for (var i = 0; i < data.length; i++) {
        var obj = data[i];
        var date = new Date(obj.date);
        var month = month1[date.getMonth()];
        if (months[month]) {
          months[month].push(obj);  // already have a list- append to it
        }
        else {
          months[month] = [obj]; // no list for this month yet - create a new one
        }
      }
      return months;

    }
    result = groupByMonth(totalHoursOfMonth);

    let allData = JSON.parse(JSON.stringify(result));

    for (const key in allData) {
      const element = allData[key];
      for (const key in element) {
        if (element.hasOwnProperty(key)) {
          const element2 = element[key];
          element2.date;
          var momentObj = sails.moment.tz(element2.date, user.timeZone);
          element2.date = sails.moment(momentObj).format('DD-MM-YYYY');
        }
      }
    }
   // console.log('allData', allData);

   // console.log('allData', Object.keys(allData));

    return exits.success({ timeCardDetails: allData });
  }
};
