module.exports = {


  friendlyName: 'Delete all',


  description: '',


  inputs: {

  },


  exits: {
		success: {
      statusCode: 200,
      description: 'Notification Deleted.',
    },
    redirect: {
      responseType: 'redirect'
    },
    invalid: {
      statusCode: 409,
      description: 'Invalid request'
    },
  },


  fn: async function (inputs) {

    await Notifications.destroy({});

		//add notification data
		getNearByUsersQuery =
		"SELECT notifications.*,application.firstName as firstName,application.lastName FROM notifications LEFT JOIN user ON user.id=notifications.sender_id left join application ON user.id=application.userId Where notifications.receiver_type='admin' ORDER BY notifications.id DESC";
		var rawResult = await sails.sendNativeQuery(
			getNearByUsersQuery
		);
		notificationData = rawResult.rows;
		var moment = require("moment");
		notificationData.forEach(function(data,index){
			data.new_date = moment.utc(data.createdAt).fromNow(true)
		});
		this.req.session.numRecords = await Notifications.count();
		this.req.session.notificationData = notificationData;

		throw {
      redirect: '/admin/notificationlist'
    };

  }


};
