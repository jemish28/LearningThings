module.exports = {


  friendlyName: 'Notification list',


  description: '',


  inputs: {

  },


  exits: {
		success: {
      responseType: 'view',
      viewTemplatePath: 'admin/notificationlist'
    },
    redirect: {
      responseType: 'redirect',
    }
  },


  fn: async function (inputs ,exits) {
		var moment = require("moment");

		getNearByUsersQuery =
		"SELECT notifications.*,application.firstName as firstName,application.lastName as lastName FROM notifications LEFT JOIN user ON user.id=notifications.sender_id left join application ON user.id=application.userId Where notifications.receiver_type='admin' ORDER BY notifications.id DESC";

		var rawResult = await sails.sendNativeQuery(
      getNearByUsersQuery
    );
		notificationData1 = rawResult.rows;

		notificationData1.forEach(function(data,index){
			data.new_date = moment.utc(data.createdAt).fromNow(true)
		});

    return exits.success({
			notificationData1:notificationData1
		});

  }


};
