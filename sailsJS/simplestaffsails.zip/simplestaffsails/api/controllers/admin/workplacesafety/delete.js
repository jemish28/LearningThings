module.exports = {


  friendlyName: 'Delete',


  description: 'Delete job.',


  inputs: {

  },


  exits: {
    success: {
      description: 'Job Deleted.',
    },
    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {



    var Workplacesafety = this.req.params['id'];
    console.log('delete request get id :- ', this.req.params['id']);

    await Workplacesafety.destroy({
      id: Workplacesafety
    });


    exits.success();
  }

};
