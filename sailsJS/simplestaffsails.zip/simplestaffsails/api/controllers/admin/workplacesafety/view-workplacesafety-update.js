module.exports = {


  friendlyName: 'View job create',


  description: 'Display "job Create" page.',

  inputs: {
    id: {
      type: 'string',
      required: true,
    },
  },
  exits: {

    success: {
      viewTemplatePath: 'admin/workplacesafety/edit'
    }

  },

  fn: async function (inputs, exits) {
    console.log('input',inputs.id);
    var workplacesafety = await Workplacesafety.findOne({
      id: inputs.id
    });
    return exits.success({result: workplacesafety});
  }
};
