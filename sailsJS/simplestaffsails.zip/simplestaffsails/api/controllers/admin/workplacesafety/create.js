module.exports = {

  friendlyName: 'Create',

  description: 'Create admin.',

  inputs: {
    title: {
      type: 'ref',
      required: true,
    },
    about: {
      type: 'ref',
      required: true,
    },
  },
  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and City is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {


    var workplacesafetyRecord = await Workplacesafety.create({
      title: inputs.title,
      description: inputs.about,
    }).fetch();

    throw {
      redirect: '/admin/workplacesafety'
    };
  }
};
