module.exports = {


  friendlyName: 'View User Availability For Job Index',


  description: 'Display "Index" page.',

  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'admin/workplacesafety/index'
    },
    redirect: {
      responseType: 'redirect',
    }
  },


  fn: async function (inputs, exits) {
    return exits.success();
  }
};
