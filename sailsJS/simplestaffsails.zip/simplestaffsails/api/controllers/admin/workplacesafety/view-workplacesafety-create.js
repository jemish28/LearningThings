module.exports = {


  friendlyName: 'View job create',


  description: 'Display "workplacesafety Create" page.',


  exits: {

    success: {
      viewTemplatePath: 'admin/workplacesafety/create'
    }

  },

  fn: async function (inputs, exits) {

    return exits.success({ result:'' });
  }
};
