module.exports = {

  friendlyName: 'Create',

  description: 'Create admin.',

  inputs: {
    delete: {
      type: 'string'
    },
    userId:{
      type: 'ref'
    },
    media: {
      type: 'string',
    },
  },
  exits: {
    invalid: {
      statusCode: 409,
    //  description: 'Name and City is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {
    var objApplication = await Application.findOne({
      where: {
        userId: inputs.userId,
      },
      select: ['id']
    });
    let file = this.req.file('media[]');
    var applicationId = objApplication.id;
    console.log('file._files',file._files[0].stream.filename );
    console.log('users',inputs.userId);

    if (file) {
      let documents = sails.config.custom.documents;

      let path = sails.config.custom.mediaUploadPath + inputs.userId + documents;

      const multipleFiles = await sails.helpers.fileUploadHelperForAdmin.with({
        name: file,
        media: path,
        multiple: true
      });
      console.log('controlller multipleFiles', multipleFiles);
      for (var i = 0; i < multipleFiles.length; i++) {
        var jobMedia = await ApplicationMedia.create({
          media: multipleFiles[i],
          applicationId: applicationId,
          name:file._files[i].stream.filename
        }).fetch();
      }
    }

    console.log('id',inputs.delete);
    var array = inputs.delete.split(',');
    console.log(array.length);

    if (inputs.delete) {
      var objJobMediaDelete = await ApplicationMedia.find({
        id: array
      });
      files = [];

      console.log('deleted media id', objJobMediaDelete.length);
      let documents = sails.config.custom.documents;
      let filepath = sails.config.custom.mediaUploadPath + inputs.userId + documents;
      for (var images = 0; images < objJobMediaDelete.length; images++) {
        objJobMediaDelete[images].media = filepath + objJobMediaDelete[images].media;
        files.push(objJobMediaDelete[images].media);
      }

      var fs = require('fs');
      function deleteFiles(files, callback) {
        var i = files.length;

        files.forEach((filepath) => {
          fs.unlink(filepath, (err) => {
            i--;
            if (err) {
              callback(err);
              return;
            } else if (i <= 0) {
              return null;
            }
          });
        });
      }

      deleteFiles(files, (err) => {
        if (err) {
          console.log(err);
        } else {
          console.log('all files removed');
        }
      });

      await ApplicationMedia.destroy({ id: array });
    }

    throw {
      redirect: '/admin/media'
    };
  }
};

