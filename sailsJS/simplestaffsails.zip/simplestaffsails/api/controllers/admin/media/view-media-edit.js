module.exports = {

  friendlyName: 'View job create',

  description: 'Display "job Create" page.',

  inputs: {
    id: {
      type: 'string',
      required: true,
    },
  },
  exits: {
    success: {
      viewTemplatePath: 'admin/media/edit'
    }
  },

  fn: async function (inputs, exits) {
    let mediaData;
    console.log('input for image edit', inputs.id);

    var objApplication = await Application.findOne({
      where: {
        userId: inputs.id,
      },
      select: ['id']
    });
    console.log('objApplication', objApplication.id);

    var objApplicationMedia = await ApplicationMedia.find({
      applicationId: objApplication.id,
    });

    let documents = sails.config.custom.documents;
    var baseurl = sails.config.custom.mediaDisplayPath + inputs.id + documents;


    for (let applicationMedia of objApplicationMedia) {
      applicationMedia.mediawithpath = baseurl + applicationMedia.media;
      applicationMedia.withoutpath = applicationMedia.media;
    }

    return exits.success({
      media: objApplicationMedia,
      id:inputs.id
    });

  }
};
