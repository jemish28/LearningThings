module.exports = {


  friendlyName: 'View job create',


  description: 'Display "job Create" page.',


  exits: {

    success: {
      viewTemplatePath: 'admin/media/create'
    }

  },

  fn: async function (inputs, exits) {
    var application = await Application.find({
      status: 'approved',
    });

    var userIds = [];
    for (var i = 0; i < application.length; i++) {
      userId = application[i].userId;
      userIds.push(userId);
    }

    var user = await User.find({
      id: userIds
    });

    return exits.success({userData: user});
  }
};
