module.exports = {

  friendlyName: 'Create',

  description: 'Create admin.',

  inputs: {


    media: {
      type: 'string',
    },
    users:{
      type: 'ref',
    }

  },
  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and City is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {
    var objApplication = await Application.findOne({
      where: {
        userId: inputs.users,
      },
      select: ['id']
    });
    let file = this.req.file('media[]');
    var applicationId = objApplication.id;
    console.log('file._files',file._files[0].stream.filename );
    console.log('users',inputs.users);

    if (file) {
      let documents = sails.config.custom.documents;

      let path = sails.config.custom.mediaUploadPath + inputs.users + documents;

      const multipleFiles = await sails.helpers.fileUploadHelperForAdmin.with({
        name: file,
        media: path,
        multiple: true
      });
      console.log('controlller multipleFiles', multipleFiles);
      for (var i = 0; i < multipleFiles.length; i++) {
        var jobMedia = await ApplicationMedia.create({
          media: multipleFiles[i],
          applicationId: applicationId,
          name:file._files[i].stream.filename
        }).fetch();
      }
    }

    throw {
      redirect: '/admin/media'
    };
  }
};
