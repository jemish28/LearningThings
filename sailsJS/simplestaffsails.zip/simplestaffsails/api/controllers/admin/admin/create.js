module.exports = {


  friendlyName: 'Create',


  description: 'Create admin.',


  inputs: {
    firstName: {
      type: 'string',
      required: true,
    },
    lastName: {
      type: 'string',
      required: true,
    },
    email: {
      unique: true,
      required: true,
      type: 'string',
      isEmail: true,
      description: 'The email address for the new account, e.g. m@example.com.',
      extendedDescription: 'Must be a valid email address.',
    },
    password: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 6,
      example: 'passwordlol',
      description: 'The unencrypted password to use for the new account.'
		},
		image: {
			//required: true,
			type: 'ref',
		}
  },


  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and Email is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },


  fn: async function (inputs, exits) {

		let profileMedia = sails.config.custom.profilePicture;
		let path = sails.config.custom.mediaUploadPath + profileMedia;
		let file = this.req.file('image');
		if (file._files.length === 0) {
			file.upload({
				noop: true,
			});
		}

		let fileName = await sails.helpers.fileUploadHelper.with({
			name: file,
			media: path,
		});

    var userRecord = await Admin.create({
      firstName: inputs.firstName,
      lastName: inputs.lastName,
			email: inputs.email,
			image: fileName.fileName,
      password: await sails.helpers.passwords.hashPassword(inputs.password),
    }).fetch();

    if (!userRecord) {
      return exits.invalid({
        message: 'invalid'
      });
    }

    throw {
      redirect: '/admin/admins'
    };
  }

};
