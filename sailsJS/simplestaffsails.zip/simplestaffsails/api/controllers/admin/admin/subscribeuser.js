module.exports = {
  friendlyName: 'Subscribeuser',

  description: 'Subscribeuser user.',

  inputs: {},

  exits: {},

  fn: async function (inputs, exits) {
    var adminId = this.req.session.adminId;

    let socketId = sails.sockets.getId(this.req);

    // await User.update({ id: inputs.id }).set({ socketId: socketId, userStatus: 'online' });

    let onlineUser = await Admin.find({
      id: adminId,
    });


    Admin.subscribe(this.req, [onlineUser[0].id]);
    // Admin.publish(_.map(onlineUser, 'id'), {
    //   verb: 'connectUser',
    //   data: adminId,
    // });
    exits.success({ message: 'admin subscribe successfully' });
  },
};
