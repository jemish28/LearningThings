module.exports = {
  friendlyName: 'Login',

  inputs: {
    email: {
      description: 'The email to try in this attempt, e.g. "irl@example.com".',
      type: 'string',
      required: true
    },

    password: {
      description: 'The unencrypted password to try in this attempt, e.g. "passwordlol".',
      type: 'string',
      required: true
    },

  },


  exits: {

    success: {
      description: 'The requesting user agent has been successfully logged in.',

    },

    badCombo: {
      description: `The provided email and password combination does not
      match any user in the database.`,
      responseType: 'unauthorized'
      // ^This uses the custom `unauthorized` response located in `api/responses/unauthorized.js`.
      // To customize the generic "unauthorized" response across this entire app, change that file
      // (see api/responses/unauthorized).
      //
      // To customize the response for _only this_ action, replace `responseType` with
      // something else.  For example, you might set `statusCode: 498` and change the
      // implementation below accordingly (see http://sailsjs.com/docs/concepts/controllers).
    },

    redirect: {
      description: 'The requesting user is already logged in.',
      responseType: 'redirect'
    }
  },


  fn: async function (inputs) {


    var userRecord = await Admin.findOne({
      email: inputs.email.toLowerCase(),
    });

    if (!userRecord) {
      throw 'badCombo';
    }

    // If the password doesn't match, then also exit thru "badCombo".
    await sails.helpers.passwords.checkPassword(inputs.password, userRecord.password)
      .intercept('incorrect', 'badCombo');
    if (inputs.rememberMe) {
      if (this.req.isSocket) {
        sails.log.warn(
          'Received `rememberMe: true` from a virtual request, but it was ignored\n' +
          'because a browser\'s session cookie cannot be reset over sockets.\n' +
          'Please use a traditional HTTP request instead.'
        );
      } else {
        this.req.session.cookie.maxAge = sails.config.custom.rememberMeCookieMaxAge;
      }
    }
    this.req.session.admin = userRecord;
    this.req.session.adminId = userRecord.id;

		//add notification data
		getNearByUsersQuery =
		"SELECT notifications.*,application.firstName as firstName,application.lastName FROM notifications LEFT JOIN user ON user.id=notifications.sender_id left join application ON user.id=application.userId Where notifications.receiver_type='admin' ORDER BY notifications.id DESC";
		var rawResult = await sails.sendNativeQuery(
			getNearByUsersQuery
		);
		notificationData = rawResult.rows;
		var moment = require("moment");
		notificationData.forEach(function(data,index){
			data.new_date = moment.utc(data.createdAt).fromNow(true)
		});

		this.req.session.numRecords = await Notifications.count();
		this.req.session.notificationData = notificationData;

    throw {
			redirect: '/admin/dashboard'
    };
  }

};
