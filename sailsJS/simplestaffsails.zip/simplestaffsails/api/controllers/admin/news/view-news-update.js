module.exports = {


  friendlyName: 'View job create',


  description: 'Display "job Create" page.',

  inputs: {
    id: {
      type: 'string',
      required: true,
    },
  },
  exits: {

    success: {
      viewTemplatePath: 'admin/news/edit'
    }

  },

  fn: async function (inputs, exits) {
    console.log('input',inputs.id);
    var newsRecord = await News.findOne({
      id: inputs.id
    });
    return exits.success({newsRecord: newsRecord});
  }
};
