module.exports = {

  friendlyName: 'Create',

  description: 'Create admin.',

  inputs: {
    id:{
      type: 'ref',
    },
    title: {
      type: 'ref',
      required: true,
    },
    about: {
      type: 'ref',
      required: true,
    },
  },
  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and City is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {
    console.log(inputs.id);
    var newsRecord = await News.update({
      id:inputs.id
    }).set({ title: inputs.title,
      news: inputs.about});

    throw {
      redirect: '/admin/news'
    };
  }
};
