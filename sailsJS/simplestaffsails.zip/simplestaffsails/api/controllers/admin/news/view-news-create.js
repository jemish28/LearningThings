module.exports = {


  friendlyName: 'View job create',


  description: 'Display "job Create" page.',


  exits: {

    success: {
      viewTemplatePath: 'admin/news/create'
    }

  },

  fn: async function (inputs, exits) {

    return exits.success({newsRecord: ''});
  }
};
