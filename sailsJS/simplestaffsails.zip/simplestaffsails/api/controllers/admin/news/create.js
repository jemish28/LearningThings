module.exports = {

  friendlyName: 'Create',

  description: 'Create admin.',

  inputs: {
    title: {
      type: 'ref',
      required: true,
    },
    about: {
      type: 'ref',
      required: true,
    },
  },
  exits: {
    invalid: {
      statusCode: 409,
      description: 'Name and City is required.'
    },

    redirect: {
      responseType: 'redirect'
    }
  },

  fn: async function (inputs, exits) {
    var newsRecord = await News.create({
      title: inputs.title,
      news: inputs.about,
    }).fetch();

    throw {
      redirect: '/admin/news'
    };
  }
};
