module.exports = {


  friendlyName: 'View Jobs',
  description: 'Display Jobs.',
  inputs: {},

  exits: {
    success: {}
  },


  fn: async function (inputs, exits) {

    let result = await sails.helpers.datatablePending2.with({
      model: 'news',
      options: this.req.query
    });

    return exits.success(result);
  }
};
