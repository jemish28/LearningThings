/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    userId: {
      model: 'User'
    },
    date: {
      type: 'ref',
      columnType: 'datetime'
    },
    reportedby: {
      type: 'string',
    },
    title: {
      type: 'ref',
    },
    employeeName: {
      type: 'ref',
    },
    dateofincident: {
      type: 'ref',
      columnType: 'datetime'
    },
    timeOfIncident: {
      type: 'ref',
    },
    location: {
      type: 'ref',
    },
    additionalPersonInvolved: {
      type: 'string',
      required: false,
      allowNull: true
    },
    witnesses: {
      type: 'string',
      required: false,
      allowNull: true
    },
    document: {
      type: 'string',
      required: false,
      allowNull: true
    }
  },
};

