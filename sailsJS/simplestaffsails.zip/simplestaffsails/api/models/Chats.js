module.exports = {
  fetchRecordsOnUpdate: true,
  attributes: {
    fromUserId: {
      model: 'user',
    },
    userId: {
      model: 'user',
    },
    chatType: {
      type: 'string',
      isIn: ['individualchat', 'groupchat'],
      defaultsTo: 'individualchat',
    },
    chatHeaderType: {
      type: 'string',
      isIn: ['normal', 'userjoin', 'userleft', 'added', 'removed', 'groupnamechanged', 'left'],
      defaultsTo: 'normal',
    },
    mediaContent: {
      type: 'string',
      allowNull: true,
    },
    mediaType: {
      type: 'string',
      isIn: ['text', 'image', 'location', 'document', 'video'],
      defaultsTo: 'text',
    },
    mediaStatus: {
      type: 'string',
      isIn: ['sent', 'delivered', 'viewed'],
      defaultsTo: 'sent',
    },
    isRead: {
      type: 'boolean',
    },
  },
};
