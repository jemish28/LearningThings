/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    userId :{
      model: 'User'
    },
    ppeorderform :{
      type : 'string'
    },
    ppeformitems:{
      collection: 'ppeformitem',
      via : 'ppeformid'
    }
  },
};

