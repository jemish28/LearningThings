/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    userId: {
      model: 'User',
    },
    title: {
      type: 'string',
    },
    description: {
      type: 'string',
    },
    hours: {
      type: 'string',
    },
    status: {
      type: 'string',
      //   isIn: ['accepted','decline', 'assign', 'completed'],
      // required: true,
    },
    isAll: {
      type: 'ref',
    },
    numberOfUser: {
      type: 'number',
      allowNull: true
    },
    userlimit:{
      type: 'number',
      allowNull: true
    },
    JobMedias: {
      collection: 'JobMedia',
      via: 'jobId'
    },
    JobTotalTime: {
      collection: 'JobInAndJobOut',
      via: 'jobId'
    },
  },
};

