/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    userId: {
      model: 'User'
    },
    firstName: {
      type: 'string',
    },
    lastName: {
      type: 'string',
    },
    middleInitial: {
      type: 'string',
    },
    streetNumber: {
      type: 'string',
    },
    city: {
      type: 'string',
    },
    state: {
      type: 'string',
    },
    zipCode: {
      type: 'string',
    },
    phoneNumber: {
      type: 'string',
    },
    otp: {
      type: 'number',
    },
    isPhoneNumberVarified: {
      type: 'boolean',
    },
    eligibleToWorkInUs: {
      type: 'boolean',
    },
    haveYouEverWorkForThisCompany: {
      type: 'boolean',
    },
    haveYouEverBeenConvicatedOfFalony: {
      type: 'boolean',
    },
    socialSecurityNumber: {
      type: 'string',
    },
    skillAndQualification: {
      type: 'string',
    },
    appointmentDate: {
      type: 'ref',
      columnType: 'datetime'
    },
    status: {
      type: 'string',
      isIn: ['incomplete', 'approved', 'rejected', 'pending'],
      required: true,
    },
    profileImage: {
      type: 'string',
    },
    applicationMedias: {
      collection: 'ApplicationMedia',
      via: 'applicationId'
		},
		document: {
			type: 'string',
			allowNull: true
		}
  },
  customToJSON: function () {
    if (this.appointmentDate) {
      var moment = require('moment');
      this.appointmentDate = moment(this.appointmentDate).format('YYYY-MM-DD hh:mm');
    }
    return _.omit(this, []);
  },
  // afterUpdate: async function (valuesToSet, proceed) {
  //   console.log('update things');
  //   var min=1000;
  //   var max=9999;
  //   var random = await Math.floor(Math.random() * (+max - +min)) + +min;
  //   var sendMessage = 'your otp number is :'+random;
  //   var fullMobilenumber = valuesToSet.phoneNumber;
  //   await sails.helpers.sendSms(fullMobilenumber, sendMessage);
  //   return proceed();
  // }

};

