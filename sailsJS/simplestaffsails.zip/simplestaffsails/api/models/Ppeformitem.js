/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    ppeformid: {
      model: 'Ppeform'
    },
    itemname: {
      type: 'ref'
    },
    quantity:{
      type: 'ref'
    },
    size:{
      type: 'ref'
    },
  },
};

