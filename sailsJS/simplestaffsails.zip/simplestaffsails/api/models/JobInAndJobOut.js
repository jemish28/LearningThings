/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    jobId: {
      model: 'Job'
    },
    timeOfJob: {
      type: 'number'
    },
    userId:{
      type: 'number'
    },
    'jobInTime': { type: 'ref', columnType: 'datetime' },
    'jobOutTime': { type: 'ref', columnType: 'datetime' },
    longitude:{
      type: 'string',
    },
    latitude:{
      type: 'string',
    },
    location:{
      type: 'string',
		},
		desc:{
      type: 'string',
		},
		status:{
			type: 'string',
		},
		total_hours:{
			type: 'ref',
		}
  },
};

