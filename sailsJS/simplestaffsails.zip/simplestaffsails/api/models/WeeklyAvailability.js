/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    userId: {
      model: 'User'
    },

    'date': { type: 'ref', columnType: 'datetime' },
    status: {
      type: 'ref',
    },
  },
};

