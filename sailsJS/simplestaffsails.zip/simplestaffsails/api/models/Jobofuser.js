/**
 * Application.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    userId :{
      type: 'number'
    },
    status: {
      type: 'string',
      required: true,
    },
    isproceed:{
      type: 'boolean',
      defaultsTo: false
    },
    jobId :{
      model: 'Job'
    },
  },
};

