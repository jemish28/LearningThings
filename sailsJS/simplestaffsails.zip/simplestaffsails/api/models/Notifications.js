/**
 * Notifications.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {
		sender_id: {
      type: 'number',
		},
		reciever_id: {
      type: 'number',
		},
		notification_type: {
      type: 'string',
		},
		notification_data: {
      type: 'string',
		},
		is_viewed: {
      type: 'boolean',
		},
		is_read: {
      type: 'boolean',
		},
		is_hidden: {
      type: 'boolean',
		},
		sender_type: {
      type: 'string',
		},
		receiver_type: {
      type: 'string',
		}

  },

};

