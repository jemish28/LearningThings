/**
 * User.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */
var password;
module.exports = {
  fetchRecordsOnUpdate: true,
  attributes: {
    userName: {
      type: 'string',
      //   required: true,
    },
    email: {
      type: 'string',
      required: true,
      unique: true,
      isEmail: true,
    },
    password: {
      type: 'string',
      required: true,
      protect: true
    },
    isEmailVerified: {
      type: 'boolean',
    },
    resetPasswordToken: {
      type: 'string',
    },
    timeZone: {
      type: 'string',
      allowNull: true
    },
    profileImage: {
      type: 'string',
    },
    devicetoken: {
      type: 'string',
      allowNull: true
    },
    snsendpointarn: {
      type: 'string',
      allowNull: true
    },
    snstopicscriptionarn: {
      type: 'string',
      allowNull: true
    },
    devicetype: {
      type: 'string',
      allowNull: true
    },
    createdBy: {
      type: 'string',
      allowNull: true
    },
    application: {
      collection: 'Application',
      via: 'userId'
    },
  },
  // customToJSON: function () {
  //   // Return a shallow copy of this record with the password and ssn removed.
  //   return _.omit(this, ['password', 'verificationToken'])
  // },

  // beforeCreate: async function (valuesToSet, proceed) {
  //   // Hash password
  //   // console.log('beforeCreate', valuesToSet);
  //   await sails.helpers.passwords.hashPassword(valuesToSet.password).exec((err, hashedPassword) => {
  //     if (err) {
  //       return proceed(err);
  //     }
  //     valuesToSet.password = hashedPassword;
  //     valuesToSet.verificationToken = sails.helpers.strings.random('url-friendly')
  //     return proceed();
  //   });
  // },

  afterCreate: async function (valuesToSet, proceed) {
    var password;
    console.log('afterCreate', valuesToSet, sails.helpers.strings.random('url-friendly'));
    console.log('valuesToSet', valuesToSet);
    if (valuesToSet.createdBy !== 'Admin') {
      if (sails.config.custom.verifyEmailAddresses) {
        await sails.helpers.sendEmail.with({
          to: valuesToSet.email,
          subject: 'Please confirm your account',
          template: 'email-verify-account',
          layout: 'layout-email',
          typeOfSend: 'queue', // 'now', 'queue', 'preview'
          templateData: {
            id: valuesToSet.id,
            fullName: valuesToSet.userName
          }
        });
      } else {
        sails.log.info('Skipping new account email verification... (since `verifyEmailAddresses` is disabled)');
      }
    } else {
      var updatedUser = await User.update({
        id: valuesToSet.id
      }).set({password:await sails.helpers.passwords.hashPassword('123456')});
      if (sails.config.custom.verifyEmailAddresses) {
        await sails.helpers.sendEmail.with({
          to: valuesToSet.email,
          subject: 'Account login details',
          template: 'email-password-send',
          layout: 'layout-email',
          typeOfSend: 'queue', // 'now', 'queue', 'preview'
          templateData: {
            id: valuesToSet.id,
            fullName: valuesToSet.userName,
            email:valuesToSet.email,
            password:'123456'
          }
        });
      } else {
        sails.log.info('Skipping new account email verification... (since `verifyEmailAddresses` is disabled)');
      }
    }
    return proceed();
  },





  // afterUpdate: async function (valuesToSet, proceed) {
  //   console.log('update things');
  //   var min=100000;
  //   var max=999999;
  //   var random =Math.floor(Math.random() * (+max - +min)) + +min;
  //   var sendMessage = 'your otp number is :'+random;
  //   var fullMobilenumber = valuesToSet.user_mobile_number;
  //   await sails.helpers.sendSms(fullMobilenumber, sendMessage);
  //   return proceed();
  // },

  // beforeUpdate: async function (valuesToSet, proceed) {
  //   console.log('beforeUpdate', valuesToSet);
  //   if (valuesToSet.password) {
  //     await sails.helpers.passwords.hashPassword(valuesToSet.password).exec((err, hashedPassword) => {
  //       if (err) {
  //         return proceed(err);
  //       }
  //       valuesToSet.password = hashedPassword;

  //     });
  //   }
  //   return proceed();
  // },

  //   afterUpdate: function (valuesToSet, proceed) {
  //     console.log('afterUpdate', valuesToSet);
  //     return proceed();
  //   },

  //   beforeDestroy: function (valuesToSet, proceed) {
  //     console.log('beforeDestroy', valuesToSet);
  //     return proceed();
  //   },

  //   afterDestroy: function (valuesToSet, proceed) {
  //     console.log('beforeDestroy', valuesToSet);
  //     return proceed();
  //   },
  customToJSON: function () {

    return _.omit(this, ['password']);
  },
};
