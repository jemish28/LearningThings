global.AWS = require('aws-sdk');

global.AWS.config.update({ accessKeyId: sails.config.custom.aws.snsAccessKeyId, secretAccessKey: sails.config.custom.aws.snsSecretAccessKey });

global.AWS.config.update({ region: sails.config.custom.aws.snsRegion }, { output: sails.config.custom.aws.snsOutput });

global.sns = new global.AWS.SNS();
