module.exports = {
  friendlyName: 'Topic subscribe',
  description: '',
  inputs: {
    usertype: {
      type: 'string',
      example: 'user',
      isIn: ['user', 'driver'],
      description: 'user/driver',
      defaultsTo: 'user',
    },
    devicetype: {
      type: 'string',
      example: 'iOS',
      isIn: ['iOS', 'Android'],
      description: 'device type',
      required: true,
    },
    endpointarn: {
      type: 'string',
      example: 'af34fsdf4asdrg34tfrsdfg',
      description: 'endpoint arn',
      required: false,
    },
  },
  exits: {},
  fn: async function(inputs, exits) {
    // inputs.usertype, inputs.devicetype, inputs.endpointarn

    if (!inputs.endpointarn) {
      return exits.success({
        status: false,
        err: null,
      });
    }

    var topicArn = '';
    if (inputs.usertype === 'user') {
      if (inputs.devicetype === 'iOS') {
        topicArn = sails.config.custom.aws.snsArnIosUserTopic;
      } else if (inputs.devicetype === 'Android') {
        topicArn = sails.config.custom.aws.snsArnAndroidUserTopic;
      }
    } else if (inputs.usertype === 'driver') {
      if (inputs.devicetype === 'iOS') {
        topicArn = sails.config.custom.aws.snsArnIosDriverTopic;
      } else if (inputs.devicetype === 'Android') {
        topicArn = sails.config.custom.aws.snsArnAndroidDriverTopic;
      }
    }

    var params = {
      Protocol: 'application' /* required */,
      TopicArn: topicArn /* required */,
      Endpoint: inputs.endpointarn,
    };
    global.sns.subscribe(params, (err, data) => {
      return exits.success({
        status: err ? false : true,
        err: err,
        data: data,
      });
    });
  },
};
