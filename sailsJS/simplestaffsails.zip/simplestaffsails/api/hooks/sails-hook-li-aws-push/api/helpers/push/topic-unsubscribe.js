module.exports = {
  friendlyName: 'Topic unsubscribe',
  description: '',
  inputs: {
    snstopicscriptionarn: {
      type: 'string',
      example: 'af34fsdf4asdrg34tfrsdfg',
      description: 'sns topic scription arn',
      required: false
    },
  },
  exits: {

  },
  fn: async function (inputs, exits) {
    if(!inputs.snstopicscriptionarn){
      return exits.success({
        status: false,
        err: null
      });
    }

    var params = {
      SubscriptionArn: inputs.snstopicscriptionarn /* required */
    };
    global.sns.unsubscribe(params, (err, data) => {
      return exits.success({
        status: (err ? false : true),
        err: err,
        data: data
      });
    });
  }
};
