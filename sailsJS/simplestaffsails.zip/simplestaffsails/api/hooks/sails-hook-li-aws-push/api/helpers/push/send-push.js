module.exports = {
  friendlyName: 'Send push',
  description: '',
  inputs: {
    title: {
      type: 'string',
      //  required: false,
      description: 'User device token',
    },
    data: {
      type: 'string',
      //  required: true,
      description: 'AWS ARN id',
    },
    notificationType: {
      type: 'string',
      //   required: false,
      description: 'notification action',
    },
    endpointArn: {
      type: 'string',
      // required: false,
      description: 'User device token',
    },
    jobId: {
      type: 'ref',
      description: 'job Id'
    },

  },
  exits: {
    redirect: {
      responseType: 'redirect'
    },
    invalid: {}
  },
  fn: async function (inputs, exits) {
    // exits.success({
    //   status: true,
    // });
    var jobId;
    if (inputs.jobId) {
      jobId = inputs.jobId;
    } else {
      jobId = '';
    }

    var message = inputs.data;
    var titleNotification = inputs.title;
    var endpointArn = inputs.endpointArn;
    console.log('endpointArn for check', inputs.endpointArn);
    var sns = global.sns;
    var notificationType = inputs.notificationType;
    if (!endpointArn) {
      console.log('endpointArn blank: ', endpointArn);
      return;
      // return exits.success({
      //   status: false,
      //   message: 'end-point-arn blank',
      //   errorcode: '',
      // });
    }
    var payload = {
      default: message,

      APNS_SANDBOX: {
        aps: {
          alert: {
            title: titleNotification,
            body: message,
            notificationType: notificationType,
            jobId:jobId
          },
          sound: 'default',
          badge: 1,
          action: message,
          extra: {
            notificationType: notificationType,
            jobId:jobId
          },
        },
      },
      APNS: {
        aps: {
          alert: {
            title: titleNotification,
            body: message,
            notificationType: notificationType,
            jobId:jobId
          },
          sound: 'default',
          badge: 1,
          action: message,
          extra: {
            notificationType: notificationType,
            jobId:jobId
          },
        },
      },
      GCM: {
        data: {
          message: message,
          sound: 'default',
          badge: 1,
          action: message,
          extra: {
            notificationType: notificationType,
            jobId:jobId
          },
        },
      },
    };

    //  first have to stringify the inner APNS object...
    payload.APNS = JSON.stringify(payload.APNS);
    payload.APNS_SANDBOX = JSON.stringify(payload.APNS_SANDBOX);
    payload.GCM = JSON.stringify(payload.GCM);
    payload = JSON.stringify(payload);
    console.log('endpointArn', endpointArn);
    console.log('payload', payload);


    sns.publish(
      {
        Message: payload,
        MessageStructure: 'json',
        TargetArn: endpointArn,
      },
      async (snsPublishErr, snsPublishData) => {
        if (snsPublishErr) {

          if (snsPublishErr.code === 'EndpointDisabled') {
            var enableArnRes = await sails.helpers.push.enableArn(endpointArn);
            sns.publish(
              {
                Message: payload,
                MessageStructure: 'json',
                TargetArn: endpointArn,
              },
              async (snsPublishErr, snsPublishData) => {
                snsPublishData.message.jobId = inputs.jobId;
                snsPublishData.message.notificationType = inputs.notificationType;
                if (snsPublishErr) {
                  console.log('Notification Error: 2 : message: ', snsPublishErr.message, ', code: ', snsPublishErr.code);
                  // return;
                  return exits.success({
                    status: false,
                    message: snsPublishErr.message,
                    errorcode: snsPublishErr.code,
                  });
                } else {
                  console.log({
                    status: true,
                    message: snsPublishData,
                    errorcode: '',
                  });
                  //return;
                  return exits.success({
                    status: true,
                    message: snsPublishData,
                    errorcode: '',
                  });
                }
              }
            );
          } else {
            //return;
            return exits.success({
              status: false,
              message: snsPublishErr.message,
              errorcode: snsPublishErr.code,
            });
          }
        } else {
          console.log({
            status: true,
            message: snsPublishData,
            errorcode: '',
          });

          //return;
          return exits.success({
            status: true,
            message: snsPublishData,
            errorcode: '',
          });
        }
      }
    );
  },
};
