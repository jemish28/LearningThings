module.exports = function defineSailsHookLiAwsPushHook(sails) {
  var loader = require('@logisticinfotech/sails-util-mvcsloader')(sails);

  return {
    initialize: function(next) {
      sails.log.info('Initializing custom hook (`sails-hook-li-aws-push`)');
      sails.after('hook:helpers:loaded', () => {
        loader.adapt(
          {
            services: __dirname + '/api/services', // Path to the services to load
            helpers: __dirname + '/api/helpers',
          },
          err => {
            return next(err);
          }
        );
      });
    },
  };
};
