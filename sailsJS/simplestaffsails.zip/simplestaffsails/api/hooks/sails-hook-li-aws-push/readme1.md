# Sails hook AWS PUSH

-   Add configuarion in development.js and production.js file

-   development.js

```
custom : {
      aws: {
      snsAccessKeyId: '',
      snsSecretAccessKey: '',
      snsRegion: 'us-west-2',
      snsOutput: 'json',

      //IOS
      snsArnIosUserPlatformApplication: '',
      snsArnIosDriverPlatformApplication: '',

      snsArnIosUserTopic: '',
      snsArnIosDriverTopic: '',

      // ANDROID
      snsArnAndroidUserPlatformApplication: '',
      snsArnAndroidDriverPlatformApplication: '',

      snsArnAndroidUserTopic: '',
      snsArnAndroidDriverTopic: '',
    },
}
```
