module.exports = {
  friendlyName: 'Common query helper',

  description: '',

  inputs: {
    moduleName: {
      type: 'string',
      required: true,
    },
  },

  exits: {
    success: {
      description: 'All done.',
    },
  },

  fn: async function(inputs, exits) {
    let select = '';
    if (inputs.moduleName == 'user') {
      select += `CASE WHEN "user"."id" IS NULL
                  THEN
                    '[]'
                  ELSE
                    json_build_object(
                      'id',"user"."id",
                      'emailAddress',"user"."emailAddress",
                      'firstName',"user"."firstName",
                      'lastName',"user"."lastName",
                      'profileImage',
                      CASE WHEN POSITION('${sails.config.custom.protocol}' IN "user"."profileImage") != '0'
                      THEN
                      "user"."profileImage"
                      ELSE
                        CONCAT('${sails.config.custom.mediaUrl}','${
  sails.config.custom.companyLogoPath
}',"user"."companyId",'/${sails.config.custom.userProfilePath}',"user"."id",'/',"user"."profileImage")
                      END,

                      'bankId',"user"."bankId",
                      'parentId',"user"."parentId",
                      'loginType',"user"."loginType",
                      'socialId',"user"."socialId",
                      'isActive',"user"."isActive",
                      'companyId',"user"."companyId",
                      'birthDate',TO_CHAR("user"."birthDate",'yyyy-mm-dd'),
                      'gender',"user"."gender"

                    )
                  END
                `;
    }
    exits.success(select);
  },
};
