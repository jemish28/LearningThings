module.exports = {
  friendlyName: 'File upload helper',

  description: '',
  inputs: {
    name: {
      type: 'ref',
    },
    media: {
      type: 'string',
    },
    multiple: {
      type: 'boolean',
      defaultsTo: false,
    },
  },

  exits: {
    success: {
      description: 'All done.',
    },
  },

  fn: async function (inputs, exits) {
    // if (inputs.oldImage) await sails.helpers.removeFile.with({
    //   oldImage: inputs.path + "/" + inputs.oldImage
    // });

    //console.log('inputs.name', inputs.name);
    await inputs.name.upload({
      dirname: inputs.media,
    }, (error, uploadedFiles) => {
      console.log('uploadedFiles', uploadedFiles);
      if (error) {
        return console.log(error);
      }
      if (inputs.multiple) {
        let multipleFiles = [];
        for (let uploadedFile of uploadedFiles) {
          let filename = uploadedFile.fd;
          filename = filename.split('/');
          filename = filename[filename.length - 1];
          multipleFiles.push(filename);
        }
        return exits.success(multipleFiles);

      } else {
        let filename = uploadedFiles[0].fd;
        filename = filename.split('/');
        multipleFiles = filename[filename.length - 1];
        return exits.success(multipleFiles);
      }
    });
  },
};
