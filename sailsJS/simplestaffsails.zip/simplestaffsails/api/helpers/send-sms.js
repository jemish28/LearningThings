module.exports = {
  friendlyName: 'sendSms',
  description: 'Send SMS via twillio',
  inputs: {
    toMobileNumber: {
      type: 'string',
      example: '+919999999999',
      description: 'The mobile number to whom we need to send sms',
      required: true
    },
    msgBody: {
      type: 'string',
      example: 'Message here',
      description: 'The mobile number to whom we need to send sms',
      required: true
    },
    typeOfSend: {
      // expecting 'now','queue'
      // 'now': it will send sms instant then respond to caller.
      // 'queue': it will add sms to queue.
      type: 'string',
      required: false,
      defaultsTo: 'queue',
    },
  },
  exits: {

  },
  fn: async function (inputs, exits) {
    console.log(inputs.toMobileNumber);
    var twilio = require('twilio');
    var client = new twilio(sails.config.ACCOUNT_SID, sails.config.AUTH_TOKEN);
    if (sails.config.PHONE_SMS_STATUS === 'true') {
      if (inputs.typeOfSend === 'queue') {
        console.log('abcd');
        Jobs.create('sendSms', {
          inputs: inputs
        }).save((err) => {
          if (err) {
            return exits.success({
              status: false,
              message: err.message,
              data: null
            });
          }
          return exits.success({
            status: true,
            message: sails.__('sms send success'),
            data: null
          });
        });
      } else {
        client.messages.create({
          body: inputs.msgBody,
          to: inputs.toMobileNumber, // Text this number
          from: sails.config.TWILLIO_PHONE_NO // From a valid Twilio number
        }, (err, message) => {
          if (message) {
            return exits.success({
              status: true,
              message: sails.__('sms send success'),
              data: message
            });
          } else if (err) {
            return exits.success({
              status: false,
              message: err.message
            });
          } else {
            return exits.success({
              status: false,
              message: sails.__('Twillio Error')
            });
          }
        });
      }
    } else {
      return exits.success({
        status: true,
        message: sails.__('PHONE_SMS_STATUS is false in .env so not sending sms.')
      });
    }
  }
};
