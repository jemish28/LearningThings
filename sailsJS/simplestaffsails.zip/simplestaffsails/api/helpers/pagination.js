module.exports = {
  friendlyName: 'Pagination',

  description: 'Pagination something.',

  inputs: {
    page: {
      type: 'number',
      required: true,
    },
    perPage: {
      type: 'number',
      required: true,
    },
    nativeQuery: {
      type: 'string',
    },
    model: {
      type: 'string',
    },
  },

  exits: {
    success: {
      description: 'All done.',
    },
  },

  fn: async function(inputs, exits) {
    let totalRecord = 0;
    inputs.page = inputs.page - 1;

    if (inputs.nativeQuery) {
      let totalRecordSql = `SELECT COUNT(*) AS totalRecord  FROM (${inputs.nativeQuery}) AS ${inputs.model}`;

      let totalRecordResult = await sails.sendNativeQuery(totalRecordSql);

      totalRecord = parseInt(totalRecordResult.rows[0].totalRecord);
    }

    let numberOfPages = Math.ceil(totalRecord / inputs.perPage);
    if (numberOfPages != 0) {numberOfPages = numberOfPages - 1;}
    let nextPage = parseInt(inputs.page) + 1;

    let meta = {
      page: inputs.page,
      perPage: inputs.perPage,
      previousPage: inputs.page > 0 ? parseInt(inputs.page) - 1 : false,
      nextPage: numberOfPages >= nextPage ? nextPage : false,
      pageCount: numberOfPages,
      total: totalRecord,
    };

    exits.success(meta);
  },
};
