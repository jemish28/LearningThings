var path = require('path');
var url = require('url');
var util = require('util');
module.exports = {

  friendlyName: 'ppe order report',

  description: '',

  inputs: {
    template: {
      description: 'The relative path to an EJS template within our `views/emails/` folder -- WITHOUT the file extension.',
      type: 'string',
      required: true
    },

    templateData: {
      description: 'A dictionary of data which will be accessible in the EJS template.',
      type: {},
      required: true
    },
  },


  exits: {},

  fn: async function (inputs, exits) {
    var emailTemplatePath =  inputs.template;
    var htmlEmailContents = await sails.renderView(
        emailTemplatePath,
        _.extend({
          url,
          util
        }, inputs.templateData)
    );
    console.log('htmlEmailContents',htmlEmailContents);
    return exits.success(htmlEmailContents);
  }
};
