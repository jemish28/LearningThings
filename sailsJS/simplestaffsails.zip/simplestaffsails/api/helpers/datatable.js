var _ = require('lodash');
module.exports = {
  friendlyName: 'Datatable',

  description: 'Datatable something.',

  inputs: {
    model: {
      type: 'ref',
      required: true,
    },
    options: {
      type: {},
      required: true,
    },
    modelName: {
      type: 'string',
    },
    joinTable: {
      type: 'ref',
    },
  },

  exits: {
    success: {
      description: 'All done.',
    },
  },

  fn: async function (inputs, exits) {
    let model = inputs.model;
    let options = inputs.options;

    let start = options.start;
    let length = options.length;

    let joinTable = inputs.joinTable;
    let joinTableArr = [];
    let whereArr = [];


    //default column options
    var _columns = [
      {
        data: '',
        name: '',
        searchable: true,
        orderable: true,
        search: {
          regex: true,
          value: '',
        },
      },
    ];

    //default datatable options
    var _options = {
      draw: 0,
      columns: _columns,
      start: 0,
      length: 10,
      search: {
        value: '',
        regex: false,
      },
      order: [
        {
          column: 0,
          dir: 'asc',
        },
      ],
    };

    //merge both Object, options and _options into _options
    _.assign(_options, options);

    let searchableColumn = _options.columns.filter(column => column.searchable === 'true');

    let selectArr = [];
    let index = 1;

    _.each(_options.columns, (column) => {
      let selectQuery = '';

      if (column.name) {
        let select = column.name;
        select = _.split(column.name, '.');


        selectQuery += `${select[0]}`;

        if (select.length > 1) { selectQuery += `.${select[1]}`; }

        if (column.searchable === 'true' && _options.search.value) {
          let where = `${selectQuery} LIKE '%${_options.search.value}%' ${
            index < searchableColumn.length ? 'OR' : ''
          } `;
          whereArr.push(where);
          index++;
        }

        if (select.length > 1 && select[0] !== model) {
          selectQuery = `COALESCE(jsonb_agg(DISTINCT to_jsonb(${
            select[0]
          })) FILTER (WHERE ${selectQuery} IS NOT NULL),'[]') AS ${column.data}`;
        }

        selectArr.push(selectQuery);

      }
    });
    if (joinTable) {
      for (join of joinTable) {
        let joinQuery = ``;

        join.joinType = 'INNER';

        if (join.joinType) { join.joinType = join.joinType; }

        joinQuery += `${join.joinType} JOIN ${join.table} ON ${join.table}.${join.column} = ${model}.${
          join.populateColumn ? join.populateColumn : 'id'
        }`;

        if (join.join) {
          joinQuery += `${join.joinType} JOIN ${join.join[0].table} ON ${join.join[0].table}.${
            join.join[0].column
          } = ${join.table}.${join.join[0].populateColumn}`;

        }

        joinTableArr.push(joinQuery);
      }
    }
    // console.log('joinTableArr',joinTable);

    let columns = selectArr.join(',');

    let sql = `SELECT ${model}.id AS id,${columns} FROM ${model} `;

    if (joinTableArr.length > 0) { sql += `${joinTableArr.join(' ')}`; }

    if (whereArr.length > 0) { sql += ` WHERE ${whereArr.join(' ')}`; }


    sql += ` ORDER BY ${_options.columns[_options.order[0].column].data} ${_options.order[0].dir}`;
    var _response = {
      draw: _options.draw,
      recordsTotal: 0,
      recordsFiltered: 0,
      iTotalRecords: 0,
      iTotalDisplayRecords: 0,
      data: [],
    };

    let total = await sails.sendNativeQuery(sql);

    _response.recordsTotal = total.rows.length;
    _response.iTotalRecords = total.rows.length;

    if (start && length) { sql += ` LIMIT ${length} OFFSET ${start} `; }

    let result = await sails.sendNativeQuery(sql);

    _response.recordsFiltered = result.rows.length;
    _response.iTotalDisplayRecords = total.rows.length;

    _response.data = result.rows;
    return exits.success(_response);
  },
};
