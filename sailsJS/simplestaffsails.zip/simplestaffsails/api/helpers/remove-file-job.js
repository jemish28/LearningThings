module.exports = {
  friendlyName: 'Remove file',

  description: '',

  inputs: {
    oldImage: {
      type: 'string',
      required: true,
    },

  },

  exits: { },

  fn: async function(inputs, exits) {
    // let rimraf = require('rimraf');
    const fs = require('fs');
    let documents = sails.config.custom.jobMedia;
    let filePath = sails.config.custom.mediaUploadPath  + documents + inputs.oldImage;

    try {
      fs.unlinkSync(filePath);
    } catch(err) {
      console.error(err);
    }
  //  return exits.success({ message: 'File remove successfully' });
  },
};

