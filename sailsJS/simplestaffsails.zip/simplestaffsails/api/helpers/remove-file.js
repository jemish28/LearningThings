module.exports = {
  friendlyName: 'Remove file',

  description: '',

  inputs: {
    oldImage: {
      type: 'string',
      required: true,
    },
    userId: {
      type: 'number',
      required: true,
    },
  },

  exits: {
    // success: {
    //   description: 'successfully.'
    // },
    // invalid: {
    //   responseType: 'badRequest'
    // },
  },

  fn: async function(inputs, exits) {
    // let rimraf = require('rimraf');
    const fs = require('fs');
    let documents = sails.config.custom.documents;
    var filePath = sails.config.custom.mediaUploadPath + inputs.userId + documents + inputs.oldImage;
    try {
      fs.unlinkSync(filePath);
    } catch(err) {
      console.error(err);
    }
    // rimraf(filePath, () => {});
    // rimraf(tempFolderFullPath, () => {});
  //  return exits.success({ message: 'File remove successfully' });
  },
};
