
exports.up = function(knex, Promise) {
  return knex.schema.table('jobinandjobout', function (t) {
    t.string('desc').nullable();
  });
};

exports.down = function(knex, Promise) {
	return knex.schema.table('jobinandjobout', function (t) {
    t.dropColumn('desc');
  });
};
