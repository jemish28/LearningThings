
exports.up = function(knex, Promise) {
  return knex.schema.createTable('ppeformitem', (t) => {
    t.increments('id').primary();
    t.integer('ppeformid').unsigned().notNullable();
    t.foreign('ppeformid')
    .references('ppeform.id');
    t.string('itemname').nullable();
    t.string('quantity').nullable();
    t.string('size').nullable();
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
};
