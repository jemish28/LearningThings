
exports.up = function(knex, Promise) {
  return knex.schema.table('ppeform', function (t) {
    t.string('ppeorderform').nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.table('ppeform', function (t) {
    t.dropColumn('ppeorderform');
  });
};
