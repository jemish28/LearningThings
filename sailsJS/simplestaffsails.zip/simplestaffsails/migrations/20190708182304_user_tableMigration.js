exports.up = function (knex, Promise) {
  return knex.schema.table('user', t => {
    t.string('profileImage')
      .nullable();
  });
};

exports.down = function (knex, Promise) {
  return knex.schema.table('user', function (t) {
    t.dropColumn('profileImage');
  });
  // return knex.schema.dropTableIfExists('user');
};

