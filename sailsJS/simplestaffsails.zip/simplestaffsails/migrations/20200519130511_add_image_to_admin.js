
exports.up = function(knex, Promise) {
	return knex.schema.table('admin', function (t) {
    t.string('image').nullable();
  });
};

exports.down = function(knex, Promise) {
	return knex.schema.table('admin', function (t) {
    t.dropColumn('image');
  });
};
