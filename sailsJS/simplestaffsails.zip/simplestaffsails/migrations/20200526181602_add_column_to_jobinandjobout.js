
exports.up = function(knex, Promise) {
  return knex.schema.table('jobinandjobout', function (t) {
    t.string('status').nullable();
  });
};

exports.down = function(knex, Promise) {

};
