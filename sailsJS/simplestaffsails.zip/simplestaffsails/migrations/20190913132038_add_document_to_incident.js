
exports.up = function (knex, Promise) {
  return knex.schema.table('incident', function (t) {
    t.string('document').nullable();
  });
};

exports.down = function (knex, Promise) {
  return knex.schema.table('incident', function (t) {
    t.dropColumn('document');
  });
};
