
exports.up = function(knex, Promise) {
  return knex.schema.table('job', function (t) {
    t.integer('userlimit').defaultsTo(0).nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.table('job', function (t) {
    t.dropColumn('userlimit');
  });
};
