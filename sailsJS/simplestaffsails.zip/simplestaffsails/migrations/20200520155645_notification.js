
exports.up = function(knex, Promise) {
  return knex.schema.createTable('notifications', function (t) {
		t.increments('id').primary();
    t.integer('sender_id').nullable();
    t.integer('reciever_id').nullable();
    t.string('notification_type').nullable();
    t.string('notification_data').nullable();
    t.boolean('is_viewed').nullable();
    t.boolean('is_read').nullable();
		t.boolean('is_hidden').nullable();
		t.datetime('createdAt').nullable();
		t.datetime('updatedAt').nullable();
		t.string('sender_type').nullable();
		t.string('receiver_type').nullable();
  });
};

exports.down = function(knex, Promise) {
	return knex.schema.dropTableIfExists('notifications');
};
