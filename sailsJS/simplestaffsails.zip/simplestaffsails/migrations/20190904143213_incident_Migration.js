
exports.up = function(knex, Promise) {
  return knex.schema.createTable('incident', (t) => {
    t.increments('id').primary();
    t.integer('userId').nullable();
    t.foreign('userId')
    .references('user.id');
    t.date('date').nullable();
    t.string('reportedby').nullable();
    t.string('title').nullable();
    t.string('employeename').nullable();
    t.date('dateofincident').nullable();
    t.time('timeofincident').nullable();
    t.string('location').nullable();
    t.string('additionalPersonInvolved').nullable();
    t.string('witnesses').nullable();
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
//  return knex.schema.dropTableIfExists('workplacesafety');
};
