
exports.up = function(knex, Promise) {
  return knex.schema.table('user', (t) => {
    // t.increments('id').primary();
    // t.string('userName').nullable();
    // t.string('email').nullable();
    // t.string('password').nullable();
    // t.boolean('isEmailVerified').nullable();
    // t.string('resetPasswordToken').nullable();
    // t.string('timeZone').nullable();
    // t.string('profileImage').nullable();
    t.string('devicetype').nullable();
    t.string('snsendpointarn').nullable();
    t.string('snstopicscriptionarn').nullable();
    // t.datetime('createdAt').nullable();
    // t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
  //return knex.schema.dropTableIfExists('user');
};
