
exports.up = function(knex, Promise) {
  return knex.schema.createTable('application', (t) => {
    t.increments('id').primary();
    t.string('firstName').nullable();
    t.string('lastName').nullable();
    t.string('middleInitial').nullable();
    t.string('streetNumber').nullable();
    t.string('city').nullable();
    t.string('state').nullable();
    t.string('zipCode').nullable();
    t.string('phoneNumber').nullable();
    t.integer('otp').nullable();
    t.string('socialSecurityNumber').nullable();
    t.boolean('isPhoneNumberVarified').nullable();
    t.boolean('eligibleToWorkInUs').nullable();
    t.boolean('haveYouEverWorkForThisCompany').nullable();
    t.boolean('haveYouEverBeenConvicatedOfFalony').nullable();
    t.string('skillAndQualification').nullable();
    t.datetime('appointmentDate').nullable();
    t.enu('status', ['incomplete', 'approved','rejected', 'pending',]).defaultsTo('incomplete');
    t.integer('userId').unsigned().notNullable();
    t.foreign('userId')
    .references('user.id');
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};
exports.down = function(knex, Promise) {
  return knex.schema.dropTableIfExists('application');
};
