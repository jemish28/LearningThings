
exports.up = function(knex, Promise) {
  return knex.schema.createTable('weeklyavailability', (t) => {
    t.increments('id').primary();
    t.datetime('date').nullable();
    t.boolean('status').nullable();
    t.integer('userId').unsigned().notNullable();
    t.foreign('userId')
    .references('user.id');
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.dropTableIfExists('weeklyavailability');
};
