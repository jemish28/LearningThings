
exports.up = function(knex, Promise) {
  return knex.schema.createTable('news', (t) => {
    t.increments('id').primary();
    t.string('title').nullable();
    t.text('news').nullable();
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.dropTableIfExists('news');
};
