exports.up = function(knex, Promise) {
  return knex.schema.createTable('chats', (t) => {
    t.increments('id').primary();
    t.integer('fromUserId').nullable();
    t.integer('userId').nullable();
    t.integer('groupId').nullable();
    t.string('chatType').defaultsTo('individualchat');
    t.string('chatHeaderType').defaultsTo('normal');
    t.text('mediaContent').nullable();
    t.string('mediaType').defaultsTo('text');
    t.string('mediaStatus').defaultsTo('sent');
    t.boolean('isRead');
    t.json('groupUserStatus');

    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.dropTableIfExists('chats');
};
