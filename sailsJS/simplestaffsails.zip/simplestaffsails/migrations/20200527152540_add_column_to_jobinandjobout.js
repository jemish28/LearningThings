
exports.up = function(knex, Promise) {
  return knex.schema.table('jobinandjobout', function (t) {
    t.string('total_hours').nullable();
  });
};

exports.down = function(knex, Promise) {

};
