
exports.up = function(knex, Promise) {
  return knex.schema.createTable('jobofuser', (t) => {
    t.increments('id').primary();
    t.integer('userId').nullable();
    t.string('status').nullable();
    t.integer('jobId').nullable();
    t.foreign('jobId')
    .references('job.id');
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {

};
