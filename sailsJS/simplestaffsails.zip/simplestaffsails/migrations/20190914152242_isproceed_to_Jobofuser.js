
exports.up = function(knex, Promise) {
  return knex.schema.table('jobofuser', function (t) {
    t.boolean('isproceed').defaultsTo(false).nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.table('jobofuser', function (t) {
    t.dropColumn('isproceed');
  });
};
