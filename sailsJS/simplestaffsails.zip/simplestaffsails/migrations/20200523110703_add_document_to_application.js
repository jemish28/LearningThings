
exports.up = function(knex, Promise) {
  return knex.schema.table('application', function (t) {
    t.string('document').nullable();
  });
};

exports.down = function(knex, Promise) {

};
