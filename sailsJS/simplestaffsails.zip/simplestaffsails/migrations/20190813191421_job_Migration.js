
exports.up = function(knex, Promise) {
  return knex.schema.table('job', (t) => {

    t.boolean('numberOfUser').nullable();

  });
};

exports.down = function(knex, Promise) {

};
