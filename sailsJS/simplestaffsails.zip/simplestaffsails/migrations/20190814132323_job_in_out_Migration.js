
exports.up = function(knex, Promise) {
  return knex.schema.table('jobinandjobout', (t) => {
    t.integer('userId').nullable();
    //    t.boolean('numberOfUser').nullable();

  });
};

exports.down = function(knex, Promise) {

};
