
exports.up = function(knex, Promise) {
  return knex.schema.createTable('ppeform', (t) => {
    t.increments('id').primary();
    t.integer('userId').nullable();
    t.foreign('userId')
    .references('user.id');
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
};
