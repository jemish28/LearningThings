
exports.up = function(knex, Promise) {
  return knex.schema.createTable('workplacesafety', (t) => {
    t.increments('id').primary();
    t.string('title').nullable();
    t.text('description').nullable();
    t.datetime('createdAt').nullable();
    t.datetime('updatedAt').nullable();
  });
};

exports.down = function(knex, Promise) {
  return knex.schema.dropTableIfExists('workplacesafety');
};
