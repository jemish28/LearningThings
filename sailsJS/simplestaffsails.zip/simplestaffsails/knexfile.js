module.exports = {
  development: {
    client: 'mysql',
    connection: 'mysql://root:root@localhost:3306/student_staffapp',
    migrations: {
      directory: __dirname + '/migrations',
    }
  },
  staging: {
    client: 'mysql',
    connection: 'mysql://root:hnpfPY4QATFFbsa7@localhost:3306/student_staffapp',
  },
  production: {
    client: 'mysql',
    connection: 'mysql://root:hnpfPY4QATFFbsa7@localhost:3306/student_staffapp',
  },
};
