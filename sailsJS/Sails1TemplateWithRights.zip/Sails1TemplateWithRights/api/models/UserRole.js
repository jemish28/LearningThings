module.exports = {
  tableName: "UserRole",
  attributes: {
    user: {
      model: "User",
    },
    role: {
      model: "Role",
    },
  },
};
