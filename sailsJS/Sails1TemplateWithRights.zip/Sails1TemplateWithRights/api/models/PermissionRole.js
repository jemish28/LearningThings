module.exports = {
  tableName: "PermissionRole",
  attributes: {
    permission: {
      model: "Permission",
    },
    role: {
      model: "Role",
    },
  },
};
