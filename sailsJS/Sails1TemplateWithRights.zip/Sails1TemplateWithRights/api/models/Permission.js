module.exports = {
  tableName: "Permission",
  fetchRecordsOnUpdate: true,
  attributes: {
    name: {
      type: "string",
      required: true,
    },
    displayName: {
      type: "string",
      required: true,
    },
    moduleName: {
      type: "string",
      allowNull: true,
    },
    description: {
      type: "string",
      required: true,
    },
    roles: {
      collection: "Role", // model name
      via: "permission", // permission role attributes -> permission
      through: "PermissionRole", // table name of pivot table
    },
  },
};
