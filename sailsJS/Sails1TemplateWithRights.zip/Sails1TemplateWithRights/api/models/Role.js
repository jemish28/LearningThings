module.exports = {
  tableName: "Role",
  fetchRecordsOnUpdate: true,
  attributes: {
    name: {
      type: "string",
      required: true,
      unique: true,
    },
    displayName: {
      type: "string",
      required: true,
    },
    description: {
      type: "string",
      required: true,
    },
    permissions: {
      collection: "Permission",
      via: "role",
      through: "PermissionRole",
    },
    users: {
      collection: "User",
      via: "role",
      through: "UserRole",
    },
  },
};
