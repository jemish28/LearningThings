module.exports = {


  friendlyName: 'Index',


  description: 'Index rolepermission.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    // All done.
    return;

  }


};
