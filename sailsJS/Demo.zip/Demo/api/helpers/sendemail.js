module.exports = {

  friendlyName: 'Send email',

  description: '',

  inputs: {
    to: {
      type: 'string',
      description: 'The email address of the primary recipient.',
      required: true
    },
    from: {
      type: 'string',
      description: 'The email address of the primary recipient.',
      defaultsTo: 'niravjadatiya@gmail.com', // TODO:
    },
    subject: {
      type: 'string',
      description: 'The subject of the email.',
      defaultsTo: '',
    },
    typeOfSend: {
      // expecting 'now','queue','preview'
      // 'now': it will send mail instant then respond to caller.
      // 'queue': it will add mail to queue.
      // 'preview': it will just return preview (not send mail).
      type: 'string',
      defaultsTo: 'now',
    }
  },
  exits: {
    success: {
      viewTemplatePath: '/User/user-index'
    },
    redirect: {
      responseType: 'redirect'
    },
  },


  fn: async function (inputs, exits) {
    // var nodemailer = require('nodemailer');
    // var transporter = nodemailer.createTransport({
    //   host: sails.config.custom.mail.host,
    //   port: sails.config.custom.mail.port,
    //   secure: false,
    //   service: sails.config.custom.mail.service,
    //   auth: {
    //     user: sails.config.custom.mail.email,
    //     pass: sails.config.custom.mail.password
    //   }
    // });
    var mainOptions = {
      from: sails.config.custom.mail.email,
      to: inputs.to,
      subject: inputs.subject,
      text: 'Hello this is test mail'
    };
    console.log(mainOptions);

    // transporter.sendMail(mailOptions, function (error, info) {
    //   if (error) {
    //     console.log(error);
    //   } else {
    //     console.log('Email sent: ' + info.response);
    //   }
    // });
    if (inputs.typeOfSend === 'now') {
      console.log('currently running job');
      Mailer.sendMail(mainOptions, (err, info) => {
        if (err) {
          console.log(err);
          return exits.success({
            message: 'opps!! sending mail failed'
          });
        }
        // console.log('Message sent: ' + info.response);
        // console.log('Message sent: %s', info.messageId);
        // console.log('Preview URL: %s', Mailer.getTestMessageUrl(info));
        return exits.success({
          message: 'email has been sent successfully,  to:' + inputs.to
        });
      });
    } else if (inputs.typeOfSend === 'queue') {
      Jobs.create('sendMail', {
        mainOptions: mainOptions
      }).priority('high').save((err) => {
        if (err) {
          return exits.success({
            message: err
          });
        }
        return exits.success({
          message: 'sending your mail'
        });
      });
    }  else {
      return exits.success({
        message: 'Something went Wrong'
      });
    }
  }
};
