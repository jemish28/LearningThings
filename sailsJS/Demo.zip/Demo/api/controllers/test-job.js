module.exports = {


  friendlyName: 'Test job',


  description: '',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs,exits) {
    Jobs.create("demoJob",{myParamKey:'myParamValue'})
      .save(function (err) {
        return exits.success(); 
      });
    // With attempt count & priority
    Jobs.create("demoJob", {myParamKey:'myParamValue'})
    .priority('high')
    .attempts(5)
    .save(function (err) {
      return exits.success();
    });
  }


};
