module.exports = {


  friendlyName: 'Send template email',


  description: 'Send an email using a template.',


  extendedDescription: 'To ease testing and development, if the provided "to" email address ends in "@example.com", ' +
    'then the email message will be written to the terminal instead of actually being sent.' +
    '(Thanks [@simonratner](https://github.com/simonratner)!)',


  inputs: {
    to: {
      description: 'The email address of the primary recipient.',
      extendedDescription: 'If this is any address ending in "@example.com", then don\'t actually deliver the message. ' +
        'Instead, just log it to the console.',
      example: 'nola.thacker@example.com',
      required: true,
      isEmail: true,
    },
    subject: {
      description: 'The subject of the email.',
      example: 'Hello there.',
      defaultsTo: ''
    },

    from: {
      description: 'An override for the default "from" email that\'s been configured.',
      example: 'anne.martin@example.com',
      isEmail: true,
    },
  },


  exits: {

    success: {
      outputFriendlyName: 'Email delivery report',
      outputDescription: 'A dictionary of information about what went down.',
      outputType: {
        loggedInsteadOfSending: 'boolean'
      }
    }

  },


  fn: async function ({to,subject,from,}) {
    // var messageData = {
    //   to:'jemish.me@gmail.com',
    //   subject:  "test",
    // };
 
    await sails.helpers.sendemail.with({
      subject: 'Please test',
      from: "jemishhasoram@gmal.com",
      });
    // All done!

  }

};
