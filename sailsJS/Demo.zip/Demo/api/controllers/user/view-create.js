module.exports = {
  friendlyName: 'View index',
  description: 'Display "Index" page.',
  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'User/create'
    },
    redirect: {
      responseType: 'redirect'
    }
  },
  fn: async function (inputs, exits) {
    var req = this.req;
    return exits.success();
  }
};
