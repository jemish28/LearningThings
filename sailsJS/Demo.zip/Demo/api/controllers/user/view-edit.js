// module.exports = {


//   friendlyName: 'View edit',


//   description: 'Display "Edit" page.',


//   exits: {

//     success: {
//       viewTemplatePath: 'pages/user/edit'
//     }

//   },


//   fn: async function () {

//     // Respond with view.
//     return {};

//   }


// };
module.exports = async function welcomeUser(req, res) {

  // Get the `userId` parameter from the request.
  // This could have been set on the querystring, in
  // the request body, or as part of the URL used to
  // make the request.
  var userId = req.param('id');

  // Look up the user whose ID was specified in the request.
  var user = await User2.findOne({
    id: userId
  });

  // If no user was found, redirect to signup.
  if (!user) {
    return res.redirect('/User/index');
  }

  // Display the welcome view, setting the view variable
  return res.view('User/edit', {
    user
  });

}
