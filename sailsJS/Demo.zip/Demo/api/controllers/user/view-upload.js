module.exports = {
  friendlyName: 'View index',
  description: 'Display "Upload" page.',
  exits: {
    success: {
      responseType: 'view',
      viewTemplatePath: 'fileupload'
    },
    redirect: {
      responseType: 'redirect'
    }
  },
  fn: async function (inputs, exits) {
    var req = this.req;
    return exits.success();
  }


};
