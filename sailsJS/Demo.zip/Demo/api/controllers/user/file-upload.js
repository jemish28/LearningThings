module.exports = async function welcomeUser(req, res) {
  var new_image_name = req.file('imageUrl')._files[0]["stream"]["filename"];

  var _newContact = await File.create({
    imageUrl: new_image_name
  }).fetch();

  req.file('imageUrl').upload({
    dirname: require('path').resolve(sails.config.appPath, 'assets/images/upload'),
    saveAs: new_image_name,
  }, function (err, images) {
    if (err) {
      sails.log('Error');
    } else {
      sails.log('Success');
    }
  });
   
  return res.redirect('/images');

   
  // return res.view('images', {
  //   user
  // });

}
