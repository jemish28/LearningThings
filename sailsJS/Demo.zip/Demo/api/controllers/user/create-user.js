
module.exports = {
  friendlyName: 'View index',
  description: 'Display "Index" page.',

  inputs: {
    fname: {
      type: "string",
      required: true,
    },
    lname: {
      type: "string",
      required: true,
    },
    email: {
      unique: true,
      required: true,
      type: "string",
      isEmail: true,
      description: "The email address for the new account, e.g. m@example.com.",
      extendedDescription: "Must be a valid email address.",
    },
    password: {
      required: true,
      type: "string",
      maxLength: 15,
      minLength: 6,
      example: "passwordlol",
      description: "The unencrypted password to use for the new account.",
    },
  },
  exits: {
    redirect: {
      responseType: 'redirect'
    },
  },
  fn: async function (inputs, exits) {
    console.log(inputs);
    var newEmailAddress = inputs.email.toLowerCase();
    var _newContact = await User2.create({
      fName: inputs.fname,
      lName: inputs.lname,
      email: newEmailAddress,
      password: await sails.helpers.passwords.hashPassword(inputs.password),
    });
    await sails.helpers.sendemail.with({
      to: newEmailAddress,
      subject: 'Please confirm your account',
      typeOfSend: 'queue', // 'now', 'queue', 'preview'
    });
    return exits.redirect('/User/user-index');
  }
};
