/* eslint-disable no-undef */
// module.exports = {
//   friendlyName: 'Update user',
//   description: '',
//   inputs: {
//   },
//   exits: {
//   },
//   fn: async function (inputs) {
//     // All done.
//     return;
//   }
// };
module.exports = async function welcomeUser(req, res) {
  var _updateContact = await User2.update({
    id: req.param('id')
  }).set({
    fName: req.param('fname'),
    lName: req.param('lname'),
    dob: req.param('dob'),
    email: req.param('email'),
    password: req.param('password'),
  });

 
  var user = await User2.find({});
  return res.view('User/index', {
    user
  });

}