module.exports = async function welcomeUser(req, res) {
  var user = await File.find({});
  if (!user) {
    return res.redirect('/view-upload');
  }
  return res.view('images', {
    user
  });
}