// module.exports = {


//   friendlyName: 'Index',


//   description: 'Index user.',


//   inputs: {

//   },


//   exits: {

//   },


//   fn: async function (inputs) {

//     // All done.
//     return;

//   }


// };
module.exports = async function welcomeUser(req, res) {

  var user = await User2.find({});

  if (!user) {
    return res.redirect('/User/create');
  }
  return res.view('User/index', {
    user
  });

}