
module.exports = async function welcomeUser(req, res) {
  var userId = req.param('id');

  // Look up the user whose ID was specified in the request.
  var user = await User2.destroyOne({
    id: userId
  });

  // If no user was found, redirect to signup.
  if (!user) {
    return res.redirect('404');
  }
  return res.redirect('/User/user-index');

}