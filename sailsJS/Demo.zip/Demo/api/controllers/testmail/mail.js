module.exports = {

  friendlyName: 'Test mail',

  description: '',

  inputs: {
    emailAddress: {
      description: 'The email address of the alleged user who wants to recover their password.',
      example: 'rydahl@example.com',
      type: 'string',
    }
  },


  exits: {
    showTemplate: {
      responseType: 'view',
      viewTemplatePath: 'emails/test-view'
    }
  },

  fn: async function (inputs, exits) {

    let mailStatus = await sails.helpers.sendEmail.with({
      to: 'jemish@logisticinfotech.co.in',
      subject: 'Your account has been updated',
      template: 'email-verify-new-email',
    });

    // console.log('mailStatus => ', mailStatus);
  
    return exits.success(mailStatus);
  }
}
