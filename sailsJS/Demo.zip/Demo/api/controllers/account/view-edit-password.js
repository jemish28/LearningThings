module.exports = {


  friendlyName: 'View edit password',


  description: 'Display "Edit password" page.',


  exits: {

    success: {
      viewTemplatePath: 'pages/account/edit-password'
    }

  },


  fn: async function () {

    return {};

  }


};
