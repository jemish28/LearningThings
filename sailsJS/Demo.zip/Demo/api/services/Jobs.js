/**
 * Kue job queue holder
 *
 * Queue will be loaded into this object in bootstrap.js
 */
module.exports = {
  _processors: {
    demoJob: function (job, cb) {
      sails.log.info("Job, job is done =>", job.data.myParamKey);
      cb();
    },
    sendMail: function (job, cb) {
      // console.log(job);
      console.log("sendMail,job is done", job.data.mainOptions);
      
      Mailer.sendMail(job.data.mainOptions, function (err, info) {
        if (err) {
          console.log(err);
          cb(err);
        }
        // console.log('Message sent: ' + info.response);
        cb();
      
      });
    },
  
    }
}