/**
 * Node Mailer service and setup
 */

// module.exports = nodemailer.createTransport('smtps://ankurgarach4%40gmail.com:garachankur4@smtp.gmail.com');


// create reusable transporter object using the default SMTP transport
var sails = require("sails");
var nodemailer = require("nodemailer");
var smtpTransport = require('nodemailer-smtp-transport');
module.exports = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  service:'gmail',
  port: 587, 
  secure: false, // true for 465, false for other ports
  auth: {
    user:"jemishharsoram@gmail.com",
    pass:"password@2810",
  }
});
