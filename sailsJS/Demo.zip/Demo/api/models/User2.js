/**
 * User2.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {
    fName: {
      type: 'string',
      required: true,
      maxLength: 120,
    },
    lName: {
      type: 'string',
      required: true,
      maxLength: 120,
    },
    email: {
      type: 'string',
      required: true,
      unique: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },
    password: {
      type: 'string',
      required: true,
      description: 'Securely hashed representation of the user\'s login password.',
      protect: true,
      example: '2$28a8eabna301089103-13948134nad'
    },
    // imageUrl: {
    //   type: 'string',
    //   required: true,
    //   description: 'imageUrl',
    //   maxLength: 120,
    // },
  },
  // customToJSON: function () {
  //   if (this.imageUrl) {
  //     this.imageUrl = sails.config.custom.baseUrl + this.imageUrl;
  //   }
  //   return _.omit(this, []);
  // },
  customToJSON: function () {
    return _.omit(this, ['password'])
  },
};

