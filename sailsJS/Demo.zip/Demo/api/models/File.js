/**
 * File.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {
    imageUrl: {
      type: 'string',
      description: 'imageUrl',
    },
  },
    // customToJSON: function () {
    //   if (this.imageUrl) {
    //     this.imageUrl = sails.config.custom.baseUrl + '/images/upload' + this.imageUrl;
    //   }
    //   return _.omit(this, []);
    // },
};

