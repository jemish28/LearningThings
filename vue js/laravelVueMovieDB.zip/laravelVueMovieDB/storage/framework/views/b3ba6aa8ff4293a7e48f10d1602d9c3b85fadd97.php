<?php $__env->startSection('content'); ?>
<div>
    <h3>Movie page </h3>
    <movie-component :data="<?php echo e(json_encode($movies['results'])); ?>"></movie-component>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Jemish/TRANING/vue js/laravelVueMovieDB/resources/views/movie.blade.php ENDPATH**/ ?>