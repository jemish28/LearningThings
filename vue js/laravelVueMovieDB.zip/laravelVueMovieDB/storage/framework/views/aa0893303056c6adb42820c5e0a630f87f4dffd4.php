<?php $__env->startSection('content'); ?>
<div>
    <h2>home </h2>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Jemish/TRANING/vue js/laravelVueMovieDB/resources/views/welcome.blade.php ENDPATH**/ ?>