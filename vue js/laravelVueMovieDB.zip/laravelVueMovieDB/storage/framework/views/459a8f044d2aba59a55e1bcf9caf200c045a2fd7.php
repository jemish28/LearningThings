<?php $__env->startSection('content'); ?>
<div>
    <h3>Welcome to Home page </h3>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Jemish/TRANING/vue js/laravelVueMovieDB/resources/views/home.blade.php ENDPATH**/ ?>