<!doctype html>
<html lang="en">

<head>
    <title>Movie DB</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <meta name="csrf-token" value="<?php echo e(csrf_token()); ?>" />
</head>

<body class="<?php echo $__env->yieldContent('body-class'); ?>" data-aos-easing="ease" data-aos-duration="1000" data-aos-delay="0">
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="app" class="container">
        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>
</body>

</html>
<?php /**PATH /var/www/html/Jemish/TRANING/vue js/laravelVueMovieDB/resources/views/layout/app.blade.php ENDPATH**/ ?>