<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class MovieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $req)
    {
        $credentials = $req->only('email', 'password');
        if (Auth::attempt($credentials)) {
            return response()->json(['status' => true, 'status2' => true]);
        } else {
            return response()->json(['status' => false, 'statusss' => true]);
        }
        return response()->json(['status' => false]);
    }
    public function signup(Request $req)
    {
        return response()->json(['status' => 'ss']);
    }

    public function index(Request $request)
    {
        $page = $request->page;
        $data = 'https://api.themoviedb.org/3/movie/upcoming?api_key=38252124dbbb11a893376bd6da75d318&language=en-US&page=' . $page;
        $response = Http::get($data);
        return $response;
    }

    public function movies()
    {
        $data = 'https://api.themoviedb.org/3/movie/upcoming?api_key=38252124dbbb11a893376bd6da75d318&language=en-US&page=1';
        $response = Http::get($data);
        $jsondata = $response->json();
        if ($response->successful()) {
            return view('movie')->with('movies', $jsondata);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\<Response></Response>
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
