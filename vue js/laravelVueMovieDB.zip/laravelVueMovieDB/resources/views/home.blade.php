@extends('layout.app')
@section('content')
<div>
    <h3>Welcome to Home page </h3>

</div>
@endsection
