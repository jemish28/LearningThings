@extends('layout.app')
@section('content')
<div>
    <h3>Movie page </h3>
    <movie-component :data="{{json_encode($movies['results'])}}"></movie-component>
</div>
@endsection
