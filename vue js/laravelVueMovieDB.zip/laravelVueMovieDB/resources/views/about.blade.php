@extends('layout.app')
@section('content')
<div>
    <h2>About page render</h2>
    <movie-component2></movie-component2>
</div>
@endsection
