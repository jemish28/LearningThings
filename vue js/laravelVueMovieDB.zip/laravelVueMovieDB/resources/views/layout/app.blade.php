<!doctype html>
<html lang="en">

<head>
    <title>Movie DB</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <script src="{{ asset('js/app.js') }}"></script>
    <meta name="csrf-token" value="{{ csrf_token() }}" />
</head>

<body class="@yield('body-class')" data-aos-easing="ease" data-aos-duration="1000" data-aos-delay="0">
    @include('layout.header')

    <div id="app" class="container">
        @yield('content')

    </div>
    @stack('scripts')
    <script src="{{ mix('js/app.js') }}" type="text/javascript"></script>
</body>

</html>
