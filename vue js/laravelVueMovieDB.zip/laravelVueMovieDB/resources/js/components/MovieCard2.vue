<template>
    <div class="container">
        <div class="row">
            <div
                v-for="list in results"
                v-bind:key="list.id"
                class="col-md-3 col-6 my-2 movie"
            >
                <div class="card" style="min-height: 515px">
                    <img
                        class="card-img-top"
                        :src="
                            `https://image.tmdb.org/t/p/w185_and_h278_bestv2` +
                                list.poster_path
                        "
                        alt="Card image cap"
                    />
                    <div class="card-body">
                        <span class="badge badge-pill badge-info">
                            {{ list.release_date }}
                        </span>
                        <p class="card-text overview">
                            {{ list.overview }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 my-4 text-center">
            <button
                type="submit"
                id="new"
                v-on:click="loadMore"
                class="btn btn-warning"
            >
                Load More
            </button>
        </div>
    </div>
</template>
<script>
import Vue from "vue";
import axios from "axios";
import VueAxios from "vue-axios";
Vue.use(VueAxios, axios);
export default {
    name: "MainContainer",
    data() {
        return {
            results: [],
            page: 1
        };
    },
    methods: {
        detailPage(id) {
            // console.log(id, this.detail);
            this.$router.push("/movies/" + id);
        },
        loadMore() {
            this.page += 1;
            axios
                .get(`http://127.0.0.1:8000/api/getMovies/` + this.page)
                .then(response => {
                    this.results = [...this.results, ...response.data.results];
                });
        }
    },
    mounted() {
        axios.get(`http://127.0.0.1:8000/api/getMovies`).then(response => {
            this.results = response.data.results;
            console.log(this.results);
        });
    }
};
</script>
<style scoped>
.card-title {
    white-space: nowrap;
    width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    font-weight: 600;
    font-size: 18px;
    margin-bottom: 0;
}
/**/
.overview {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    margin-top: 10px;
}
</style>
