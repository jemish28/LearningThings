<template>
    <div class="container">
        <div class="row">
            <div
                v-for="list in data"
                v-bind:key="list.id"
                class="col-md-3 col-6 my-2 movie"
            >
                <div class="card" style="min-height: 515px">
                    <img
                        class="card-img-top"
                        :src="
                            `https://image.tmdb.org/t/p/w185_and_h278_bestv2` +
                                list.poster_path
                        "
                        alt="Card image cap"
                    />
                    <div class="card-body">
                        <span class="badge badge-pill badge-info">
                            {{ list.release_date }}
                        </span>
                        <p class="card-text overview">
                            {{ list.overview }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 my-4 text-center">
            <button type="submit" id="new" class="btn btn-info">
                Load More
            </button>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        data: Array
    }
};
</script>
<style scoped>
.overview {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    margin-top: 10px;
}
</style>
