<template>
  <div>
    <h1>Posts</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'create' }" class="btn btn-primary">Create Post</router-link>
      </div>
    </div>
    <Post :data="data"></Post>
    <pagination :meta_data="meta_data" v-on:next="fetchUsers"></pagination>
  </div>
</template>

<script>
import Pagination from "./Pagination";
import Post from "./Post";
export default {
  components: {
    Pagination,
    Post,
  },
  data() {
    return {
      data: [],
      meta_data: {
        last_page: null,
        current_page: 1,
        prev_page_url: null,
      },
    };
  },
  mounted() {
    this.fetchUsers();
  },
  methods: {
    fetchUsers(page = 1) {
      this.axios
        .get("api/posts", {
          params: {
            page,
          },
        })
        .then((res) => {
          this.data = res.data.data;
          this.meta_data.last_page = res.data.last_page;
          this.meta_data.current_page = res.data.current_page;
          this.meta_data.prev_page_url = res.data.prev_page_url;
          console.log(res);
        });
    },
  },
};
</script>
