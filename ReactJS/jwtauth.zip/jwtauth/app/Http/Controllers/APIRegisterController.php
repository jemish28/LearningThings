<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use JWTFactory;
use JWTAuth;
use Validator;
use Response;

class APIRegisterController extends Controller
{
  // private $apiToken;

  // public function __construct()
  // {
  //   // Unique Token
  //   $this->JWTAuth = uniqid(base64_encode(str_random(60)));
  // }

  public function register(Request $request)
  {
    // Validations
    $rules = [
      'name'     => 'required|min:3',
      'email'    => 'required|unique:users,email',
      'password' => 'required|min:8'
    ];
    $validator = Validator::make($request->all(), $rules);
    if ($validator->fails()) {
      // Validation failed
      return response()->json([
        'message' => $validator->messages(),
      ]);
    } else {
      $postArray = [
        'name'      => $request->name,
        'email'     => $request->email,
        'password'  => bcrypt($request->password),
        

      ];
      // $user = User::GetInsertId($postArray);
      $user = User::insert($postArray);
  
      if($user) {
        return response()->json([
          'name'         => $request->name,
          'email'        => $request->email,
           
        ]);
      } else {
        return response()->json([
          'message' => 'Registration failed, please try again.',
        ]);
      }
    }
  }

}